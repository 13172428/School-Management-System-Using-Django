import { Link, useLocation } from 'react-router-dom'
import { useClerk, useUser } from '@clerk/clerk-react'
import {
  LayoutDashboard,
  Users,
  GraduationCap,
  BookOpen,
  CalendarCheck,
  ClipboardList,
  CreditCard,
  Bell,
  FileUp,
  Settings,
  LogOut,
  Menu,
  X,
  ChevronLeft,
  ChevronRight,
  Calendar,
} from 'lucide-react'
import { useState } from 'react'
import { cn, formatDate } from '@/lib/utils'
import { Button } from '@/components/ui/button'
import { useDate } from '@/store/date-context'
import { useActiveAcademicYear } from '@/api/queries'
import { Badge } from '@/components/ui/form-elements'

interface NavItem {
  label: string
  icon: React.ReactNode
  to: string
  adminOnly?: boolean
}

const NAV_ITEMS: NavItem[] = [
  { label: 'Dashboard', icon: <LayoutDashboard size={18} />, to: '/' },
  { label: 'Students', icon: <Users size={18} />, to: '/students', adminOnly: true },
  { label: 'Teachers', icon: <GraduationCap size={18} />, to: '/teachers', adminOnly: true },
  { label: 'Classes', icon: <BookOpen size={18} />, to: '/classes', adminOnly: true },
  { label: 'Attendance', icon: <CalendarCheck size={18} />, to: '/attendance' },
  { label: 'Exams', icon: <ClipboardList size={18} />, to: '/exams' },
  { label: 'Fees', icon: <CreditCard size={18} />, to: '/fees', adminOnly: true },
  { label: 'Holidays', icon: <Calendar size={18} />, to: '/holidays', adminOnly: true },
  { label: 'Notifications', icon: <Bell size={18} />, to: '/notifications', adminOnly: true },
  { label: 'CSV Import', icon: <FileUp size={18} />, to: '/csv-import', adminOnly: true },
  { label: 'Settings', icon: <Settings size={18} />, to: '/settings', adminOnly: true },
]

interface AppShellProps {
  children: React.ReactNode
  role: 'admin' | 'teacher'
}

export function AppShell({ children, role }: AppShellProps) {
  const location = useLocation()
  const { signOut } = useClerk()
  const { user } = useUser()
  const [sidebarOpen, setSidebarOpen] = useState(true)
  const { selectedDate, setSelectedDate, isToday, goToToday, goToPrevDay, goToNextDay } = useDate()
  const { data: activeYear } = useActiveAcademicYear()

  const visibleNav = NAV_ITEMS.filter((item) => !item.adminOnly || role === 'admin')

  return (
    <div className="flex h-screen overflow-hidden bg-background">
      {/* Sidebar */}
      <aside
        className={cn(
          'flex flex-col border-r bg-card transition-all duration-200',
          sidebarOpen ? 'w-56' : 'w-14',
        )}
      >
        {/* Logo */}
        <div className="flex h-14 items-center border-b px-3">
          {sidebarOpen ? (
            <span className="text-sm font-semibold text-primary truncate">Maharshi High School</span>
          ) : (
            <span className="text-lg font-bold text-primary">M</span>
          )}
        </div>

        {/* Nav */}
        <nav className="flex-1 overflow-y-auto py-3 space-y-0.5 px-1.5">
          {visibleNav.map((item) => (
            <Link
              key={item.to}
              to={item.to}
              className={cn(
                'flex items-center gap-2.5 rounded-md px-2 py-2 text-sm transition-colors',
                location.pathname === item.to || (item.to !== '/' && location.pathname.startsWith(item.to))
                  ? 'bg-primary text-primary-foreground'
                  : 'text-muted-foreground hover:bg-accent hover:text-accent-foreground',
              )}
            >
              {item.icon}
              {sidebarOpen && <span className="truncate">{item.label}</span>}
            </Link>
          ))}
        </nav>

        {/* User + collapse */}
        <div className="border-t p-2 space-y-1">
          {sidebarOpen && (
            <div className="px-2 py-1">
              <p className="text-xs font-medium truncate">{user?.fullName ?? user?.emailAddresses[0]?.emailAddress}</p>
              <p className="text-xs text-muted-foreground capitalize">{role}</p>
            </div>
          )}
          <button
            onClick={() => signOut()}
            className="flex w-full items-center gap-2 rounded-md px-2 py-2 text-sm text-muted-foreground hover:bg-accent hover:text-accent-foreground"
          >
            <LogOut size={16} />
            {sidebarOpen && 'Sign out'}
          </button>
        </div>
      </aside>

      {/* Main area */}
      <div className="flex flex-1 flex-col overflow-hidden">
        {/* Header */}
        <header className="flex h-14 items-center gap-3 border-b bg-card px-4">
          <Button variant="ghost" size="icon" onClick={() => setSidebarOpen((o) => !o)}>
            <Menu size={18} />
          </Button>

          {/* Date navigator */}
          <div className="flex items-center gap-1 ml-auto">
            <Button variant="ghost" size="icon" onClick={goToPrevDay}>
              <ChevronLeft size={16} />
            </Button>
            <div className="relative">
              <input
                type="date"
                value={selectedDate}
                onChange={(e) => setSelectedDate(e.target.value)}
                className="h-9 rounded-md border border-input bg-background px-3 text-sm focus:outline-none focus:ring-2 focus:ring-ring"
              />
            </div>
            <Button variant="ghost" size="icon" onClick={goToNextDay}>
              <ChevronRight size={16} />
            </Button>
            {!isToday && (
              <Button variant="outline" size="sm" onClick={goToToday}>
                Today
              </Button>
            )}
          </div>

          {/* Academic year badge */}
          {activeYear && (
            <Badge variant="secondary" className="hidden sm:flex">
              {activeYear.name}
            </Badge>
          )}
        </header>

        {/* Page content */}
        <main className="flex-1 overflow-y-auto p-6">{children}</main>
      </div>
    </div>
  )
}
