import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query'
import { get, post, patch, del } from '@/lib/api-client'
import type {
  AcademicYear,
  AdminDashboardStats,
  Attendance,
  AttendanceSummary,
  AuditLog,
  BulkAttendanceCreate,
  Class,
  CSVImportJob,
  Exam,
  ExamResult,
  ExamSchedule,
  FeeStructure,
  Holiday,
  MessageResponse,
  Notification,
  Payment,
  Student,
  StudentFee,
  Subject,
  Teacher,
  TeacherDashboardStats,
  TimetableSlot,
} from '@/types'

// ─── Academic Years ────────────────────────────────────────────────────────────

export const useAcademicYears = () =>
  useQuery({ queryKey: ['academic-years'], queryFn: () => get<AcademicYear[]>('/academic-years') })

export const useActiveAcademicYear = () =>
  useQuery({
    queryKey: ['academic-years', 'active'],
    queryFn: () => get<AcademicYear>('/academic-years/active'),
  })

export const useCreateAcademicYear = () => {
  const qc = useQueryClient()
  return useMutation({
    mutationFn: (data: Partial<AcademicYear>) => post<AcademicYear>('/academic-years', data),
    onSuccess: () => qc.invalidateQueries({ queryKey: ['academic-years'] }),
  })
}

export const useActivateAcademicYear = () => {
  const qc = useQueryClient()
  return useMutation({
    mutationFn: (id: string) => post<AcademicYear>(`/academic-years/${id}/activate`),
    onSuccess: () => qc.invalidateQueries({ queryKey: ['academic-years'] }),
  })
}

export const useArchiveAcademicYear = () => {
  const qc = useQueryClient()
  return useMutation({
    mutationFn: (id: string) => post<MessageResponse>(`/academic-years/${id}/archive`),
    onSuccess: () => qc.invalidateQueries({ queryKey: ['academic-years'] }),
  })
}

// ─── Students ─────────────────────────────────────────────────────────────────

export const useStudents = (params?: {
  academic_year_id?: string
  search?: string
  is_active?: boolean
}) =>
  useQuery({
    queryKey: ['students', params],
    queryFn: () => get<Student[]>('/students', { params }),
  })

export const useStudent = (id: string) =>
  useQuery({
    queryKey: ['students', id],
    queryFn: () => get<Student>(`/students/${id}`),
    enabled: !!id,
  })

export const useCreateStudent = () => {
  const qc = useQueryClient()
  return useMutation({
    mutationFn: (data: unknown) => post<Student>('/students', data),
    onSuccess: () => qc.invalidateQueries({ queryKey: ['students'] }),
  })
}

export const useUpdateStudent = () => {
  const qc = useQueryClient()
  return useMutation({
    mutationFn: ({ id, data }: { id: string; data: unknown }) =>
      patch<Student>(`/students/${id}`, data),
    onSuccess: (_d, { id }) => {
      qc.invalidateQueries({ queryKey: ['students'] })
      qc.invalidateQueries({ queryKey: ['students', id] })
    },
  })
}

export const useDeleteStudent = () => {
  const qc = useQueryClient()
  return useMutation({
    mutationFn: (id: string) => del<MessageResponse>(`/students/${id}`),
    onSuccess: () => qc.invalidateQueries({ queryKey: ['students'] }),
  })
}

// ─── Teachers ─────────────────────────────────────────────────────────────────

export const useTeachers = (params?: { search?: string; is_active?: boolean }) =>
  useQuery({
    queryKey: ['teachers', params],
    queryFn: () => get<Teacher[]>('/teachers', { params }),
  })

export const useTeacher = (id: string) =>
  useQuery({
    queryKey: ['teachers', id],
    queryFn: () => get<Teacher>(`/teachers/${id}`),
    enabled: !!id,
  })

export const useCreateTeacher = () => {
  const qc = useQueryClient()
  return useMutation({
    mutationFn: (data: unknown) => post<Teacher>('/teachers', data),
    onSuccess: () => qc.invalidateQueries({ queryKey: ['teachers'] }),
  })
}

export const useUpdateTeacher = () => {
  const qc = useQueryClient()
  return useMutation({
    mutationFn: ({ id, data }: { id: string; data: unknown }) =>
      patch<Teacher>(`/teachers/${id}`, data),
    onSuccess: () => qc.invalidateQueries({ queryKey: ['teachers'] }),
  })
}

// ─── Classes ──────────────────────────────────────────────────────────────────

export const useClasses = (academic_year_id?: string) =>
  useQuery({
    queryKey: ['classes', academic_year_id],
    queryFn: () => get<Class[]>('/classes', { params: { academic_year_id } }),
    enabled: !!academic_year_id,
  })

export const useCreateClass = () => {
  const qc = useQueryClient()
  return useMutation({
    mutationFn: (data: unknown) => post<Class>('/classes', data),
    onSuccess: () => qc.invalidateQueries({ queryKey: ['classes'] }),
  })
}

export const useClassStudents = (class_id: string) =>
  useQuery({
    queryKey: ['classes', class_id, 'students'],
    queryFn: () => get<Array<{ id: string; roll_number: string; full_name: string; is_active: boolean }>>(`/classes/${class_id}/students`),
    enabled: !!class_id,
  })

export const useEnrollStudent = () => {
  const qc = useQueryClient()
  return useMutation({
    mutationFn: ({ class_id, student_id }: { class_id: string; student_id: string }) =>
      post<MessageResponse>(`/classes/${class_id}/enroll/${student_id}`),
    onSuccess: (_d, { class_id }) => qc.invalidateQueries({ queryKey: ['classes', class_id] }),
  })
}

// ─── Subjects ─────────────────────────────────────────────────────────────────

export const useSubjects = (academic_year_id?: string) =>
  useQuery({
    queryKey: ['subjects', academic_year_id],
    queryFn: () => get<Subject[]>('/subjects', { params: { academic_year_id } }),
  })

export const useCreateSubject = () => {
  const qc = useQueryClient()
  return useMutation({
    mutationFn: (data: unknown) => post<Subject>('/subjects', data),
    onSuccess: () => qc.invalidateQueries({ queryKey: ['subjects'] }),
  })
}

// ─── Holidays ─────────────────────────────────────────────────────────────────

export const useHolidays = (params?: { academic_year_id?: string; from_date?: string; to_date?: string }) =>
  useQuery({
    queryKey: ['holidays', params],
    queryFn: () => get<Holiday[]>('/holidays', { params }),
  })

export const useUpcomingHolidays = (academic_year_id?: string, days = 30) =>
  useQuery({
    queryKey: ['holidays', 'upcoming', academic_year_id],
    queryFn: () => get<Holiday[]>('/holidays/upcoming', { params: { academic_year_id, days } }),
  })

export const useCreateHoliday = () => {
  const qc = useQueryClient()
  return useMutation({
    mutationFn: (data: unknown) => post<Holiday>('/holidays', data),
    onSuccess: () => qc.invalidateQueries({ queryKey: ['holidays'] }),
  })
}

export const useUpdateHoliday = () => {
  const qc = useQueryClient()
  return useMutation({
    mutationFn: ({ id, data }: { id: string; data: unknown }) =>
      patch<Holiday>(`/holidays/${id}`, data),
    onSuccess: () => qc.invalidateQueries({ queryKey: ['holidays'] }),
  })
}

export const useDeleteHoliday = () => {
  const qc = useQueryClient()
  return useMutation({
    mutationFn: (id: string) => del<MessageResponse>(`/holidays/${id}`),
    onSuccess: () => qc.invalidateQueries({ queryKey: ['holidays'] }),
  })
}

// ─── Attendance ───────────────────────────────────────────────────────────────

export const useAttendance = (class_id: string, date: string) =>
  useQuery({
    queryKey: ['attendance', class_id, date],
    queryFn: () => get<Attendance[]>(`/attendance/class/${class_id}`, { params: { date } }),
    enabled: !!class_id && !!date,
  })

export const useAttendanceSummary = (class_id: string, date: string) =>
  useQuery({
    queryKey: ['attendance-summary', class_id, date],
    queryFn: () => get<AttendanceSummary>(`/attendance/class/${class_id}/summary`, { params: { date } }),
    enabled: !!class_id && !!date,
  })

export const useEnrolledStudents = (class_id: string) =>
  useQuery({
    queryKey: ['enrolled-students', class_id],
    queryFn: () => get<Student[]>(`/attendance/class/${class_id}/enrolled`),
    enabled: !!class_id,
  })

export const useBulkMarkAttendance = () => {
  const qc = useQueryClient()
  return useMutation({
    mutationFn: (data: BulkAttendanceCreate) => post<unknown>('/attendance/bulk', data),
    onSuccess: (_d, vars) => {
      qc.invalidateQueries({ queryKey: ['attendance', vars.class_id] })
      qc.invalidateQueries({ queryKey: ['attendance-summary', vars.class_id] })
      qc.invalidateQueries({ queryKey: ['dashboard'] })
    },
  })
}

export const useStudentAttendanceStats = (student_id: string, academic_year_id: string) =>
  useQuery({
    queryKey: ['attendance-stats', student_id, academic_year_id],
    queryFn: () =>
      get<{ percentage: number; present: number; absent: number; total_working_days: number }>(
        `/attendance/student/${student_id}/stats`,
        { params: { academic_year_id } },
      ),
    enabled: !!student_id && !!academic_year_id,
  })

// ─── Exams ────────────────────────────────────────────────────────────────────

export const useExams = (academic_year_id?: string) =>
  useQuery({
    queryKey: ['exams', academic_year_id],
    queryFn: () => get<Exam[]>('/exams', { params: { academic_year_id } }),
  })

export const useExamSchedules = (exam_id: string) =>
  useQuery({
    queryKey: ['exam-schedules', exam_id],
    queryFn: () => get<ExamSchedule[]>(`/exams/${exam_id}/schedules`),
    enabled: !!exam_id,
  })

export const useExamResults = (exam_id: string, params?: { class_id?: string; subject_id?: string }) =>
  useQuery({
    queryKey: ['exam-results', exam_id, params],
    queryFn: () => get<ExamResult[]>(`/exams/${exam_id}/results`, { params }),
    enabled: !!exam_id,
  })

export const useCreateExam = () => {
  const qc = useQueryClient()
  return useMutation({
    mutationFn: (data: unknown) => post<Exam>('/exams', data),
    onSuccess: () => qc.invalidateQueries({ queryKey: ['exams'] }),
  })
}

export const useBulkSubmitResults = () => {
  const qc = useQueryClient()
  return useMutation({
    mutationFn: ({ exam_id, results }: { exam_id: string; results: unknown[] }) =>
      post<ExamResult[]>(`/exams/${exam_id}/results`, results),
    onSuccess: (_d, { exam_id }) => qc.invalidateQueries({ queryKey: ['exam-results', exam_id] }),
  })
}

// ─── Fees ─────────────────────────────────────────────────────────────────────

export const useFeeStructures = (academic_year_id?: string) =>
  useQuery({
    queryKey: ['fee-structures', academic_year_id],
    queryFn: () => get<FeeStructure[]>('/fees/structures', { params: { academic_year_id } }),
  })

export const useStudentFees = (params?: {
  student_id?: string
  academic_year_id?: string
  status?: string
}) =>
  useQuery({
    queryKey: ['student-fees', params],
    queryFn: () => get<StudentFee[]>('/fees', { params }),
  })

export const useFeeSummary = (academic_year_id?: string) =>
  useQuery({
    queryKey: ['fee-summary', academic_year_id],
    queryFn: () => get<{ by_status: Array<{ status: string; count: number; total: number; paid: number }> }>('/fees/summary', { params: { academic_year_id } }),
  })

export const useCreateFeeStructure = () => {
  const qc = useQueryClient()
  return useMutation({
    mutationFn: (data: unknown) => post<FeeStructure>('/fees/structures', data),
    onSuccess: () => qc.invalidateQueries({ queryKey: ['fee-structures'] }),
  })
}

export const useRecordPayment = () => {
  const qc = useQueryClient()
  return useMutation({
    mutationFn: ({ fee_id, data }: { fee_id: string; data: unknown }) =>
      post<Payment>(`/fees/${fee_id}/payments`, data),
    onSuccess: () => {
      qc.invalidateQueries({ queryKey: ['student-fees'] })
      qc.invalidateQueries({ queryKey: ['fee-summary'] })
    },
  })
}

export const useFeePayments = (fee_id: string) =>
  useQuery({
    queryKey: ['fee-payments', fee_id],
    queryFn: () => get<Payment[]>(`/fees/${fee_id}/payments`),
    enabled: !!fee_id,
  })

// ─── Timetable ────────────────────────────────────────────────────────────────

export const useTimetableSlots = (params?: { class_id?: string; teacher_id?: string; academic_year_id?: string }) =>
  useQuery({
    queryKey: ['timetable', params],
    queryFn: () => get<TimetableSlot[]>('/timetable', { params }),
  })

export const useClassWeeklyTimetable = (class_id: string, academic_year_id?: string) =>
  useQuery({
    queryKey: ['timetable-weekly', class_id, academic_year_id],
    queryFn: () => get<Record<string, TimetableSlot[]>>(`/timetable/class/${class_id}/week`, { params: { academic_year_id } }),
    enabled: !!class_id,
  })

export const useCreateTimetableSlot = () => {
  const qc = useQueryClient()
  return useMutation({
    mutationFn: (data: unknown) => post<TimetableSlot>('/timetable', data),
    onSuccess: () => qc.invalidateQueries({ queryKey: ['timetable'] }),
  })
}

export const useDeleteTimetableSlot = () => {
  const qc = useQueryClient()
  return useMutation({
    mutationFn: (id: string) => del<MessageResponse>(`/timetable/${id}`),
    onSuccess: () => qc.invalidateQueries({ queryKey: ['timetable'] }),
  })
}

// ─── Notifications ────────────────────────────────────────────────────────────

export const useNotifications = (params?: { student_id?: string; status?: string }) =>
  useQuery({
    queryKey: ['notifications', params],
    queryFn: () => get<Notification[]>('/notifications', { params }),
  })

export const useNotificationAnalytics = (academic_year_id?: string) =>
  useQuery({
    queryKey: ['notification-analytics', academic_year_id],
    queryFn: () =>
      get<{
        by_status: Array<{ status: string; count: number }>
        by_channel: Array<{ channel: string; count: number }>
      }>('/notifications/analytics', { params: { academic_year_id } }),
  })

// ─── CSV Import ───────────────────────────────────────────────────────────────

export const useCSVImportJobs = (import_type?: string) =>
  useQuery({
    queryKey: ['csv-import-jobs', import_type],
    queryFn: () => get<CSVImportJob[]>('/csv-import', { params: { import_type } }),
  })

export const useCSVImportJob = (id: string) =>
  useQuery({
    queryKey: ['csv-import-jobs', id],
    queryFn: () => get<CSVImportJob>(`/csv-import/${id}`),
    enabled: !!id,
    refetchInterval: (query) => {
      const data = query.state.data as CSVImportJob | undefined
      if (data?.status === 'processing' || data?.status === 'pending') return 2000
      return false
    },
  })

export const useRollbackCSVImport = () => {
  const qc = useQueryClient()
  return useMutation({
    mutationFn: (id: string) => post<MessageResponse>(`/csv-import/${id}/rollback`),
    onSuccess: () => qc.invalidateQueries({ queryKey: ['csv-import-jobs'] }),
  })
}

// ─── Audit Logs ───────────────────────────────────────────────────────────────

export const useAuditLogs = (params?: {
  action?: string
  resource_type?: string
  from_dt?: string
  to_dt?: string
}) =>
  useQuery({
    queryKey: ['audit-logs', params],
    queryFn: () => get<AuditLog[]>('/audit-logs', { params }),
  })

// ─── Dashboard ────────────────────────────────────────────────────────────────

export const useAdminDashboard = (date?: string) =>
  useQuery({
    queryKey: ['dashboard', 'admin', date],
    queryFn: () => get<AdminDashboardStats>('/dashboard/admin', { params: { date } }),
    refetchInterval: 5 * 60 * 1000, // refresh every 5 minutes
  })

export const useTeacherDashboard = (date?: string) =>
  useQuery({
    queryKey: ['dashboard', 'teacher', date],
    queryFn: () => get<TeacherDashboardStats>('/dashboard/teacher', { params: { date } }),
    refetchInterval: 5 * 60 * 1000,
  })
