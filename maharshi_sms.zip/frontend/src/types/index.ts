// ─── Enums ────────────────────────────────────────────────────────────────────

export type UserRole = 'admin' | 'teacher'

export type AttendanceStatus = 'present' | 'absent' | 'late' | 'excused'

export type FeeStatus = 'pending' | 'partial' | 'paid' | 'overdue' | 'waived'

export type NotificationStatus = 'pending' | 'sent' | 'delivered' | 'read' | 'failed'

export type NotificationChannel = 'whatsapp' | 'email' | 'sms'

export type HolidayType =
  | 'national'
  | 'state'
  | 'school'
  | 'religious'
  | 'emergency'
  | 'other'

export type CSVImportStatus = 'pending' | 'processing' | 'completed' | 'failed' | 'rolled_back'

export type CSVImportType = 'students' | 'teachers' | 'fees' | 'marks'

export type ExamType = 'unit_test' | 'midterm' | 'final' | 'quarterly' | 'annual' | 'other'

export type PaymentMethod = 'cash' | 'cheque' | 'online' | 'bank_transfer' | 'dd' | 'other'

export type WhatsAppResponseStatus = 'pending' | 'responded' | 'locked' | 'expired'

// ─── Core Models ──────────────────────────────────────────────────────────────

export interface AcademicYear {
  id: string
  name: string
  start_date: string
  end_date: string
  is_active: boolean
  is_archived: boolean
  description: string | null
  created_at: string
  updated_at: string
}

export interface Teacher {
  id: string
  employee_id: string
  first_name: string
  last_name: string
  full_name: string
  email: string
  phone: string | null
  whatsapp_number: string | null
  qualification: string | null
  joining_date: string | null
  is_active: boolean
  clerk_user_id: string | null
  created_at: string
}

export interface ParentContact {
  id: string
  relationship_type: 'father' | 'mother' | 'guardian'
  name: string
  phone: string | null
  whatsapp_number: string | null
  email: string | null
  occupation: string | null
  is_primary: boolean
}

export interface Student {
  id: string
  admission_number: string
  first_name: string
  last_name: string
  full_name: string
  date_of_birth: string | null
  gender: 'male' | 'female' | 'other' | null
  blood_group: string | null
  admission_date: string | null
  is_active: boolean
  parent_contacts: ParentContact[]
  created_at: string
}

export interface Class {
  id: string
  academic_year_id: string
  name: string
  section: string
  display_name: string
  room_number: string | null
  capacity: number
  is_active: boolean
  student_count: number
}

export interface Subject {
  id: string
  code: string
  name: string
  description: string | null
  is_active: boolean
  max_marks: number
  passing_marks: number
}

export interface Holiday {
  id: string
  academic_year_id: string
  name: string
  description: string | null
  start_date: string
  end_date: string
  holiday_type: HolidayType
  is_active: boolean
  duration_days: number
}

export interface Attendance {
  id: string
  student_id: string
  class_id: string
  attendance_date: string
  status: AttendanceStatus
  remarks: string | null
  parent_reason: string | null
  parent_reason_locked: boolean
  whatsapp_response_status: WhatsAppResponseStatus
  student_name?: string
  roll_number?: number
}

export interface AttendanceSummary {
  total_enrolled: number
  present: number
  absent: number
  late: number
  not_marked: number
  attendance_percentage: number
}

export interface Exam {
  id: string
  academic_year_id: string
  name: string
  exam_type: ExamType
  start_date: string
  end_date: string
  is_published: boolean
  description: string | null
  created_at: string
}

export interface ExamSchedule {
  id: string
  exam_id: string
  class_id: string
  subject_id: string
  exam_date: string
  start_time: string | null
  end_time: string | null
  room: string | null
}

export interface ExamResult {
  id: string
  exam_id: string
  student_id: string
  subject_id: string
  marks_obtained: number | null
  max_marks: number
  is_absent: boolean
  remarks: string | null
  percentage: number | null
}

export interface FeeStructure {
  id: string
  academic_year_id: string
  name: string
  description: string | null
  amount: number
  due_date: string | null
  is_mandatory: boolean
  is_active: boolean
}

export interface StudentFee {
  id: string
  student_id: string
  fee_structure_id: string
  academic_year_id: string
  amount: number
  paid_amount: number
  due_date: string | null
  status: FeeStatus
  concession_amount: number
  concession_reason: string | null
  balance: number
}

export interface Payment {
  id: string
  student_fee_id: string
  amount: number
  payment_date: string
  payment_method: PaymentMethod
  receipt_number: string | null
  transaction_id: string | null
  remarks: string | null
  created_at: string
}

export interface Notification {
  id: string
  student_id: string | null
  channel: NotificationChannel
  recipient_number: string | null
  status: NotificationStatus
  sent_at: string | null
  notification_type: string
  error_message: string | null
}

export interface CSVImportJob {
  id: string
  import_type: CSVImportType
  filename: string
  total_rows: number
  processed_rows: number
  success_rows: number
  error_rows: number
  duplicate_rows: number
  status: CSVImportStatus
  errors: Array<{ row: number; error: string }> | null
  started_at: string | null
  completed_at: string | null
  created_at: string
}

export interface AuditLog {
  id: string
  created_at: string
  actor_clerk_id: string | null
  actor_role: string | null
  actor_name: string | null
  action: string
  resource_type: string
  resource_id: string | null
  ip_address: string | null
}

export interface TimetableSlot {
  id: string
  academic_year_id: string
  class_id: string
  subject_id: string | null
  teacher_id: string | null
  day_of_week: number
  start_time: string
  end_time: string
  room: string | null
}

// ─── Dashboard ────────────────────────────────────────────────────────────────

export interface AdminDashboardStats {
  date: string
  total_students: number
  active_students: number
  present_today: number
  absent_today: number
  attendance_percentage: number
  total_fees: number
  collected_fees: number
  pending_fees: number
  overdue_fees: number
  total_teachers: number
  active_teachers: number
  notifications_sent: number
  notifications_failed: number
  upcoming_holidays: Holiday[]
  is_today_holiday: boolean
  holiday_name: string | null
}

export interface TeacherDashboardStats {
  date: string
  teacher_id: string
  todays_classes: Array<{
    class_id: string
    class_name: string
    subject: string
    start_time: string
    end_time: string
    is_attended_marked: boolean
  }>
  attendance_summary: Array<{
    class_id: string
    class_name: string
    present: number
    absent: number
    total: number
    percentage: number
  }>
  upcoming_exams: Exam[]
  pending_attendance_classes: Array<{ class_id: string; class_name: string }>
}

// ─── API Request Types ────────────────────────────────────────────────────────

export interface AttendanceRecord {
  student_id: string
  status: AttendanceStatus
  remarks?: string
}

export interface BulkAttendanceCreate {
  class_id: string
  attendance_date: string
  records: AttendanceRecord[]
  send_whatsapp_notifications: boolean
}

export interface MessageResponse {
  message: string
  success: boolean
}

export interface PaginationParams {
  skip?: number
  limit?: number
}
