import { useState } from 'react'
import { Plus, Pencil, Trash2 } from 'lucide-react'
import { Card, CardContent } from '@/components/ui/card'
import { Button } from '@/components/ui/button'
import { Input, Badge, Skeleton } from '@/components/ui/form-elements'
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table'
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter } from '@/components/ui/dialog'
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select'
import {
  useHolidays,
  useCreateHoliday,
  useUpdateHoliday,
  useDeleteHoliday,
  useActiveAcademicYear,
} from '@/api/queries'
import type { Holiday, HolidayType } from '@/types'
import { formatDate } from '@/lib/utils'
import { useToast } from '@/hooks/use-toast'

const HOLIDAY_TYPES: HolidayType[] = ['national', 'state', 'school', 'religious', 'emergency', 'other']

const TYPE_COLORS: Record<HolidayType, string> = {
  national: 'info',
  state: 'secondary',
  school: 'success',
  religious: 'warning',
  emergency: 'destructive',
  other: 'outline',
}

interface HolidayFormData {
  name: string
  description: string
  start_date: string
  end_date: string
  holiday_type: HolidayType
}

function HolidayForm({
  holiday,
  academicYearId,
  onClose,
}: {
  holiday?: Holiday
  academicYearId: string
  onClose: () => void
}) {
  const { toast } = useToast()
  const create = useCreateHoliday()
  const update = useUpdateHoliday()

  const [form, setForm] = useState<HolidayFormData>({
    name: holiday?.name ?? '',
    description: holiday?.description ?? '',
    start_date: holiday?.start_date ?? '',
    end_date: holiday?.end_date ?? '',
    holiday_type: holiday?.holiday_type ?? 'school',
  })

  const handleSubmit = async () => {
    if (!form.name || !form.start_date || !form.end_date) {
      toast({ title: 'Please fill all required fields.', variant: 'destructive' })
      return
    }
    try {
      if (holiday) {
        await update.mutateAsync({ id: holiday.id, data: form })
        toast({ title: 'Holiday updated', variant: 'success' })
      } else {
        await create.mutateAsync({ ...form, academic_year_id: academicYearId })
        toast({ title: 'Holiday created', variant: 'success' })
      }
      onClose()
    } catch (e: unknown) {
      const msg = (e as { response?: { data?: { detail?: string } } })?.response?.data?.detail ?? 'Failed.'
      toast({ title: 'Error', description: msg, variant: 'destructive' })
    }
  }

  const isPending = create.isPending || update.isPending

  return (
    <div className="space-y-4">
      <div>
        <label className="text-sm font-medium">Holiday Name *</label>
        <Input
          value={form.name}
          onChange={(e) => setForm((p) => ({ ...p, name: e.target.value }))}
          className="mt-1"
          placeholder="e.g. Independence Day"
        />
      </div>
      <div className="grid grid-cols-2 gap-3">
        <div>
          <label className="text-sm font-medium">Start Date *</label>
          <Input
            type="date"
            value={form.start_date}
            onChange={(e) => setForm((p) => ({ ...p, start_date: e.target.value }))}
            className="mt-1"
          />
        </div>
        <div>
          <label className="text-sm font-medium">End Date *</label>
          <Input
            type="date"
            value={form.end_date}
            onChange={(e) => setForm((p) => ({ ...p, end_date: e.target.value }))}
            className="mt-1"
          />
        </div>
      </div>
      <div>
        <label className="text-sm font-medium">Holiday Type</label>
        <Select
          value={form.holiday_type}
          onValueChange={(v) => setForm((p) => ({ ...p, holiday_type: v as HolidayType }))}
        >
          <SelectTrigger className="mt-1">
            <SelectValue />
          </SelectTrigger>
          <SelectContent>
            {HOLIDAY_TYPES.map((t) => (
              <SelectItem key={t} value={t} className="capitalize">
                {t}
              </SelectItem>
            ))}
          </SelectContent>
        </Select>
      </div>
      <div>
        <label className="text-sm font-medium">Description</label>
        <Input
          value={form.description}
          onChange={(e) => setForm((p) => ({ ...p, description: e.target.value }))}
          className="mt-1"
          placeholder="Optional description"
        />
      </div>
      <DialogFooter>
        <Button variant="outline" onClick={onClose}>Cancel</Button>
        <Button onClick={handleSubmit} disabled={isPending}>
          {isPending ? 'Saving…' : holiday ? 'Update' : 'Create Holiday'}
        </Button>
      </DialogFooter>
    </div>
  )
}

export function HolidaysPage() {
  const { data: activeYear } = useActiveAcademicYear()
  const { data: holidays, isLoading } = useHolidays({ academic_year_id: activeYear?.id })
  const deleteHoliday = useDeleteHoliday()
  const { toast } = useToast()

  const [showAdd, setShowAdd] = useState(false)
  const [editHoliday, setEditHoliday] = useState<Holiday | null>(null)

  const handleDelete = async (id: string, name: string) => {
    if (!confirm(`Delete holiday "${name}"?`)) return
    try {
      await deleteHoliday.mutateAsync(id)
      toast({ title: 'Holiday deleted', variant: 'success' })
    } catch {
      toast({ title: 'Failed to delete', variant: 'destructive' })
    }
  }

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <h1 className="text-2xl font-bold">Holidays</h1>
        <Button onClick={() => setShowAdd(true)}>
          <Plus size={16} className="mr-1" /> Add Holiday
        </Button>
      </div>

      <Card>
        <CardContent className="p-0">
          {isLoading ? (
            <div className="p-6 space-y-2">
              {Array.from({ length: 5 }).map((_, i) => <Skeleton key={i} className="h-10 w-full" />)}
            </div>
          ) : (
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead>Name</TableHead>
                  <TableHead>Type</TableHead>
                  <TableHead>Start Date</TableHead>
                  <TableHead>End Date</TableHead>
                  <TableHead>Duration</TableHead>
                  <TableHead className="w-20">Actions</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {holidays?.map((holiday) => (
                  <TableRow key={holiday.id}>
                    <TableCell className="font-medium">{holiday.name}</TableCell>
                    <TableCell>
                      <Badge
                        variant={TYPE_COLORS[holiday.holiday_type] as 'info' | 'secondary' | 'success' | 'warning' | 'destructive' | 'outline'}
                        className="capitalize"
                      >
                        {holiday.holiday_type}
                      </Badge>
                    </TableCell>
                    <TableCell>{formatDate(holiday.start_date)}</TableCell>
                    <TableCell>{formatDate(holiday.end_date)}</TableCell>
                    <TableCell>{holiday.duration_days} day{holiday.duration_days !== 1 ? 's' : ''}</TableCell>
                    <TableCell>
                      <div className="flex gap-1">
                        <Button variant="ghost" size="icon" onClick={() => setEditHoliday(holiday)}>
                          <Pencil size={14} />
                        </Button>
                        <Button
                          variant="ghost"
                          size="icon"
                          className="text-destructive"
                          onClick={() => handleDelete(holiday.id, holiday.name)}
                        >
                          <Trash2 size={14} />
                        </Button>
                      </div>
                    </TableCell>
                  </TableRow>
                ))}
                {holidays?.length === 0 && (
                  <TableRow>
                    <TableCell colSpan={6} className="text-center text-muted-foreground py-8">
                      No holidays found.
                    </TableCell>
                  </TableRow>
                )}
              </TableBody>
            </Table>
          )}
        </CardContent>
      </Card>

      <Dialog open={showAdd} onOpenChange={setShowAdd}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>Add Holiday</DialogTitle>
          </DialogHeader>
          {activeYear && (
            <HolidayForm academicYearId={activeYear.id} onClose={() => setShowAdd(false)} />
          )}
        </DialogContent>
      </Dialog>

      <Dialog open={!!editHoliday} onOpenChange={(o) => { if (!o) setEditHoliday(null) }}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>Edit Holiday</DialogTitle>
          </DialogHeader>
          {activeYear && editHoliday && (
            <HolidayForm
              holiday={editHoliday}
              academicYearId={activeYear.id}
              onClose={() => setEditHoliday(null)}
            />
          )}
        </DialogContent>
      </Dialog>
    </div>
  )
}
