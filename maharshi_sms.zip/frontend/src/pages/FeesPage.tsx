import { useState } from 'react'
import { Plus, CreditCard, CheckCircle } from 'lucide-react'
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card'
import { Button } from '@/components/ui/button'
import { Input, Badge, Skeleton } from '@/components/ui/form-elements'
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table'
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter } from '@/components/ui/dialog'
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select'
import {
  useFeeStructures,
  useStudentFees,
  useFeeSummary,
  useCreateFeeStructure,
  useRecordPayment,
  useActiveAcademicYear,
} from '@/api/queries'
import type { FeeStatus, PaymentMethod, StudentFee } from '@/types'
import { formatCurrency, formatDate } from '@/lib/utils'
import { useToast } from '@/hooks/use-toast'

const STATUS_COLORS: Record<FeeStatus, string> = {
  paid: 'success',
  pending: 'secondary',
  partial: 'warning',
  overdue: 'destructive',
  waived: 'outline',
}

function RecordPaymentModal({ fee, onClose }: { fee: StudentFee; onClose: () => void }) {
  const { toast } = useToast()
  const recordPayment = useRecordPayment()
  const [form, setForm] = useState({
    amount: String(fee.balance),
    payment_date: new Date().toISOString().split('T')[0],
    payment_method: 'cash' as PaymentMethod,
    receipt_number: '',
    remarks: '',
  })

  const handleSubmit = async () => {
    try {
      await recordPayment.mutateAsync({
        fee_id: fee.id,
        data: { ...form, amount: parseFloat(form.amount) },
      })
      toast({ title: 'Payment recorded', variant: 'success' })
      onClose()
    } catch {
      toast({ title: 'Failed to record payment', variant: 'destructive' })
    }
  }

  return (
    <div className="space-y-4">
      <div className="rounded-md bg-muted/50 p-3 text-sm">
        <p>Balance due: <strong>{formatCurrency(fee.balance)}</strong></p>
        <p className="text-muted-foreground">Total: {formatCurrency(fee.amount)} | Paid: {formatCurrency(fee.paid_amount)}</p>
      </div>
      <div className="grid grid-cols-2 gap-3">
        <div>
          <label className="text-sm font-medium">Amount (₹)</label>
          <Input
            type="number"
            value={form.amount}
            onChange={(e) => setForm((p) => ({ ...p, amount: e.target.value }))}
            className="mt-1"
          />
        </div>
        <div>
          <label className="text-sm font-medium">Payment Date</label>
          <Input
            type="date"
            value={form.payment_date}
            onChange={(e) => setForm((p) => ({ ...p, payment_date: e.target.value }))}
            className="mt-1"
          />
        </div>
        <div>
          <label className="text-sm font-medium">Payment Method</label>
          <Select value={form.payment_method} onValueChange={(v) => setForm((p) => ({ ...p, payment_method: v as PaymentMethod }))}>
            <SelectTrigger className="mt-1"><SelectValue /></SelectTrigger>
            <SelectContent>
              {['cash', 'cheque', 'online', 'bank_transfer', 'dd'].map((m) => (
                <SelectItem key={m} value={m} className="capitalize">{m}</SelectItem>
              ))}
            </SelectContent>
          </Select>
        </div>
        <div>
          <label className="text-sm font-medium">Receipt No.</label>
          <Input
            value={form.receipt_number}
            onChange={(e) => setForm((p) => ({ ...p, receipt_number: e.target.value }))}
            className="mt-1"
          />
        </div>
      </div>
      <div>
        <label className="text-sm font-medium">Remarks</label>
        <Input
          value={form.remarks}
          onChange={(e) => setForm((p) => ({ ...p, remarks: e.target.value }))}
          className="mt-1"
        />
      </div>
      <DialogFooter>
        <Button variant="outline" onClick={onClose}>Cancel</Button>
        <Button onClick={handleSubmit} disabled={recordPayment.isPending}>
          {recordPayment.isPending ? 'Recording…' : 'Record Payment'}
        </Button>
      </DialogFooter>
    </div>
  )
}

export function FeesPage() {
  const { data: activeYear } = useActiveAcademicYear()
  const { data: summary } = useFeeSummary(activeYear?.id)
  const { data: fees, isLoading } = useStudentFees({ academic_year_id: activeYear?.id })
  const { data: structures } = useFeeStructures(activeYear?.id)
  const [paymentFee, setPaymentFee] = useState<StudentFee | null>(null)

  // Summary totals
  const totalFees = summary?.by_status.reduce((s, r) => s + r.total, 0) ?? 0
  const collectedFees = summary?.by_status.reduce((s, r) => s + r.paid, 0) ?? 0
  const overdueFees = summary?.by_status.find((r) => r.status === 'overdue')?.total ?? 0

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <h1 className="text-2xl font-bold">Fees</h1>
      </div>

      {/* Summary cards */}
      <div className="grid grid-cols-2 gap-4 lg:grid-cols-4">
        <Card><CardContent className="pt-5 pb-4">
          <p className="text-xs text-muted-foreground">Total Fees</p>
          <p className="text-xl font-bold">{formatCurrency(totalFees)}</p>
        </CardContent></Card>
        <Card><CardContent className="pt-5 pb-4">
          <p className="text-xs text-muted-foreground">Collected</p>
          <p className="text-xl font-bold text-green-600">{formatCurrency(collectedFees)}</p>
        </CardContent></Card>
        <Card><CardContent className="pt-5 pb-4">
          <p className="text-xs text-muted-foreground">Outstanding</p>
          <p className="text-xl font-bold text-yellow-600">{formatCurrency(totalFees - collectedFees)}</p>
        </CardContent></Card>
        <Card><CardContent className="pt-5 pb-4">
          <p className="text-xs text-muted-foreground">Overdue</p>
          <p className="text-xl font-bold text-red-600">{formatCurrency(overdueFees)}</p>
        </CardContent></Card>
      </div>

      {/* Fee structures */}
      {structures && structures.length > 0 && (
        <Card>
          <CardHeader><CardTitle className="text-base">Fee Structures</CardTitle></CardHeader>
          <CardContent className="p-0">
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead>Name</TableHead>
                  <TableHead>Amount</TableHead>
                  <TableHead>Due Date</TableHead>
                  <TableHead>Mandatory</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {structures.map((s) => (
                  <TableRow key={s.id}>
                    <TableCell className="font-medium">{s.name}</TableCell>
                    <TableCell>{formatCurrency(s.amount)}</TableCell>
                    <TableCell>{formatDate(s.due_date)}</TableCell>
                    <TableCell>
                      <Badge variant={s.is_mandatory ? 'info' : 'secondary'}>
                        {s.is_mandatory ? 'Mandatory' : 'Optional'}
                      </Badge>
                    </TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          </CardContent>
        </Card>
      )}

      {/* Student fees */}
      <Card>
        <CardHeader><CardTitle className="text-base">Student Fees</CardTitle></CardHeader>
        <CardContent className="p-0">
          {isLoading ? (
            <div className="p-6 space-y-2">
              {Array.from({ length: 6 }).map((_, i) => <Skeleton key={i} className="h-10 w-full" />)}
            </div>
          ) : (
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead>Student ID</TableHead>
                  <TableHead>Total</TableHead>
                  <TableHead>Paid</TableHead>
                  <TableHead>Balance</TableHead>
                  <TableHead>Due Date</TableHead>
                  <TableHead>Status</TableHead>
                  <TableHead className="w-24">Actions</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {fees?.map((fee) => (
                  <TableRow key={fee.id}>
                    <TableCell className="font-mono text-xs">{fee.student_id.slice(0, 8)}…</TableCell>
                    <TableCell>{formatCurrency(fee.amount)}</TableCell>
                    <TableCell className="text-green-600">{formatCurrency(fee.paid_amount)}</TableCell>
                    <TableCell className={fee.balance > 0 ? 'text-red-600 font-medium' : 'text-green-600'}>
                      {formatCurrency(fee.balance)}
                    </TableCell>
                    <TableCell>{formatDate(fee.due_date)}</TableCell>
                    <TableCell>
                      <Badge variant={STATUS_COLORS[fee.status] as 'success' | 'secondary' | 'warning' | 'destructive' | 'outline'}>
                        {fee.status}
                      </Badge>
                    </TableCell>
                    <TableCell>
                      {fee.status !== 'paid' && fee.status !== 'waived' && (
                        <Button
                          size="sm"
                          variant="outline"
                          onClick={() => setPaymentFee(fee)}
                        >
                          <CreditCard size={12} className="mr-1" /> Pay
                        </Button>
                      )}
                      {fee.status === 'paid' && <CheckCircle size={16} className="text-green-500" />}
                    </TableCell>
                  </TableRow>
                ))}
                {fees?.length === 0 && (
                  <TableRow>
                    <TableCell colSpan={7} className="text-center text-muted-foreground py-8">
                      No fee records found.
                    </TableCell>
                  </TableRow>
                )}
              </TableBody>
            </Table>
          )}
        </CardContent>
      </Card>

      {/* Payment modal */}
      <Dialog open={!!paymentFee} onOpenChange={(o) => { if (!o) setPaymentFee(null) }}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>Record Payment</DialogTitle>
          </DialogHeader>
          {paymentFee && (
            <RecordPaymentModal fee={paymentFee} onClose={() => setPaymentFee(null)} />
          )}
        </DialogContent>
      </Dialog>
    </div>
  )
}
