import { useState } from 'react'
import { CheckCircle, XCircle, Clock, Download } from 'lucide-react'
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card'
import { Button } from '@/components/ui/button'
import { Badge, Skeleton } from '@/components/ui/form-elements'
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select'
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table'
import {
  useClasses,
  useAttendance,
  useAttendanceSummary,
  useEnrolledStudents,
  useBulkMarkAttendance,
} from '@/api/queries'
import { useDate } from '@/store/date-context'
import { useActiveAcademicYear } from '@/api/queries'
import type { AttendanceRecord, AttendanceStatus } from '@/types'
import { useToast } from '@/hooks/use-toast'
import apiClient from '@/lib/api-client'

const STATUS_OPTIONS: { value: AttendanceStatus; label: string; color: string }[] = [
  { value: 'present', label: 'Present', color: 'success' },
  { value: 'absent', label: 'Absent', color: 'destructive' },
  { value: 'late', label: 'Late', color: 'warning' },
  { value: 'excused', label: 'Excused', color: 'secondary' },
]

function StatusBadge({ status }: { status: AttendanceStatus }) {
  const opt = STATUS_OPTIONS.find((s) => s.value === status)
  if (!opt) return null
  return (
    <Badge variant={opt.color as 'success' | 'destructive' | 'warning' | 'secondary'}>
      {opt.label}
    </Badge>
  )
}

export function AttendancePage() {
  const { selectedDate } = useDate()
  const { data: activeYear } = useActiveAcademicYear()
  const { data: classes, isLoading: classesLoading } = useClasses(activeYear?.id)
  const [selectedClass, setSelectedClass] = useState<string>('')
  const [attendanceMap, setAttendanceMap] = useState<Record<string, AttendanceStatus>>({})
  const [mode, setMode] = useState<'view' | 'mark'>('view')
  const { toast } = useToast()
  const bulkMark = useBulkMarkAttendance()

  const { data: existingAttendance, isLoading: attLoading } = useAttendance(selectedClass, selectedDate)
  const { data: summary } = useAttendanceSummary(selectedClass, selectedDate)
  const { data: enrolled, isLoading: enrolledLoading } = useEnrolledStudents(selectedClass)

  const isAlreadyMarked = (existingAttendance?.length ?? 0) > 0

  const initMarkingMode = () => {
    if (!enrolled) return
    const initial: Record<string, AttendanceStatus> = {}
    enrolled.forEach((s) => {
      const existing = existingAttendance?.find((a) => a.student_id === s.id)
      initial[s.id] = existing?.status ?? 'present'
    })
    setAttendanceMap(initial)
    setMode('mark')
  }

  const handleSubmit = async () => {
    if (!selectedClass) return
    const records: AttendanceRecord[] = Object.entries(attendanceMap).map(([student_id, status]) => ({
      student_id,
      status,
    }))
    try {
      await bulkMark.mutateAsync({
        class_id: selectedClass,
        attendance_date: selectedDate,
        records,
        send_whatsapp_notifications: true,
      })
      toast({ title: 'Attendance saved', description: 'WhatsApp notifications sent to absent parents.', variant: 'success' })
      setMode('view')
    } catch {
      toast({ title: 'Error', description: 'Failed to save attendance.', variant: 'destructive' })
    }
  }

  const downloadPDF = async (type: 'daily' | 'monthly') => {
    const url = `/attendance/class/${selectedClass}/report/${type}?date=${selectedDate}`
    const response = await apiClient.get(url, { responseType: 'blob' })
    const blobUrl = URL.createObjectURL(new Blob([response.data], { type: 'application/pdf' }))
    const link = document.createElement('a')
    link.href = blobUrl
    link.download = `attendance_${type}_${selectedDate}.pdf`
    link.click()
  }

  const students = mode === 'mark' ? enrolled : enrolled

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <h1 className="text-2xl font-bold">Attendance</h1>
        {selectedClass && (
          <div className="flex gap-2">
            <Button variant="outline" size="sm" onClick={() => downloadPDF('daily')}>
              <Download size={14} className="mr-1" /> Daily PDF
            </Button>
            <Button variant="outline" size="sm" onClick={() => downloadPDF('monthly')}>
              <Download size={14} className="mr-1" /> Monthly PDF
            </Button>
          </div>
        )}
      </div>

      {/* Class selector */}
      <Card>
        <CardContent className="pt-6">
          <div className="flex flex-col gap-4 sm:flex-row sm:items-end">
            <div className="flex-1">
              <label className="text-sm font-medium mb-1.5 block">Select Class</label>
              {classesLoading ? (
                <Skeleton className="h-10 w-full" />
              ) : (
                <Select value={selectedClass} onValueChange={setSelectedClass}>
                  <SelectTrigger>
                    <SelectValue placeholder="Choose a class…" />
                  </SelectTrigger>
                  <SelectContent>
                    {classes?.map((cls) => (
                      <SelectItem key={cls.id} value={cls.id}>
                        {cls.display_name}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              )}
            </div>
            {selectedClass && mode === 'view' && (
              <Button onClick={initMarkingMode}>
                {isAlreadyMarked ? 'Edit Attendance' : 'Mark Attendance'}
              </Button>
            )}
            {mode === 'mark' && (
              <div className="flex gap-2">
                <Button variant="outline" onClick={() => setMode('view')}>Cancel</Button>
                <Button onClick={handleSubmit} disabled={bulkMark.isPending}>
                  {bulkMark.isPending ? 'Saving…' : 'Save Attendance'}
                </Button>
              </div>
            )}
          </div>
        </CardContent>
      </Card>

      {/* Summary */}
      {summary && selectedClass && (
        <div className="grid grid-cols-2 gap-3 sm:grid-cols-5">
          <Card>
            <CardContent className="pt-4 pb-3">
              <p className="text-xs text-muted-foreground">Total</p>
              <p className="text-xl font-bold">{summary.total_enrolled}</p>
            </CardContent>
          </Card>
          <Card>
            <CardContent className="pt-4 pb-3">
              <p className="text-xs text-muted-foreground">Present</p>
              <p className="text-xl font-bold text-green-600">{summary.present}</p>
            </CardContent>
          </Card>
          <Card>
            <CardContent className="pt-4 pb-3">
              <p className="text-xs text-muted-foreground">Absent</p>
              <p className="text-xl font-bold text-red-600">{summary.absent}</p>
            </CardContent>
          </Card>
          <Card>
            <CardContent className="pt-4 pb-3">
              <p className="text-xs text-muted-foreground">Late</p>
              <p className="text-xl font-bold text-yellow-600">{summary.late}</p>
            </CardContent>
          </Card>
          <Card>
            <CardContent className="pt-4 pb-3">
              <p className="text-xs text-muted-foreground">Attendance %</p>
              <p className="text-xl font-bold">{summary.attendance_percentage.toFixed(1)}%</p>
            </CardContent>
          </Card>
        </div>
      )}

      {/* Attendance table */}
      {selectedClass && (
        <Card>
          <CardHeader>
            <CardTitle className="text-base">
              {mode === 'mark' ? 'Mark Attendance' : 'Attendance Records'}
            </CardTitle>
          </CardHeader>
          <CardContent className="p-0">
            {attLoading || enrolledLoading ? (
              <div className="p-6 space-y-2">
                {Array.from({ length: 6 }).map((_, i) => (
                  <Skeleton key={i} className="h-10 w-full" />
                ))}
              </div>
            ) : (
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead className="w-16">Roll</TableHead>
                    <TableHead>Student Name</TableHead>
                    <TableHead>Status</TableHead>
                    {mode === 'view' && <TableHead>Parent Reason</TableHead>}
                    {mode === 'view' && <TableHead>WhatsApp</TableHead>}
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {(mode === 'mark' ? enrolled ?? [] : existingAttendance ?? []).map((record, idx) => {
                    const isAttendanceRecord = 'student_name' in record
                    const studentId = isAttendanceRecord ? record.student_id : (record as { id: string }).id
                    const name = isAttendanceRecord
                      ? record.student_name ?? '—'
                      : (record as { full_name: string }).full_name
                    const roll = isAttendanceRecord ? record.roll_number : idx + 1
                    const currentStatus = mode === 'mark'
                      ? attendanceMap[studentId]
                      : isAttendanceRecord ? record.status : undefined

                    return (
                      <TableRow key={studentId}>
                        <TableCell className="font-mono text-sm">{roll}</TableCell>
                        <TableCell className="font-medium">{name}</TableCell>
                        <TableCell>
                          {mode === 'mark' ? (
                            <Select
                              value={currentStatus}
                              onValueChange={(v) =>
                                setAttendanceMap((prev) => ({ ...prev, [studentId]: v as AttendanceStatus }))
                              }
                            >
                              <SelectTrigger className="w-32">
                                <SelectValue />
                              </SelectTrigger>
                              <SelectContent>
                                {STATUS_OPTIONS.map((s) => (
                                  <SelectItem key={s.value} value={s.value}>
                                    {s.label}
                                  </SelectItem>
                                ))}
                              </SelectContent>
                            </Select>
                          ) : isAttendanceRecord && currentStatus ? (
                            <StatusBadge status={currentStatus} />
                          ) : null}
                        </TableCell>
                        {mode === 'view' && isAttendanceRecord && (
                          <>
                            <TableCell className="text-sm text-muted-foreground">
                              {record.parent_reason ?? (record.status === 'absent' ? (
                                <span className="text-yellow-600 text-xs">Awaiting reply</span>
                              ) : '—')}
                            </TableCell>
                            <TableCell>
                              <Badge
                                variant={
                                  record.whatsapp_response_status === 'responded' || record.whatsapp_response_status === 'locked'
                                    ? 'success'
                                    : record.whatsapp_response_status === 'expired'
                                    ? 'destructive'
                                    : 'secondary'
                                }
                              >
                                {record.whatsapp_response_status}
                              </Badge>
                            </TableCell>
                          </>
                        )}
                      </TableRow>
                    )
                  })}
                </TableBody>
              </Table>
            )}
          </CardContent>
        </Card>
      )}
    </div>
  )
}
