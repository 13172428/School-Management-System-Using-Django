import { useRef, useState } from 'react'
import { Upload, Download, RefreshCw, RotateCcw } from 'lucide-react'
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card'
import { Button } from '@/components/ui/button'
import { Badge, Skeleton } from '@/components/ui/form-elements'
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select'
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table'
import { useCSVImportJobs, useRollbackCSVImport, useActiveAcademicYear } from '@/api/queries'
import type { CSVImportType } from '@/types'
import { formatDate } from '@/lib/utils'
import { useToast } from '@/hooks/use-toast'
import apiClient from '@/lib/api-client'

const IMPORT_TYPES: { value: CSVImportType; label: string; description: string }[] = [
  { value: 'students', label: 'Students', description: 'Bulk import student records' },
  { value: 'teachers', label: 'Teachers', description: 'Bulk import teacher records' },
  { value: 'fees', label: 'Fees', description: 'Bulk import fee structures' },
  { value: 'marks', label: 'Marks / Results', description: 'Bulk import exam results' },
]

function StatusBadge({ status }: { status: string }) {
  const variants: Record<string, string> = {
    completed: 'success',
    failed: 'destructive',
    processing: 'info',
    pending: 'secondary',
    rolled_back: 'warning',
  }
  return <Badge variant={(variants[status] ?? 'secondary') as 'success' | 'destructive' | 'info' | 'secondary' | 'warning'}>{status}</Badge>
}

export function CSVImportPage() {
  const fileRef = useRef<HTMLInputElement>(null)
  const [importType, setImportType] = useState<CSVImportType>('students')
  const [uploading, setUploading] = useState(false)
  const { toast } = useToast()
  const { data: activeYear } = useActiveAcademicYear()
  const { data: jobs, isLoading, refetch } = useCSVImportJobs()
  const rollback = useRollbackCSVImport()

  const downloadTemplate = async (type: CSVImportType) => {
    const res = await apiClient.get(`/csv-import/templates/${type}`, { responseType: 'blob' })
    const url = URL.createObjectURL(new Blob([res.data], { type: 'text/csv' }))
    const a = document.createElement('a')
    a.href = url
    a.download = `${type}_template.csv`
    a.click()
  }

  const handleUpload = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0]
    if (!file || !activeYear) return
    setUploading(true)
    try {
      const form = new FormData()
      form.append('file', file)
      await apiClient.post(
        `/csv-import/upload?import_type=${importType}&academic_year_id=${activeYear.id}`,
        form,
        { headers: { 'Content-Type': 'multipart/form-data' } },
      )
      toast({ title: 'Upload started', description: 'Processing your file…', variant: 'success' })
      refetch()
    } catch (err: unknown) {
      const detail = (err as { response?: { data?: { detail?: string } } })?.response?.data?.detail ?? 'Upload failed.'
      toast({ title: 'Upload failed', description: detail, variant: 'destructive' })
    } finally {
      setUploading(false)
      if (fileRef.current) fileRef.current.value = ''
    }
  }

  const handleRollback = async (id: string) => {
    try {
      const res = await rollback.mutateAsync(id)
      toast({ title: 'Rollback complete', description: res.message, variant: 'success' })
    } catch {
      toast({ title: 'Rollback failed', variant: 'destructive' })
    }
  }

  return (
    <div className="space-y-6">
      <h1 className="text-2xl font-bold">CSV Import Center</h1>

      {/* Import types + templates */}
      <div className="grid grid-cols-1 gap-4 sm:grid-cols-2 lg:grid-cols-4">
        {IMPORT_TYPES.map((type) => (
          <Card key={type.value}>
            <CardContent className="pt-4 pb-3">
              <p className="font-medium">{type.label}</p>
              <p className="text-xs text-muted-foreground mt-0.5">{type.description}</p>
              <Button
                variant="outline"
                size="sm"
                className="mt-3 w-full"
                onClick={() => downloadTemplate(type.value)}
              >
                <Download size={13} className="mr-1" /> Download Template
              </Button>
            </CardContent>
          </Card>
        ))}
      </div>

      {/* Upload */}
      <Card>
        <CardHeader>
          <CardTitle className="text-base">Upload CSV</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="flex flex-col gap-4 sm:flex-row sm:items-end">
            <div className="flex-1">
              <label className="text-sm font-medium mb-1.5 block">Import Type</label>
              <Select value={importType} onValueChange={(v) => setImportType(v as CSVImportType)}>
                <SelectTrigger>
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  {IMPORT_TYPES.map((t) => (
                    <SelectItem key={t.value} value={t.value}>{t.label}</SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
            <div className="flex gap-2">
              <Button
                onClick={() => fileRef.current?.click()}
                disabled={uploading || !activeYear}
              >
                <Upload size={14} className="mr-1" />
                {uploading ? 'Uploading…' : 'Choose File & Upload'}
              </Button>
              <input ref={fileRef} type="file" accept=".csv" className="hidden" onChange={handleUpload} />
            </div>
          </div>
          {!activeYear && (
            <p className="text-xs text-destructive mt-2">No active academic year found. Activate one first.</p>
          )}
        </CardContent>
      </Card>

      {/* Job history */}
      <Card>
        <CardHeader className="flex-row items-center justify-between">
          <CardTitle className="text-base">Import History</CardTitle>
          <Button variant="ghost" size="icon" onClick={() => refetch()}>
            <RefreshCw size={14} />
          </Button>
        </CardHeader>
        <CardContent className="p-0">
          {isLoading ? (
            <div className="p-6 space-y-2">
              {Array.from({ length: 4 }).map((_, i) => <Skeleton key={i} className="h-10 w-full" />)}
            </div>
          ) : (
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead>File</TableHead>
                  <TableHead>Type</TableHead>
                  <TableHead>Total</TableHead>
                  <TableHead>Success</TableHead>
                  <TableHead>Errors</TableHead>
                  <TableHead>Duplicates</TableHead>
                  <TableHead>Status</TableHead>
                  <TableHead>Date</TableHead>
                  <TableHead className="w-20">Actions</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {jobs?.map((job) => (
                  <TableRow key={job.id}>
                    <TableCell className="font-mono text-xs max-w-[160px] truncate">{job.filename}</TableCell>
                    <TableCell className="capitalize">{job.import_type}</TableCell>
                    <TableCell>{job.total_rows}</TableCell>
                    <TableCell className="text-green-600">{job.success_rows}</TableCell>
                    <TableCell className="text-red-600">{job.error_rows}</TableCell>
                    <TableCell className="text-yellow-600">{job.duplicate_rows}</TableCell>
                    <TableCell><StatusBadge status={job.status} /></TableCell>
                    <TableCell className="text-xs">{formatDate(job.created_at)}</TableCell>
                    <TableCell>
                      {job.status === 'completed' && (
                        <Button
                          variant="ghost"
                          size="icon"
                          title="Rollback import"
                          onClick={() => handleRollback(job.id)}
                          disabled={rollback.isPending}
                        >
                          <RotateCcw size={14} />
                        </Button>
                      )}
                    </TableCell>
                  </TableRow>
                ))}
                {jobs?.length === 0 && (
                  <TableRow>
                    <TableCell colSpan={9} className="text-center text-muted-foreground py-8">
                      No imports yet.
                    </TableCell>
                  </TableRow>
                )}
              </TableBody>
            </Table>
          )}
        </CardContent>
      </Card>
    </div>
  )
}
