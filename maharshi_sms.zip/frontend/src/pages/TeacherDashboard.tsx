import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card'
import { Badge, Skeleton } from '@/components/ui/form-elements'
import { useTeacherDashboard } from '@/api/queries'
import { useDate } from '@/store/date-context'
import { formatDate } from '@/lib/utils'
import { Link } from 'react-router-dom'
import { Button } from '@/components/ui/button'

export function TeacherDashboard() {
  const { selectedDate } = useDate()
  const { data: stats, isLoading } = useTeacherDashboard(selectedDate)

  if (isLoading) {
    return (
      <div className="space-y-4">
        {Array.from({ length: 3 }).map((_, i) => (
          <Skeleton key={i} className="h-32 rounded-lg" />
        ))}
      </div>
    )
  }

  if (!stats) return null

  return (
    <div className="space-y-6">
      <h1 className="text-2xl font-bold">Dashboard — {formatDate(selectedDate)}</h1>

      {/* Today's classes */}
      <Card>
        <CardHeader>
          <CardTitle className="text-base">Today's Classes</CardTitle>
        </CardHeader>
        <CardContent>
          {stats.todays_classes.length === 0 ? (
            <p className="text-sm text-muted-foreground">No classes scheduled for today.</p>
          ) : (
            <div className="space-y-2">
              {stats.todays_classes.map((cls) => (
                <div key={cls.class_id} className="flex items-center justify-between rounded-md border p-3">
                  <div>
                    <p className="font-medium">{cls.class_name}</p>
                    <p className="text-sm text-muted-foreground">{cls.subject} · {cls.start_time} – {cls.end_time}</p>
                  </div>
                  <div className="flex items-center gap-2">
                    <Badge variant={cls.is_attended_marked ? 'success' : 'warning'}>
                      {cls.is_attended_marked ? 'Marked' : 'Pending'}
                    </Badge>
                    {!cls.is_attended_marked && (
                      <Button size="sm" asChild>
                        <Link to="/attendance">Mark Now</Link>
                      </Button>
                    )}
                  </div>
                </div>
              ))}
            </div>
          )}
        </CardContent>
      </Card>

      {/* Attendance summary */}
      {stats.attendance_summary.length > 0 && (
        <Card>
          <CardHeader>
            <CardTitle className="text-base">Attendance Summary</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-2">
              {stats.attendance_summary.map((s) => (
                <div key={s.class_id} className="flex items-center gap-3">
                  <span className="w-32 text-sm font-medium truncate">{s.class_name}</span>
                  <div className="flex-1 bg-muted rounded-full h-2 overflow-hidden">
                    <div
                      className="h-full bg-green-500 rounded-full"
                      style={{ width: `${s.percentage}%` }}
                    />
                  </div>
                  <span className="text-xs text-muted-foreground w-16 text-right">
                    {s.present}/{s.total} ({s.percentage.toFixed(0)}%)
                  </span>
                </div>
              ))}
            </div>
          </CardContent>
        </Card>
      )}

      {/* Upcoming exams */}
      {stats.upcoming_exams.length > 0 && (
        <Card>
          <CardHeader>
            <CardTitle className="text-base">Upcoming Exams</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-2">
              {stats.upcoming_exams.map((exam) => (
                <div key={exam.id} className="flex items-center justify-between">
                  <span className="text-sm font-medium">{exam.name}</span>
                  <div className="flex items-center gap-2">
                    <Badge variant="secondary">{exam.exam_type}</Badge>
                    <span className="text-xs text-muted-foreground">{formatDate(exam.start_date)}</span>
                  </div>
                </div>
              ))}
            </div>
          </CardContent>
        </Card>
      )}

      {/* Pending tasks */}
      {stats.pending_attendance_classes.length > 0 && (
        <Card className="border-yellow-200 bg-yellow-50">
          <CardHeader>
            <CardTitle className="text-base text-yellow-800">Pending Attendance</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-1">
              {stats.pending_attendance_classes.map((c) => (
                <div key={c.class_id} className="flex items-center justify-between">
                  <span className="text-sm text-yellow-800">{c.class_name}</span>
                  <Button size="sm" variant="outline" asChild>
                    <Link to="/attendance">Mark Now</Link>
                  </Button>
                </div>
              ))}
            </div>
          </CardContent>
        </Card>
      )}
    </div>
  )
}
