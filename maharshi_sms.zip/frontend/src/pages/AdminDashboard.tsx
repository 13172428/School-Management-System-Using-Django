import { Users, UserCheck, UserX, GraduationCap, CreditCard, Bell, TrendingUp } from 'lucide-react'
import {
  ResponsiveContainer,
  BarChart,
  Bar,
  XAxis,
  YAxis,
  Tooltip,
  Cell,
} from 'recharts'
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card'
import { Skeleton } from '@/components/ui/form-elements'
import { Badge } from '@/components/ui/form-elements'
import { useAdminDashboard } from '@/api/queries'
import { useDate } from '@/store/date-context'
import { formatCurrency, formatDate, formatPercent } from '@/lib/utils'

function StatCard({
  title,
  value,
  sub,
  icon,
  color = 'blue',
}: {
  title: string
  value: string | number
  sub?: string
  icon: React.ReactNode
  color?: 'blue' | 'green' | 'red' | 'yellow'
}) {
  const colors = {
    blue: 'text-blue-600 bg-blue-50',
    green: 'text-green-600 bg-green-50',
    red: 'text-red-600 bg-red-50',
    yellow: 'text-yellow-600 bg-yellow-50',
  }
  return (
    <Card>
      <CardContent className="pt-6">
        <div className="flex items-start justify-between">
          <div>
            <p className="text-sm text-muted-foreground">{title}</p>
            <p className="text-2xl font-bold mt-1">{value}</p>
            {sub && <p className="text-xs text-muted-foreground mt-1">{sub}</p>}
          </div>
          <div className={`rounded-full p-2 ${colors[color]}`}>{icon}</div>
        </div>
      </CardContent>
    </Card>
  )
}

export function AdminDashboard() {
  const { selectedDate } = useDate()
  const { data: stats, isLoading } = useAdminDashboard(selectedDate)

  if (isLoading) {
    return (
      <div className="space-y-6">
        <div className="grid grid-cols-2 gap-4 lg:grid-cols-4">
          {Array.from({ length: 8 }).map((_, i) => (
            <Skeleton key={i} className="h-28 rounded-lg" />
          ))}
        </div>
      </div>
    )
  }

  if (!stats) return null

  const attendanceData = [
    { name: 'Present', value: stats.present_today, fill: '#22c55e' },
    { name: 'Absent', value: stats.absent_today, fill: '#ef4444' },
  ]

  const feeData = [
    { name: 'Collected', value: stats.collected_fees },
    { name: 'Pending', value: stats.pending_fees },
    { name: 'Overdue', value: stats.overdue_fees },
  ]

  return (
    <div className="space-y-6">
      {/* Holiday banner */}
      {stats.is_today_holiday && (
        <div className="rounded-lg bg-yellow-50 border border-yellow-200 px-4 py-3 text-yellow-800 flex items-center gap-2">
          <span className="font-medium">🎉 Today is a holiday:</span>
          <span>{stats.holiday_name}</span>
        </div>
      )}

      <h1 className="text-2xl font-bold">Dashboard — {formatDate(selectedDate)}</h1>

      {/* Student stats */}
      <div>
        <h2 className="text-sm font-semibold text-muted-foreground uppercase tracking-wide mb-3">Students</h2>
        <div className="grid grid-cols-2 gap-4 lg:grid-cols-4">
          <StatCard title="Total Students" value={stats.total_students} icon={<Users size={18} />} color="blue" />
          <StatCard title="Active Students" value={stats.active_students} icon={<UserCheck size={18} />} color="green" />
          <StatCard
            title="Present Today"
            value={stats.present_today}
            sub={formatPercent(stats.attendance_percentage)}
            icon={<UserCheck size={18} />}
            color="green"
          />
          <StatCard title="Absent Today" value={stats.absent_today} icon={<UserX size={18} />} color="red" />
        </div>
      </div>

      {/* Fee stats */}
      <div>
        <h2 className="text-sm font-semibold text-muted-foreground uppercase tracking-wide mb-3">Fees</h2>
        <div className="grid grid-cols-2 gap-4 lg:grid-cols-4">
          <StatCard title="Total Fees" value={formatCurrency(stats.total_fees)} icon={<CreditCard size={18} />} color="blue" />
          <StatCard title="Collected" value={formatCurrency(stats.collected_fees)} icon={<TrendingUp size={18} />} color="green" />
          <StatCard title="Pending" value={formatCurrency(stats.pending_fees)} icon={<CreditCard size={18} />} color="yellow" />
          <StatCard title="Overdue" value={formatCurrency(stats.overdue_fees)} icon={<CreditCard size={18} />} color="red" />
        </div>
      </div>

      {/* Teachers + Notifications */}
      <div className="grid grid-cols-2 gap-4 lg:grid-cols-4">
        <StatCard title="Total Teachers" value={stats.total_teachers} icon={<GraduationCap size={18} />} color="blue" />
        <StatCard title="Active Teachers" value={stats.active_teachers} icon={<GraduationCap size={18} />} color="green" />
        <StatCard title="Messages Sent" value={stats.notifications_sent} icon={<Bell size={18} />} color="green" />
        <StatCard title="Failed Messages" value={stats.notifications_failed} icon={<Bell size={18} />} color="red" />
      </div>

      {/* Charts */}
      <div className="grid grid-cols-1 gap-6 lg:grid-cols-2">
        <Card>
          <CardHeader>
            <CardTitle className="text-base">Attendance Today</CardTitle>
          </CardHeader>
          <CardContent>
            <ResponsiveContainer width="100%" height={200}>
              <BarChart data={attendanceData}>
                <XAxis dataKey="name" />
                <YAxis />
                <Tooltip />
              <Bar dataKey="value" radius={[4, 4, 0, 0]}>
                  {attendanceData.map((entry, i) => (
                    <Cell key={i} fill={entry.fill} />
                  ))}
                </Bar>
              </BarChart>
            </ResponsiveContainer>
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle className="text-base">Fee Collection (₹)</CardTitle>
          </CardHeader>
          <CardContent>
            <ResponsiveContainer width="100%" height={200}>
              <BarChart data={feeData}>
                <XAxis dataKey="name" />
                <YAxis tickFormatter={(v) => `₹${(v / 1000).toFixed(0)}k`} />
                <Tooltip formatter={(v) => formatCurrency(v as number)} />
                <Bar dataKey="value" fill="#3b82f6" radius={[4, 4, 0, 0]} />
              </BarChart>
            </ResponsiveContainer>
          </CardContent>
        </Card>
      </div>

      {/* Upcoming holidays */}
      {stats.upcoming_holidays.length > 0 && (
        <Card>
          <CardHeader>
            <CardTitle className="text-base">Upcoming Holidays</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-2">
              {stats.upcoming_holidays.map((h) => (
                <div key={h.id} className="flex items-center justify-between py-1">
                  <span className="text-sm font-medium">{h.name}</span>
                  <div className="flex items-center gap-2">
                    <Badge variant="outline">{h.holiday_type}</Badge>
                    <span className="text-xs text-muted-foreground">
                      {formatDate(h.start_date)}
                      {h.duration_days > 1 && ` – ${formatDate(h.end_date)}`}
                    </span>
                  </div>
                </div>
              ))}
            </div>
          </CardContent>
        </Card>
      )}
    </div>
  )
}
