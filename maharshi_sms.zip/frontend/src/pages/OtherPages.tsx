// Combined page file: TeachersPage, ExamsPage, NotificationsPage
import { useState } from 'react'
import { Plus, Search } from 'lucide-react'
import { Card, CardContent } from '@/components/ui/card'
import { Button } from '@/components/ui/button'
import { Input, Badge, Skeleton } from '@/components/ui/form-elements'
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table'
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter } from '@/components/ui/dialog'
import {
  useTeachers,
  useCreateTeacher,
  useUpdateTeacher,
  useExams,
  useNotifications,
  useNotificationAnalytics,
  useActiveAcademicYear,
} from '@/api/queries'
import type { Teacher } from '@/types'
import { capitalize, formatDate } from '@/lib/utils'
import { useToast } from '@/hooks/use-toast'

// ─── Teacher Form ─────────────────────────────────────────────────────────────

function TeacherForm({ teacher, onClose }: { teacher?: Teacher; onClose: () => void }) {
  const { toast } = useToast()
  const create = useCreateTeacher()
  const update = useUpdateTeacher()

  const [form, setForm] = useState({
    employee_id: teacher?.employee_id ?? '',
    first_name: teacher?.first_name ?? '',
    last_name: teacher?.last_name ?? '',
    email: teacher?.email ?? '',
    phone: teacher?.phone ?? '',
    whatsapp_number: teacher?.whatsapp_number ?? '',
    qualification: teacher?.qualification ?? '',
    joining_date: teacher?.joining_date ?? '',
  })

  const handleSubmit = async () => {
    try {
      if (teacher) {
        await update.mutateAsync({ id: teacher.id, data: form })
      } else {
        await create.mutateAsync(form)
      }
      toast({ title: teacher ? 'Teacher updated' : 'Teacher added', variant: 'success' })
      onClose()
    } catch (e: unknown) {
      const msg =
        (e as { response?: { data?: { detail?: string } } })?.response?.data?.detail ?? 'Failed.'
      toast({ title: 'Error', description: msg, variant: 'destructive' })
    }
  }

  const isPending = create.isPending || update.isPending

  return (
    <div className="space-y-4">
      <div className="grid grid-cols-2 gap-3">
        {[
          { label: 'Employee ID *', key: 'employee_id', disabled: !!teacher },
          { label: 'Joining Date', key: 'joining_date', type: 'date' },
          { label: 'First Name *', key: 'first_name' },
          { label: 'Last Name *', key: 'last_name' },
          { label: 'Email *', key: 'email', type: 'email' },
          { label: 'Phone', key: 'phone' },
          { label: 'WhatsApp No.', key: 'whatsapp_number' },
          { label: 'Qualification', key: 'qualification' },
        ].map(({ label, key, type = 'text', disabled }) => (
          <div key={key}>
            <label className="text-sm font-medium">{label}</label>
            <Input
              type={type}
              value={form[key as keyof typeof form]}
              onChange={(e) => setForm((p) => ({ ...p, [key]: e.target.value }))}
              className="mt-1"
              disabled={disabled}
            />
          </div>
        ))}
      </div>
      <DialogFooter>
        <Button variant="outline" onClick={onClose}>Cancel</Button>
        <Button onClick={handleSubmit} disabled={isPending}>
          {isPending ? 'Saving…' : teacher ? 'Update' : 'Add Teacher'}
        </Button>
      </DialogFooter>
    </div>
  )
}

// ─── Teachers Page ────────────────────────────────────────────────────────────

export function TeachersPage() {
  const [search, setSearch] = useState('')
  const [showAdd, setShowAdd] = useState(false)
  const [editTeacher, setEditTeacher] = useState<Teacher | null>(null)
  const { data: teachers, isLoading } = useTeachers({ search: search || undefined })

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <h1 className="text-2xl font-bold">Teachers</h1>
        <Button onClick={() => setShowAdd(true)}>
          <Plus size={16} className="mr-1" /> Add Teacher
        </Button>
      </div>

      <Card>
        <CardContent className="pt-4 pb-4">
          <div className="relative">
            <Search size={16} className="absolute left-3 top-3 text-muted-foreground" />
            <Input
              placeholder="Search teachers…"
              value={search}
              onChange={(e) => setSearch(e.target.value)}
              className="pl-9"
            />
          </div>
        </CardContent>
      </Card>

      <Card>
        <CardContent className="p-0">
          {isLoading ? (
            <div className="p-6 space-y-2">
              {Array.from({ length: 6 }).map((_, i) => (
                <Skeleton key={i} className="h-10 w-full" />
              ))}
            </div>
          ) : (
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead>Emp. ID</TableHead>
                  <TableHead>Name</TableHead>
                  <TableHead>Email</TableHead>
                  <TableHead>Phone</TableHead>
                  <TableHead>Joining Date</TableHead>
                  <TableHead>Status</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {teachers?.map((t) => (
                  <TableRow
                    key={t.id}
                    className="cursor-pointer"
                    onClick={() => setEditTeacher(t)}
                  >
                    <TableCell className="font-mono text-sm">{t.employee_id}</TableCell>
                    <TableCell className="font-medium">{t.full_name}</TableCell>
                    <TableCell className="text-sm">{t.email}</TableCell>
                    <TableCell className="text-sm">{t.phone ?? '—'}</TableCell>
                    <TableCell>{formatDate(t.joining_date)}</TableCell>
                    <TableCell>
                      <Badge variant={t.is_active ? 'success' : 'secondary'}>
                        {t.is_active ? 'Active' : 'Inactive'}
                      </Badge>
                    </TableCell>
                  </TableRow>
                ))}
                {teachers?.length === 0 && (
                  <TableRow>
                    <TableCell colSpan={6} className="text-center text-muted-foreground py-8">
                      No teachers found.
                    </TableCell>
                  </TableRow>
                )}
              </TableBody>
            </Table>
          )}
        </CardContent>
      </Card>

      <Dialog open={showAdd} onOpenChange={setShowAdd}>
        <DialogContent className="max-w-lg">
          <DialogHeader>
            <DialogTitle>Add Teacher</DialogTitle>
          </DialogHeader>
          <TeacherForm onClose={() => setShowAdd(false)} />
        </DialogContent>
      </Dialog>

      <Dialog open={!!editTeacher} onOpenChange={(o) => { if (!o) setEditTeacher(null) }}>
        <DialogContent className="max-w-lg">
          <DialogHeader>
            <DialogTitle>Edit Teacher — {editTeacher?.full_name}</DialogTitle>
          </DialogHeader>
          {editTeacher && (
            <TeacherForm teacher={editTeacher} onClose={() => setEditTeacher(null)} />
          )}
        </DialogContent>
      </Dialog>
    </div>
  )
}

// ─── Exams Page ───────────────────────────────────────────────────────────────

export function ExamsPage() {
  const { data: activeYear } = useActiveAcademicYear()
  const { data: exams, isLoading } = useExams(activeYear?.id)

  return (
    <div className="space-y-6">
      <h1 className="text-2xl font-bold">Exams</h1>
      <Card>
        <CardContent className="p-0">
          {isLoading ? (
            <div className="p-6 space-y-2">
              {Array.from({ length: 4 }).map((_, i) => (
                <Skeleton key={i} className="h-10 w-full" />
              ))}
            </div>
          ) : (
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead>Name</TableHead>
                  <TableHead>Type</TableHead>
                  <TableHead>Start</TableHead>
                  <TableHead>End</TableHead>
                  <TableHead>Published</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {exams?.map((exam) => (
                  <TableRow key={exam.id}>
                    <TableCell className="font-medium">{exam.name}</TableCell>
                    <TableCell>{capitalize(exam.exam_type)}</TableCell>
                    <TableCell>{formatDate(exam.start_date)}</TableCell>
                    <TableCell>{formatDate(exam.end_date)}</TableCell>
                    <TableCell>
                      <Badge variant={exam.is_published ? 'success' : 'secondary'}>
                        {exam.is_published ? 'Yes' : 'Draft'}
                      </Badge>
                    </TableCell>
                  </TableRow>
                ))}
                {exams?.length === 0 && (
                  <TableRow>
                    <TableCell colSpan={5} className="text-center text-muted-foreground py-8">
                      No exams found.
                    </TableCell>
                  </TableRow>
                )}
              </TableBody>
            </Table>
          )}
        </CardContent>
      </Card>
    </div>
  )
}

// ─── Notifications Page ───────────────────────────────────────────────────────

export function NotificationsPage() {
  const { data: notifications, isLoading } = useNotifications()
  const { data: analytics } = useNotificationAnalytics(undefined)

  const sentCount =
    analytics?.by_status.find((s) => s.status === 'sent')?.count ?? 0
  const failedCount =
    analytics?.by_status.find((s) => s.status === 'failed')?.count ?? 0

  return (
    <div className="space-y-6">
      <h1 className="text-2xl font-bold">Notifications</h1>

      <div className="grid grid-cols-2 gap-4 lg:grid-cols-4">
        <Card>
          <CardContent className="pt-5 pb-4">
            <p className="text-xs text-muted-foreground">Messages Sent</p>
            <p className="text-xl font-bold text-green-600">{sentCount}</p>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="pt-5 pb-4">
            <p className="text-xs text-muted-foreground">Failed</p>
            <p className="text-xl font-bold text-red-600">{failedCount}</p>
          </CardContent>
        </Card>
      </div>

      <Card>
        <CardContent className="p-0">
          {isLoading ? (
            <div className="p-6 space-y-2">
              {Array.from({ length: 5 }).map((_, i) => (
                <Skeleton key={i} className="h-10 w-full" />
              ))}
            </div>
          ) : (
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead>Type</TableHead>
                  <TableHead>Channel</TableHead>
                  <TableHead>Recipient</TableHead>
                  <TableHead>Status</TableHead>
                  <TableHead>Sent At</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {notifications?.map((n) => (
                  <TableRow key={n.id}>
                    <TableCell className="capitalize">{n.notification_type}</TableCell>
                    <TableCell className="capitalize">{n.channel}</TableCell>
                    <TableCell className="text-sm">{n.recipient_number ?? '—'}</TableCell>
                    <TableCell>
                      <Badge
                        variant={
                          n.status === 'sent' || n.status === 'delivered'
                            ? 'success'
                            : n.status === 'failed'
                            ? 'destructive'
                            : 'secondary'
                        }
                      >
                        {n.status}
                      </Badge>
                    </TableCell>
                    <TableCell className="text-xs">
                      {n.sent_at ? formatDate(n.sent_at) : '—'}
                    </TableCell>
                  </TableRow>
                ))}
                {notifications?.length === 0 && (
                  <TableRow>
                    <TableCell colSpan={5} className="text-center text-muted-foreground py-8">
                      No notifications yet.
                    </TableCell>
                  </TableRow>
                )}
              </TableBody>
            </Table>
          )}
        </CardContent>
      </Card>
    </div>
  )
}
