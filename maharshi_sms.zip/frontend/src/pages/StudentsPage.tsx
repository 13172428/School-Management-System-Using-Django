import { useState } from 'react'
import { Plus, Search, Eye } from 'lucide-react'
import { Card, CardContent } from '@/components/ui/card'
import { Button } from '@/components/ui/button'
import { Input, Badge, Skeleton } from '@/components/ui/form-elements'
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table'
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogFooter,
} from '@/components/ui/dialog'
import { useStudents, useCreateStudent, useUpdateStudent, useActiveAcademicYear } from '@/api/queries'
import type { Student } from '@/types'
import { formatDate } from '@/lib/utils'
import { useToast } from '@/hooks/use-toast'

function StudentForm({
  student,
  academicYearId,
  onClose,
}: {
  student?: Student
  academicYearId: string
  onClose: () => void
}) {
  const { toast } = useToast()
  const create = useCreateStudent()
  const update = useUpdateStudent()

  const [form, setForm] = useState({
    admission_number: student?.admission_number ?? '',
    first_name: student?.first_name ?? '',
    last_name: student?.last_name ?? '',
    date_of_birth: student?.date_of_birth ?? '',
    gender: student?.gender ?? '',
    blood_group: student?.blood_group ?? '',
    admission_date: student?.admission_date ?? '',
  })

  const handleSubmit = async () => {
    try {
      if (student) {
        await update.mutateAsync({ id: student.id, data: form })
        toast({ title: 'Student updated', variant: 'success' })
      } else {
        await create.mutateAsync({ ...form, academic_year_id: academicYearId, parent_contacts: [] })
        toast({ title: 'Student added', variant: 'success' })
      }
      onClose()
    } catch (e: unknown) {
      const msg = (e as { response?: { data?: { detail?: string } } })?.response?.data?.detail ?? 'Failed to save student.'
      toast({ title: 'Error', description: msg, variant: 'destructive' })
    }
  }

  const isPending = create.isPending || update.isPending

  return (
    <div className="space-y-4">
      <div className="grid grid-cols-2 gap-3">
        <div>
          <label className="text-sm font-medium">Admission No.</label>
          <Input
            value={form.admission_number}
            onChange={(e) => setForm((p) => ({ ...p, admission_number: e.target.value }))}
            className="mt-1"
            disabled={!!student}
          />
        </div>
        <div>
          <label className="text-sm font-medium">Date of Birth</label>
          <Input
            type="date"
            value={form.date_of_birth}
            onChange={(e) => setForm((p) => ({ ...p, date_of_birth: e.target.value }))}
            className="mt-1"
          />
        </div>
        <div>
          <label className="text-sm font-medium">First Name</label>
          <Input
            value={form.first_name}
            onChange={(e) => setForm((p) => ({ ...p, first_name: e.target.value }))}
            className="mt-1"
          />
        </div>
        <div>
          <label className="text-sm font-medium">Last Name</label>
          <Input
            value={form.last_name}
            onChange={(e) => setForm((p) => ({ ...p, last_name: e.target.value }))}
            className="mt-1"
          />
        </div>
        <div>
          <label className="text-sm font-medium">Gender</label>
          <select
            value={form.gender}
            onChange={(e) => setForm((p) => ({ ...p, gender: e.target.value }))}
            className="mt-1 flex h-10 w-full rounded-md border border-input bg-background px-3 py-2 text-sm"
          >
            <option value="">Select…</option>
            <option value="male">Male</option>
            <option value="female">Female</option>
            <option value="other">Other</option>
          </select>
        </div>
        <div>
          <label className="text-sm font-medium">Blood Group</label>
          <Input
            value={form.blood_group}
            onChange={(e) => setForm((p) => ({ ...p, blood_group: e.target.value }))}
            placeholder="e.g. B+"
            className="mt-1"
          />
        </div>
      </div>
      <DialogFooter>
        <Button variant="outline" onClick={onClose}>Cancel</Button>
        <Button onClick={handleSubmit} disabled={isPending}>
          {isPending ? 'Saving…' : student ? 'Update' : 'Add Student'}
        </Button>
      </DialogFooter>
    </div>
  )
}

export function StudentsPage() {
  const { data: activeYear } = useActiveAcademicYear()
  const [search, setSearch] = useState('')
  const [showAdd, setShowAdd] = useState(false)
  const [editStudent, setEditStudent] = useState<Student | null>(null)

  const { data: students, isLoading } = useStudents({
    academic_year_id: activeYear?.id,
    search: search || undefined,
  })

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <h1 className="text-2xl font-bold">Students</h1>
        <Button onClick={() => setShowAdd(true)}>
          <Plus size={16} className="mr-1" /> Add Student
        </Button>
      </div>

      {/* Search */}
      <Card>
        <CardContent className="pt-4 pb-4">
          <div className="relative">
            <Search size={16} className="absolute left-3 top-3 text-muted-foreground" />
            <Input
              placeholder="Search by name or admission number…"
              value={search}
              onChange={(e) => setSearch(e.target.value)}
              className="pl-9"
            />
          </div>
        </CardContent>
      </Card>

      {/* Table */}
      <Card>
        <CardContent className="p-0">
          {isLoading ? (
            <div className="p-6 space-y-2">
              {Array.from({ length: 8 }).map((_, i) => <Skeleton key={i} className="h-10 w-full" />)}
            </div>
          ) : (
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead>Admission No.</TableHead>
                  <TableHead>Name</TableHead>
                  <TableHead>Gender</TableHead>
                  <TableHead>Date of Birth</TableHead>
                  <TableHead>Status</TableHead>
                  <TableHead className="w-20">Actions</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {students?.map((student) => (
                  <TableRow key={student.id}>
                    <TableCell className="font-mono text-sm">{student.admission_number}</TableCell>
                    <TableCell className="font-medium">{student.full_name}</TableCell>
                    <TableCell className="capitalize">{student.gender ?? '—'}</TableCell>
                    <TableCell>{formatDate(student.date_of_birth)}</TableCell>
                    <TableCell>
                      <Badge variant={student.is_active ? 'success' : 'secondary'}>
                        {student.is_active ? 'Active' : 'Inactive'}
                      </Badge>
                    </TableCell>
                    <TableCell>
                      <Button
                        variant="ghost"
                        size="icon"
                        onClick={() => setEditStudent(student)}
                      >
                        <Eye size={14} />
                      </Button>
                    </TableCell>
                  </TableRow>
                ))}
                {students?.length === 0 && (
                  <TableRow>
                    <TableCell colSpan={6} className="text-center text-muted-foreground py-8">
                      No students found.
                    </TableCell>
                  </TableRow>
                )}
              </TableBody>
            </Table>
          )}
        </CardContent>
      </Card>

      {/* Add dialog */}
      <Dialog open={showAdd} onOpenChange={setShowAdd}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>Add Student</DialogTitle>
          </DialogHeader>
          {activeYear && (
            <StudentForm academicYearId={activeYear.id} onClose={() => setShowAdd(false)} />
          )}
        </DialogContent>
      </Dialog>

      {/* Edit dialog */}
      <Dialog open={!!editStudent} onOpenChange={(o) => { if (!o) setEditStudent(null) }}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>Edit Student — {editStudent?.full_name}</DialogTitle>
          </DialogHeader>
          {activeYear && editStudent && (
            <StudentForm
              student={editStudent}
              academicYearId={activeYear.id}
              onClose={() => setEditStudent(null)}
            />
          )}
        </DialogContent>
      </Dialog>
    </div>
  )
}
