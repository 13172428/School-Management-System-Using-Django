import React, { createContext, useContext, useState, type ReactNode } from 'react'
import { toISODate } from '@/lib/utils'

interface DateContextValue {
  selectedDate: string        // ISO date string YYYY-MM-DD
  setSelectedDate: (date: string) => void
  isToday: boolean
  goToToday: () => void
  goToPrevDay: () => void
  goToNextDay: () => void
}

const DateContext = createContext<DateContextValue | null>(null)

export function DateProvider({ children }: { children: ReactNode }) {
  const [selectedDate, setSelectedDate] = useState<string>(toISODate(new Date()))

  const isToday = selectedDate === toISODate(new Date())

  const goToToday = () => setSelectedDate(toISODate(new Date()))

  const goToPrevDay = () => {
    const d = new Date(selectedDate)
    d.setDate(d.getDate() - 1)
    setSelectedDate(toISODate(d))
  }

  const goToNextDay = () => {
    const d = new Date(selectedDate)
    d.setDate(d.getDate() + 1)
    setSelectedDate(toISODate(d))
  }

  return (
    <DateContext.Provider
      value={{ selectedDate, setSelectedDate, isToday, goToToday, goToPrevDay, goToNextDay }}
    >
      {children}
    </DateContext.Provider>
  )
}

export function useDate() {
  const ctx = useContext(DateContext)
  if (!ctx) throw new Error('useDate must be used within DateProvider')
  return ctx
}
