import { ClerkProvider, SignIn, SignedIn, SignedOut, useAuth, useUser } from '@clerk/clerk-react'
import { QueryClient, QueryClientProvider } from '@tanstack/react-query'
import { ReactQueryDevtools } from '@tanstack/react-query-devtools'
import { BrowserRouter, Route, Routes, Navigate } from 'react-router-dom'
import { useEffect } from 'react'

import { DateProvider } from '@/store/date-context'
import { setTokenGetter } from '@/lib/api-client'
import { AppShell } from '@/components/common/AppShell'
import { Toaster } from '@/hooks/use-toast'

import { AdminDashboard } from '@/pages/AdminDashboard'
import { TeacherDashboard } from '@/pages/TeacherDashboard'
import { AttendancePage } from '@/pages/AttendancePage'
import { StudentsPage } from '@/pages/StudentsPage'
import { HolidaysPage } from '@/pages/HolidaysPage'
import { FeesPage } from '@/pages/FeesPage'
import { CSVImportPage } from '@/pages/CSVImportPage'
import { TeachersPage, ExamsPage, NotificationsPage } from '@/pages/OtherPages'

const CLERK_PUBLISHABLE_KEY = import.meta.env.VITE_CLERK_PUBLISHABLE_KEY

if (!CLERK_PUBLISHABLE_KEY) {
  throw new Error('Missing VITE_CLERK_PUBLISHABLE_KEY in environment.')
}

const queryClient = new QueryClient({
  defaultOptions: {
    queries: {
      staleTime: 60 * 1000, // 1 minute
      retry: 1,
    },
  },
})

// Sets the Clerk token getter on the API client once signed in
function ClerkTokenBridge() {
  const { getToken } = useAuth()
  useEffect(() => {
    setTokenGetter(() => getToken())
  }, [getToken])
  return null
}

type UserRole = 'admin' | 'teacher'

function AppRoutes() {
  const { user } = useUser()
  const role = (user?.publicMetadata?.role as UserRole) ?? 'teacher'

  return (
    <DateProvider>
      <AppShell role={role}>
        <Routes>
          <Route
            path="/"
            element={role === 'admin' ? <AdminDashboard /> : <TeacherDashboard />}
          />
          {/* Admin-only */}
          {role === 'admin' && (
            <>
              <Route path="/students" element={<StudentsPage />} />
              <Route path="/teachers" element={<TeachersPage />} />
              <Route path="/classes" element={<div className="p-8 text-muted-foreground">Classes page — coming soon</div>} />
              <Route path="/fees" element={<FeesPage />} />
              <Route path="/holidays" element={<HolidaysPage />} />
              <Route path="/notifications" element={<NotificationsPage />} />
              <Route path="/csv-import" element={<CSVImportPage />} />
              <Route path="/settings" element={<div className="p-8 text-muted-foreground">Settings — coming soon</div>} />
            </>
          )}
          {/* Shared */}
          <Route path="/attendance" element={<AttendancePage />} />
          <Route path="/exams" element={<ExamsPage />} />
          {/* Fallback */}
          <Route path="*" element={<Navigate to="/" replace />} />
        </Routes>
      </AppShell>
    </DateProvider>
  )
}

export default function App() {
  return (
    <ClerkProvider publishableKey={CLERK_PUBLISHABLE_KEY}>
      <QueryClientProvider client={queryClient}>
        <BrowserRouter>
          <SignedOut>
            <div className="flex min-h-screen items-center justify-center bg-muted/40">
              <SignIn />
            </div>
          </SignedOut>
          <SignedIn>
            <ClerkTokenBridge />
            <AppRoutes />
          </SignedIn>
        </BrowserRouter>
        <Toaster />
        <ReactQueryDevtools initialIsOpen={false} />
      </QueryClientProvider>
    </ClerkProvider>
  )
}
