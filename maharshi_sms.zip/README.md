# Maharshi High School — School Management System

A production-ready, cloud-based School Management System built for Maharshi High School.

## Architecture

```
sms/
├── backend/          # FastAPI + SQLAlchemy + PostgreSQL
│   ├── app/
│   │   ├── api/v1/endpoints/   # 16 endpoint modules
│   │   ├── core/               # Config, logging, security (Clerk JWT)
│   │   ├── db/                 # Async SQLAlchemy engine
│   │   ├── models/             # 20+ SQLAlchemy models
│   │   ├── schemas/            # Pydantic v2 schemas
│   │   ├── services/           # Business logic
│   │   └── tasks/              # Celery async tasks
│   ├── alembic/                # Database migrations
│   └── tests/                  # pytest async test suite
├── frontend/         # React + TypeScript + Vite + Tailwind
│   └── src/
│       ├── api/               # React Query hooks for all endpoints
│       ├── components/        # shadcn/ui component library
│       ├── pages/             # Page components
│       └── store/             # Date context (global date selector)
└── docker-compose.yml
```

## Stack

| Layer | Technology |
|-------|-----------|
| Frontend | React 18, TypeScript, Vite, TailwindCSS, shadcn/ui, React Query |
| Backend | FastAPI, SQLAlchemy 2 (async), Alembic |
| Auth | Clerk (JWT verification, role-based via public metadata) |
| Database | PostgreSQL (Railway) |
| Cache / Queue | Redis + Celery (Railway) |
| Notifications | WhatsApp Cloud API (interactive buttons with lock-on-first-reply) |
| Deployment | Frontend → Vercel, Backend → Railway |

## User Roles

| Role | Access |
|------|--------|
| **Admin** | Full access to all modules |
| **Teacher** | Attendance marking, exam results, timetable, read-only reports |

Roles are set in Clerk's **Public Metadata** field: `{ "role": "admin" }` or `{ "role": "teacher" }`.

---

## Local Development

### Prerequisites

- Python 3.11+
- Node.js 20+
- PostgreSQL 16
- Redis 7
- Poetry

### Backend

```bash
cd backend

# Install dependencies
poetry install

# Copy and configure environment
cp .env.example .env
# Edit .env with your Clerk, WhatsApp, and DB credentials

# Run migrations
poetry run alembic upgrade head

# Start server
poetry run uvicorn app.main:app --reload
```

The API will be at http://localhost:8000  
Swagger docs at http://localhost:8000/docs

### Frontend

```bash
cd frontend

# Install dependencies
npm install

# Configure environment
cp .env.example .env.local
# Add VITE_CLERK_PUBLISHABLE_KEY from your Clerk dashboard

# Start dev server
npm run dev
```

Frontend at http://localhost:5173 (proxied to backend via Vite)

### Docker Compose (full stack)

```bash
# From project root
cp backend/.env.example backend/.env
# Edit backend/.env

docker-compose up -d
```

Services:
- `http://localhost:8000` — Backend API
- `http://localhost:5432` — PostgreSQL
- `http://localhost:6379` — Redis
- Celery worker + Celery beat (background tasks)

---

## Database Migrations

```bash
cd backend

# Create a new migration after model changes
poetry run alembic revision --autogenerate -m "description"

# Apply migrations
poetry run alembic upgrade head

# Rollback one step
poetry run alembic downgrade -1
```

---

## Running Tests

```bash
cd backend

# Requires a test PostgreSQL database
# Set DATABASE_URL to your test DB in .env or environment

poetry run pytest tests/ -v --cov=app --cov-report=term-missing
```

Target: **80% coverage minimum**.

---

## Deployment

### Backend (Railway)

1. Create a Railway project
2. Add a PostgreSQL service and Redis service
3. Deploy the backend service pointing to `backend/`
4. Set all environment variables from `backend/.env.example`
5. Run `alembic upgrade head` as a deploy command or one-off

### Frontend (Vercel)

1. Connect your GitHub repo to Vercel
2. Set the root directory to `frontend/`
3. Add environment variables:
   - `VITE_CLERK_PUBLISHABLE_KEY`
   - `VITE_API_URL` = your Railway backend URL + `/api/v1`

---

## WhatsApp Notification Flow

As seen in `Media_1.jpg` and `Media_2.jpg`:

1. Teacher marks a student **absent** via the attendance page
2. Backend sends an **interactive WhatsApp message** to the primary parent with 3 buttons:
   - Reason 1: Suffering from Fever or Other Illness
   - Reason 2: Going to Function or Out of Town  
   - Reason 3: Emergency Work
3. Parent taps a button → WhatsApp webhook fires → reason is saved to `attendance.parent_reason`
4. **First reply locks the record** — subsequent replies from the same parent receive a "already locked" message
5. The reason appears in the daily PDF report and attendance dashboard

### WhatsApp Webhook Setup

In Meta Developer Console → WhatsApp → Configuration:
- Callback URL: `https://your-backend.railway.app/api/v1/webhooks/whatsapp`
- Verify Token: value of `WHATSAPP_VERIFY_TOKEN` env var
- Subscribe to: `messages`

---

## Key Business Rules

- **Attendance cannot be marked on Sundays or holidays** (enforced server-side)
- **Only one academic year can be active** at a time
- **All operational data is scoped to `academic_year_id`**
- **Fee overdue status** is auto-set daily by Celery beat when `due_date` passes
- **CSV imports** support rollback — all imported records are tracked by `imported_ids`
- **Audit logs** track every create/update/delete action with actor identity

---

## API Documentation

When running locally, full interactive API docs are at:
- Swagger UI: http://localhost:8000/docs
- ReDoc: http://localhost:8000/redoc

Production docs are disabled for security.

---

## Environment Variables Reference

See `backend/.env.example` for full documentation of all required and optional environment variables.
