"""Initial schema

Revision ID: 001_initial_schema
Revises:
Create Date: 2024-01-01 00:00:00.000000
"""
from typing import Sequence, Union

import sqlalchemy as sa
from alembic import op
from sqlalchemy.dialects import postgresql

revision: str = "001_initial_schema"
down_revision: Union[str, None] = None
branch_labels: Union[str, Sequence[str], None] = None
depends_on: Union[str, Sequence[str], None] = None

# Define all enums using postgresql.ENUM with create_type=False
# We create the types manually via op.execute and tell SQLAlchemy not to touch them
attendancestatus = postgresql.ENUM(
    "present", "absent", "late", "excused",
    name="attendancestatus", create_type=False
)
feestatus = postgresql.ENUM(
    "pending", "paid", "partial", "overdue", "waived",
    name="feestatus", create_type=False
)
notificationstatus = postgresql.ENUM(
    "pending", "sent", "failed", "delivered", "read",
    name="notificationstatus", create_type=False
)
notificationchannel = postgresql.ENUM(
    "whatsapp", "email", "sms",
    name="notificationchannel", create_type=False
)
holidaytype = postgresql.ENUM(
    "national", "religious", "school", "state", "emergency", "other",
    name="holidaytype", create_type=False
)
csvimportstatus = postgresql.ENUM(
    "pending", "processing", "completed", "failed", "rolled_back",
    name="csvimportstatus", create_type=False
)
csvimporttype = postgresql.ENUM(
    "students", "teachers", "fees", "marks",
    name="csvimporttype", create_type=False
)
examtype = postgresql.ENUM(
    "unit_test", "midterm", "final", "quarterly", "annual", "other",
    name="examtype", create_type=False
)
paymentmethod = postgresql.ENUM(
    "cash", "cheque", "online", "bank_transfer", "dd", "other",
    name="paymentmethod", create_type=False
)
whatsappresponsestatus = postgresql.ENUM(
    "pending", "responded", "locked", "expired",
    name="whatsappresponsestatus", create_type=False
)


def upgrade() -> None:
    # Create all enum types manually — one place, one time
    op.execute("CREATE TYPE attendancestatus AS ENUM ('present', 'absent', 'late', 'excused')")
    op.execute("CREATE TYPE feestatus AS ENUM ('pending', 'paid', 'partial', 'overdue', 'waived')")
    op.execute("CREATE TYPE notificationstatus AS ENUM ('pending', 'sent', 'failed', 'delivered', 'read')")
    op.execute("CREATE TYPE notificationchannel AS ENUM ('whatsapp', 'email', 'sms')")
    op.execute("CREATE TYPE holidaytype AS ENUM ('national', 'religious', 'school', 'state', 'emergency', 'other')")
    op.execute("CREATE TYPE csvimportstatus AS ENUM ('pending', 'processing', 'completed', 'failed', 'rolled_back')")
    op.execute("CREATE TYPE csvimporttype AS ENUM ('students', 'teachers', 'fees', 'marks')")
    op.execute("CREATE TYPE examtype AS ENUM ('unit_test', 'midterm', 'final', 'quarterly', 'annual', 'other')")
    op.execute("CREATE TYPE paymentmethod AS ENUM ('cash', 'cheque', 'online', 'bank_transfer', 'dd', 'other')")
    op.execute("CREATE TYPE whatsappresponsestatus AS ENUM ('pending', 'responded', 'locked', 'expired')")

    # academic_years
    op.create_table(
        "academic_years",
        sa.Column("id", postgresql.UUID(as_uuid=True), nullable=False, server_default=sa.text("gen_random_uuid()")),
        sa.Column("name", sa.String(50), nullable=False),
        sa.Column("start_date", sa.Date(), nullable=False),
        sa.Column("end_date", sa.Date(), nullable=False),
        sa.Column("is_active", sa.Boolean(), nullable=False, server_default="false"),
        sa.Column("is_archived", sa.Boolean(), nullable=False, server_default="false"),
        sa.Column("description", sa.Text()),
        sa.Column("created_at", sa.DateTime(timezone=True), server_default=sa.text("now()"), nullable=False),
        sa.Column("updated_at", sa.DateTime(timezone=True), server_default=sa.text("now()"), nullable=False),
        sa.PrimaryKeyConstraint("id"),
        sa.UniqueConstraint("name"),
    )

    # teachers
    op.create_table(
        "teachers",
        sa.Column("id", postgresql.UUID(as_uuid=True), nullable=False, server_default=sa.text("gen_random_uuid()")),
        sa.Column("employee_id", sa.String(50), nullable=False),
        sa.Column("clerk_user_id", sa.String(255)),
        sa.Column("first_name", sa.String(100), nullable=False),
        sa.Column("last_name", sa.String(100), nullable=False),
        sa.Column("email", sa.String(255), nullable=False),
        sa.Column("phone", sa.String(20)),
        sa.Column("whatsapp_number", sa.String(20)),
        sa.Column("qualification", sa.String(255)),
        sa.Column("joining_date", sa.Date()),
        sa.Column("is_active", sa.Boolean(), server_default="true"),
        sa.Column("profile_image_url", sa.String(500)),
        sa.Column("address", sa.Text()),
        sa.Column("extra_data", postgresql.JSONB()),
        sa.Column("created_at", sa.DateTime(timezone=True), server_default=sa.text("now()"), nullable=False),
        sa.Column("updated_at", sa.DateTime(timezone=True), server_default=sa.text("now()"), nullable=False),
        sa.PrimaryKeyConstraint("id"),
        sa.UniqueConstraint("employee_id"),
        sa.UniqueConstraint("email"),
        sa.UniqueConstraint("clerk_user_id"),
    )
    op.create_index("ix_teachers_email", "teachers", ["email"])
    op.create_index("ix_teachers_employee_id", "teachers", ["employee_id"])
    op.create_index("ix_teachers_clerk_user_id", "teachers", ["clerk_user_id"])

    # students
    op.create_table(
        "students",
        sa.Column("id", postgresql.UUID(as_uuid=True), nullable=False, server_default=sa.text("gen_random_uuid()")),
        sa.Column("admission_number", sa.String(50), nullable=False),
        sa.Column("first_name", sa.String(100), nullable=False),
        sa.Column("last_name", sa.String(100), nullable=False),
        sa.Column("date_of_birth", sa.Date()),
        sa.Column("gender", sa.String(10)),
        sa.Column("blood_group", sa.String(5)),
        sa.Column("address", sa.Text()),
        sa.Column("profile_image_url", sa.String(500)),
        sa.Column("admission_date", sa.Date()),
        sa.Column("is_active", sa.Boolean(), server_default="true"),
        sa.Column("extra_data", postgresql.JSONB()),
        sa.Column("created_at", sa.DateTime(timezone=True), server_default=sa.text("now()"), nullable=False),
        sa.Column("updated_at", sa.DateTime(timezone=True), server_default=sa.text("now()"), nullable=False),
        sa.PrimaryKeyConstraint("id"),
        sa.UniqueConstraint("admission_number"),
    )
    op.create_index("ix_students_admission_number", "students", ["admission_number"])
    op.create_index("ix_students_is_active", "students", ["is_active"])

    # parent_contacts
    op.create_table(
        "parent_contacts",
        sa.Column("id", postgresql.UUID(as_uuid=True), nullable=False, server_default=sa.text("gen_random_uuid()")),
        sa.Column("student_id", postgresql.UUID(as_uuid=True), nullable=False),
        sa.Column("relationship_type", sa.String(20), nullable=False),
        sa.Column("name", sa.String(200), nullable=False),
        sa.Column("phone", sa.String(20)),
        sa.Column("whatsapp_number", sa.String(20)),
        sa.Column("email", sa.String(255)),
        sa.Column("occupation", sa.String(100)),
        sa.Column("is_primary", sa.Boolean(), server_default="false"),
        sa.Column("created_at", sa.DateTime(timezone=True), server_default=sa.text("now()"), nullable=False),
        sa.Column("updated_at", sa.DateTime(timezone=True), server_default=sa.text("now()"), nullable=False),
        sa.ForeignKeyConstraint(["student_id"], ["students.id"], ondelete="CASCADE"),
        sa.PrimaryKeyConstraint("id"),
    )
    op.create_index("ix_parent_contacts_student_id", "parent_contacts", ["student_id"])
    op.create_index("ix_parent_contacts_whatsapp", "parent_contacts", ["whatsapp_number"])

    # subjects
    op.create_table(
        "subjects",
        sa.Column("id", postgresql.UUID(as_uuid=True), nullable=False, server_default=sa.text("gen_random_uuid()")),
        sa.Column("academic_year_id", postgresql.UUID(as_uuid=True), nullable=False),
        sa.Column("code", sa.String(20), nullable=False),
        sa.Column("name", sa.String(100), nullable=False),
        sa.Column("description", sa.Text()),
        sa.Column("is_active", sa.Boolean(), server_default="true"),
        sa.Column("max_marks", sa.Integer(), server_default="100"),
        sa.Column("passing_marks", sa.Integer(), server_default="35"),
        sa.Column("created_at", sa.DateTime(timezone=True), server_default=sa.text("now()"), nullable=False),
        sa.Column("updated_at", sa.DateTime(timezone=True), server_default=sa.text("now()"), nullable=False),
        sa.ForeignKeyConstraint(["academic_year_id"], ["academic_years.id"]),
        sa.PrimaryKeyConstraint("id"),
        sa.UniqueConstraint("academic_year_id", "code", name="uq_subject_year_code"),
    )
    op.create_index("ix_subjects_academic_year_id", "subjects", ["academic_year_id"])

    # classes
    op.create_table(
        "classes",
        sa.Column("id", postgresql.UUID(as_uuid=True), nullable=False, server_default=sa.text("gen_random_uuid()")),
        sa.Column("academic_year_id", postgresql.UUID(as_uuid=True), nullable=False),
        sa.Column("name", sa.String(50), nullable=False),
        sa.Column("section", sa.String(10), nullable=False),
        sa.Column("room_number", sa.String(20)),
        sa.Column("capacity", sa.Integer(), server_default="40"),
        sa.Column("is_active", sa.Boolean(), server_default="true"),
        sa.Column("created_at", sa.DateTime(timezone=True), server_default=sa.text("now()"), nullable=False),
        sa.Column("updated_at", sa.DateTime(timezone=True), server_default=sa.text("now()"), nullable=False),
        sa.ForeignKeyConstraint(["academic_year_id"], ["academic_years.id"]),
        sa.PrimaryKeyConstraint("id"),
        sa.UniqueConstraint("academic_year_id", "name", "section", name="uq_class_year_name_section"),
    )
    op.create_index("ix_classes_academic_year_id", "classes", ["academic_year_id"])

    # student_class_enrollments
    op.create_table(
        "student_class_enrollments",
        sa.Column("id", postgresql.UUID(as_uuid=True), nullable=False, server_default=sa.text("gen_random_uuid()")),
        sa.Column("student_id", postgresql.UUID(as_uuid=True), nullable=False),
        sa.Column("class_id", postgresql.UUID(as_uuid=True), nullable=False),
        sa.Column("academic_year_id", postgresql.UUID(as_uuid=True), nullable=False),
        sa.Column("roll_number", sa.Integer()),
        sa.Column("enrollment_date", sa.Date(), nullable=False),
        sa.Column("is_active", sa.Boolean(), server_default="true"),
        sa.Column("created_at", sa.DateTime(timezone=True), server_default=sa.text("now()"), nullable=False),
        sa.Column("updated_at", sa.DateTime(timezone=True), server_default=sa.text("now()"), nullable=False),
        sa.ForeignKeyConstraint(["class_id"], ["classes.id"]),
        sa.ForeignKeyConstraint(["student_id"], ["students.id"]),
        sa.ForeignKeyConstraint(["academic_year_id"], ["academic_years.id"]),
        sa.PrimaryKeyConstraint("id"),
        sa.UniqueConstraint("student_id", "class_id", name="uq_student_class_enrollment"),
    )
    op.create_index("ix_student_class_enrollments_class_id", "student_class_enrollments", ["class_id"])
    op.create_index("ix_student_class_enrollments_student_id", "student_class_enrollments", ["student_id"])

    # teacher_subject_assignments
    op.create_table(
        "teacher_subject_assignments",
        sa.Column("id", postgresql.UUID(as_uuid=True), nullable=False, server_default=sa.text("gen_random_uuid()")),
        sa.Column("teacher_id", postgresql.UUID(as_uuid=True), nullable=False),
        sa.Column("subject_id", postgresql.UUID(as_uuid=True), nullable=False),
        sa.Column("class_id", postgresql.UUID(as_uuid=True), nullable=False),
        sa.Column("academic_year_id", postgresql.UUID(as_uuid=True), nullable=False),
        sa.Column("created_at", sa.DateTime(timezone=True), server_default=sa.text("now()"), nullable=False),
        sa.Column("updated_at", sa.DateTime(timezone=True), server_default=sa.text("now()"), nullable=False),
        sa.ForeignKeyConstraint(["teacher_id"], ["teachers.id"]),
        sa.ForeignKeyConstraint(["subject_id"], ["subjects.id"]),
        sa.ForeignKeyConstraint(["class_id"], ["classes.id"]),
        sa.ForeignKeyConstraint(["academic_year_id"], ["academic_years.id"]),
        sa.PrimaryKeyConstraint("id"),
        sa.UniqueConstraint("teacher_id", "subject_id", "class_id", name="uq_teacher_subject_class"),
    )

    # class_teacher_assignments
    op.create_table(
        "class_teacher_assignments",
        sa.Column("id", postgresql.UUID(as_uuid=True), nullable=False, server_default=sa.text("gen_random_uuid()")),
        sa.Column("class_id", postgresql.UUID(as_uuid=True), nullable=False),
        sa.Column("teacher_id", postgresql.UUID(as_uuid=True), nullable=False),
        sa.Column("academic_year_id", postgresql.UUID(as_uuid=True), nullable=False),
        sa.Column("created_at", sa.DateTime(timezone=True), server_default=sa.text("now()"), nullable=False),
        sa.Column("updated_at", sa.DateTime(timezone=True), server_default=sa.text("now()"), nullable=False),
        sa.ForeignKeyConstraint(["class_id"], ["classes.id"]),
        sa.ForeignKeyConstraint(["teacher_id"], ["teachers.id"]),
        sa.ForeignKeyConstraint(["academic_year_id"], ["academic_years.id"]),
        sa.PrimaryKeyConstraint("id"),
        sa.UniqueConstraint("class_id", "academic_year_id", name="uq_class_teacher_year"),
    )

    # timetable_slots
    op.create_table(
        "timetable_slots",
        sa.Column("id", postgresql.UUID(as_uuid=True), nullable=False, server_default=sa.text("gen_random_uuid()")),
        sa.Column("class_id", postgresql.UUID(as_uuid=True), nullable=False),
        sa.Column("teacher_id", postgresql.UUID(as_uuid=True), nullable=False),
        sa.Column("subject_id", postgresql.UUID(as_uuid=True), nullable=False),
        sa.Column("day_of_week", sa.Integer(), nullable=False),
        sa.Column("period_number", sa.Integer(), nullable=False),
        sa.Column("start_time", sa.String(5), nullable=False),
        sa.Column("end_time", sa.String(5), nullable=False),
        sa.Column("created_at", sa.DateTime(timezone=True), server_default=sa.text("now()"), nullable=False),
        sa.Column("updated_at", sa.DateTime(timezone=True), server_default=sa.text("now()"), nullable=False),
        sa.ForeignKeyConstraint(["class_id"], ["classes.id"]),
        sa.ForeignKeyConstraint(["teacher_id"], ["teachers.id"]),
        sa.ForeignKeyConstraint(["subject_id"], ["subjects.id"]),
        sa.PrimaryKeyConstraint("id"),
        sa.UniqueConstraint("class_id", "day_of_week", "period_number", name="uq_timetable_slot"),
    )
    op.create_index("ix_timetable_slots_class_id", "timetable_slots", ["class_id"])
    op.create_index("ix_timetable_slots_teacher_id", "timetable_slots", ["teacher_id"])

    # holidays
    op.create_table(
        "holidays",
        sa.Column("id", postgresql.UUID(as_uuid=True), nullable=False, server_default=sa.text("gen_random_uuid()")),
        sa.Column("academic_year_id", postgresql.UUID(as_uuid=True), nullable=False),
        sa.Column("name", sa.String(200), nullable=False),
        sa.Column("description", sa.Text()),
        sa.Column("start_date", sa.Date(), nullable=False),
        sa.Column("end_date", sa.Date(), nullable=False),
        sa.Column("holiday_type", holidaytype, nullable=False),
        sa.Column("is_active", sa.Boolean(), server_default="true"),
        sa.Column("created_at", sa.DateTime(timezone=True), server_default=sa.text("now()"), nullable=False),
        sa.Column("updated_at", sa.DateTime(timezone=True), server_default=sa.text("now()"), nullable=False),
        sa.ForeignKeyConstraint(["academic_year_id"], ["academic_years.id"]),
        sa.PrimaryKeyConstraint("id"),
    )
    op.create_index("ix_holidays_academic_year_id", "holidays", ["academic_year_id"])
    op.create_index("ix_holidays_start_date", "holidays", ["start_date"])
    op.create_index("ix_holidays_end_date", "holidays", ["end_date"])

    # academic_calendar_events
    op.create_table(
        "academic_calendar_events",
        sa.Column("id", postgresql.UUID(as_uuid=True), nullable=False, server_default=sa.text("gen_random_uuid()")),
        sa.Column("academic_year_id", postgresql.UUID(as_uuid=True), nullable=False),
        sa.Column("title", sa.String(200), nullable=False),
        sa.Column("description", sa.Text()),
        sa.Column("event_date", sa.Date(), nullable=False),
        sa.Column("end_date", sa.Date()),
        sa.Column("event_type", sa.String(50), server_default="'general'"),
        sa.Column("color", sa.String(7)),
        sa.Column("created_at", sa.DateTime(timezone=True), server_default=sa.text("now()"), nullable=False),
        sa.Column("updated_at", sa.DateTime(timezone=True), server_default=sa.text("now()"), nullable=False),
        sa.ForeignKeyConstraint(["academic_year_id"], ["academic_years.id"]),
        sa.PrimaryKeyConstraint("id"),
    )

    # attendance
    op.create_table(
        "attendance",
        sa.Column("id", postgresql.UUID(as_uuid=True), nullable=False, server_default=sa.text("gen_random_uuid()")),
        sa.Column("student_id", postgresql.UUID(as_uuid=True), nullable=False),
        sa.Column("class_id", postgresql.UUID(as_uuid=True), nullable=False),
        sa.Column("academic_year_id", postgresql.UUID(as_uuid=True), nullable=False),
        sa.Column("attendance_date", sa.Date(), nullable=False),
        sa.Column("status", attendancestatus, nullable=False),
        sa.Column("marked_by_teacher_id", postgresql.UUID(as_uuid=True)),
        sa.Column("remarks", sa.Text()),
        sa.Column("parent_reason", sa.Text()),
        sa.Column("parent_reason_locked", sa.Boolean(), server_default="false"),
        sa.Column("whatsapp_response_status", whatsappresponsestatus, server_default="'pending'"),
        sa.Column("whatsapp_notification_sent_at", sa.DateTime(timezone=True)),
        sa.Column("created_at", sa.DateTime(timezone=True), server_default=sa.text("now()"), nullable=False),
        sa.Column("updated_at", sa.DateTime(timezone=True), server_default=sa.text("now()"), nullable=False),
        sa.ForeignKeyConstraint(["class_id"], ["classes.id"]),
        sa.ForeignKeyConstraint(["student_id"], ["students.id"]),
        sa.ForeignKeyConstraint(["academic_year_id"], ["academic_years.id"]),
        sa.ForeignKeyConstraint(["marked_by_teacher_id"], ["teachers.id"]),
        sa.PrimaryKeyConstraint("id"),
        sa.UniqueConstraint("student_id", "attendance_date", "class_id", name="uq_attendance"),
    )
    op.create_index("ix_attendance_class_date", "attendance", ["class_id", "attendance_date"])
    op.create_index("ix_attendance_student_date", "attendance", ["student_id", "attendance_date"])
    op.create_index("ix_attendance_academic_year_id", "attendance", ["academic_year_id"])
    op.create_index("ix_attendance_date", "attendance", ["attendance_date"])

    # exams
    op.create_table(
        "exams",
        sa.Column("id", postgresql.UUID(as_uuid=True), nullable=False, server_default=sa.text("gen_random_uuid()")),
        sa.Column("academic_year_id", postgresql.UUID(as_uuid=True), nullable=False),
        sa.Column("name", sa.String(200), nullable=False),
        sa.Column("exam_type", examtype, nullable=False),
        sa.Column("start_date", sa.Date(), nullable=False),
        sa.Column("end_date", sa.Date(), nullable=False),
        sa.Column("is_published", sa.Boolean(), server_default="false"),
        sa.Column("description", sa.Text()),
        sa.Column("created_at", sa.DateTime(timezone=True), server_default=sa.text("now()"), nullable=False),
        sa.Column("updated_at", sa.DateTime(timezone=True), server_default=sa.text("now()"), nullable=False),
        sa.ForeignKeyConstraint(["academic_year_id"], ["academic_years.id"]),
        sa.PrimaryKeyConstraint("id"),
    )
    op.create_index("ix_exams_academic_year_id", "exams", ["academic_year_id"])

    # exam_schedules
    op.create_table(
        "exam_schedules",
        sa.Column("id", postgresql.UUID(as_uuid=True), nullable=False, server_default=sa.text("gen_random_uuid()")),
        sa.Column("exam_id", postgresql.UUID(as_uuid=True), nullable=False),
        sa.Column("class_id", postgresql.UUID(as_uuid=True), nullable=False),
        sa.Column("subject_id", postgresql.UUID(as_uuid=True), nullable=False),
        sa.Column("exam_date", sa.Date(), nullable=False),
        sa.Column("start_time", sa.String(5)),
        sa.Column("end_time", sa.String(5)),
        sa.Column("room", sa.String(50)),
        sa.Column("created_at", sa.DateTime(timezone=True), server_default=sa.text("now()"), nullable=False),
        sa.Column("updated_at", sa.DateTime(timezone=True), server_default=sa.text("now()"), nullable=False),
        sa.ForeignKeyConstraint(["class_id"], ["classes.id"]),
        sa.ForeignKeyConstraint(["exam_id"], ["exams.id"]),
        sa.ForeignKeyConstraint(["subject_id"], ["subjects.id"]),
        sa.PrimaryKeyConstraint("id"),
    )

    # exam_results
    op.create_table(
        "exam_results",
        sa.Column("id", postgresql.UUID(as_uuid=True), nullable=False, server_default=sa.text("gen_random_uuid()")),
        sa.Column("exam_id", postgresql.UUID(as_uuid=True), nullable=False),
        sa.Column("student_id", postgresql.UUID(as_uuid=True), nullable=False),
        sa.Column("subject_id", postgresql.UUID(as_uuid=True), nullable=False),
        sa.Column("marks_obtained", sa.Numeric(6, 2)),
        sa.Column("max_marks", sa.Numeric(6, 2), server_default="100"),
        sa.Column("is_absent", sa.Boolean(), server_default="false"),
        sa.Column("remarks", sa.Text()),
        sa.Column("created_at", sa.DateTime(timezone=True), server_default=sa.text("now()"), nullable=False),
        sa.Column("updated_at", sa.DateTime(timezone=True), server_default=sa.text("now()"), nullable=False),
        sa.ForeignKeyConstraint(["exam_id"], ["exams.id"]),
        sa.ForeignKeyConstraint(["student_id"], ["students.id"]),
        sa.ForeignKeyConstraint(["subject_id"], ["subjects.id"]),
        sa.PrimaryKeyConstraint("id"),
        sa.UniqueConstraint("exam_id", "student_id", "subject_id", name="uq_exam_result"),
    )
    op.create_index("ix_exam_results_exam_id", "exam_results", ["exam_id"])
    op.create_index("ix_exam_results_student_id", "exam_results", ["student_id"])

    # fee_structures
    op.create_table(
        "fee_structures",
        sa.Column("id", postgresql.UUID(as_uuid=True), nullable=False, server_default=sa.text("gen_random_uuid()")),
        sa.Column("academic_year_id", postgresql.UUID(as_uuid=True), nullable=False),
        sa.Column("name", sa.String(200), nullable=False),
        sa.Column("description", sa.Text()),
        sa.Column("amount", sa.Numeric(12, 2), nullable=False),
        sa.Column("due_date", sa.Date()),
        sa.Column("is_mandatory", sa.Boolean(), server_default="true"),
        sa.Column("is_active", sa.Boolean(), server_default="true"),
        sa.Column("created_at", sa.DateTime(timezone=True), server_default=sa.text("now()"), nullable=False),
        sa.Column("updated_at", sa.DateTime(timezone=True), server_default=sa.text("now()"), nullable=False),
        sa.ForeignKeyConstraint(["academic_year_id"], ["academic_years.id"]),
        sa.PrimaryKeyConstraint("id"),
    )
    op.create_index("ix_fee_structures_academic_year_id", "fee_structures", ["academic_year_id"])

    # student_fees
    op.create_table(
        "student_fees",
        sa.Column("id", postgresql.UUID(as_uuid=True), nullable=False, server_default=sa.text("gen_random_uuid()")),
        sa.Column("student_id", postgresql.UUID(as_uuid=True), nullable=False),
        sa.Column("fee_structure_id", postgresql.UUID(as_uuid=True), nullable=False),
        sa.Column("academic_year_id", postgresql.UUID(as_uuid=True), nullable=False),
        sa.Column("amount_due", sa.Numeric(12, 2), nullable=False),
        sa.Column("amount_paid", sa.Numeric(12, 2), server_default="0"),
        sa.Column("due_date", sa.Date()),
        sa.Column("status", feestatus, server_default="'pending'"),
        sa.Column("concession_amount", sa.Numeric(12, 2), server_default="0"),
        sa.Column("concession_reason", sa.Text()),
        sa.Column("remarks", sa.Text()),
        sa.Column("created_at", sa.DateTime(timezone=True), server_default=sa.text("now()"), nullable=False),
        sa.Column("updated_at", sa.DateTime(timezone=True), server_default=sa.text("now()"), nullable=False),
        sa.ForeignKeyConstraint(["academic_year_id"], ["academic_years.id"]),
        sa.ForeignKeyConstraint(["fee_structure_id"], ["fee_structures.id"]),
        sa.ForeignKeyConstraint(["student_id"], ["students.id"]),
        sa.PrimaryKeyConstraint("id"),
        sa.UniqueConstraint("student_id", "fee_structure_id", name="uq_student_fee"),
    )
    op.create_index("ix_student_fees_student_id", "student_fees", ["student_id"])
    op.create_index("ix_student_fees_academic_year_id", "student_fees", ["academic_year_id"])
    op.create_index("ix_student_fees_status", "student_fees", ["status"])

    # payments
    op.create_table(
        "payments",
        sa.Column("id", postgresql.UUID(as_uuid=True), nullable=False, server_default=sa.text("gen_random_uuid()")),
        sa.Column("student_fee_id", postgresql.UUID(as_uuid=True), nullable=False),
        sa.Column("amount", sa.Numeric(12, 2), nullable=False),
        sa.Column("payment_date", sa.Date(), nullable=False),
        sa.Column("payment_method", paymentmethod, nullable=False),
        sa.Column("receipt_number", sa.String(100)),
        sa.Column("transaction_id", sa.String(255)),
        sa.Column("remarks", sa.Text()),
        sa.Column("collected_by_clerk_id", sa.String(255)),
        sa.Column("created_at", sa.DateTime(timezone=True), server_default=sa.text("now()"), nullable=False),
        sa.Column("updated_at", sa.DateTime(timezone=True), server_default=sa.text("now()"), nullable=False),
        sa.ForeignKeyConstraint(["student_fee_id"], ["student_fees.id"], ondelete="CASCADE"),
        sa.PrimaryKeyConstraint("id"),
    )
    op.create_index("ix_payments_student_fee_id", "payments", ["student_fee_id"])
    op.create_index("ix_payments_payment_date", "payments", ["payment_date"])

    # notifications
    op.create_table(
        "notifications",
        sa.Column("id", postgresql.UUID(as_uuid=True), nullable=False, server_default=sa.text("gen_random_uuid()")),
        sa.Column("academic_year_id", postgresql.UUID(as_uuid=True)),
        sa.Column("student_id", postgresql.UUID(as_uuid=True)),
        sa.Column("parent_contact_id", postgresql.UUID(as_uuid=True)),
        sa.Column("channel", notificationchannel, nullable=False),
        sa.Column("recipient_number", sa.String(20)),
        sa.Column("recipient_email", sa.String(255)),
        sa.Column("template_name", sa.String(100)),
        sa.Column("message_body", sa.Text()),
        sa.Column("status", notificationstatus, server_default="'pending'"),
        sa.Column("whatsapp_message_id", sa.String(255)),
        sa.Column("error_message", sa.Text()),
        sa.Column("sent_at", sa.DateTime(timezone=True)),
        sa.Column("delivered_at", sa.DateTime(timezone=True)),
        sa.Column("notification_type", sa.String(50), server_default="'general'"),
        sa.Column("extra_data", postgresql.JSONB()),
        sa.Column("created_at", sa.DateTime(timezone=True), server_default=sa.text("now()"), nullable=False),
        sa.Column("updated_at", sa.DateTime(timezone=True), server_default=sa.text("now()"), nullable=False),
        sa.ForeignKeyConstraint(["academic_year_id"], ["academic_years.id"]),
        sa.ForeignKeyConstraint(["parent_contact_id"], ["parent_contacts.id"]),
        sa.ForeignKeyConstraint(["student_id"], ["students.id"]),
        sa.PrimaryKeyConstraint("id"),
    )
    op.create_index("ix_notifications_student_id", "notifications", ["student_id"])
    op.create_index("ix_notifications_status", "notifications", ["status"])
    op.create_index("ix_notifications_sent_at", "notifications", ["sent_at"])
    op.create_index("ix_notifications_academic_year_id", "notifications", ["academic_year_id"])

    # csv_import_jobs
    op.create_table(
        "csv_import_jobs",
        sa.Column("id", postgresql.UUID(as_uuid=True), nullable=False, server_default=sa.text("gen_random_uuid()")),
        sa.Column("import_type", csvimporttype, nullable=False),
        sa.Column("academic_year_id", postgresql.UUID(as_uuid=True)),
        sa.Column("filename", sa.String(255), nullable=False),
        sa.Column("total_rows", sa.Integer(), server_default="0"),
        sa.Column("processed_rows", sa.Integer(), server_default="0"),
        sa.Column("success_rows", sa.Integer(), server_default="0"),
        sa.Column("error_rows", sa.Integer(), server_default="0"),
        sa.Column("duplicate_rows", sa.Integer(), server_default="0"),
        sa.Column("status", csvimportstatus, server_default="'pending'"),
        sa.Column("errors", postgresql.JSONB()),
        sa.Column("imported_ids", postgresql.JSONB()),
        sa.Column("started_at", sa.DateTime(timezone=True)),
        sa.Column("completed_at", sa.DateTime(timezone=True)),
        sa.Column("initiated_by_clerk_id", sa.String(255)),
        sa.Column("created_at", sa.DateTime(timezone=True), server_default=sa.text("now()"), nullable=False),
        sa.Column("updated_at", sa.DateTime(timezone=True), server_default=sa.text("now()"), nullable=False),
        sa.ForeignKeyConstraint(["academic_year_id"], ["academic_years.id"]),
        sa.PrimaryKeyConstraint("id"),
    )
    op.create_index("ix_csv_import_jobs_status", "csv_import_jobs", ["status"])
    op.create_index("ix_csv_import_jobs_import_type", "csv_import_jobs", ["import_type"])

    # audit_logs
    op.create_table(
        "audit_logs",
        sa.Column("id", postgresql.UUID(as_uuid=True), nullable=False, server_default=sa.text("gen_random_uuid()")),
        sa.Column("created_at", sa.DateTime(timezone=True), server_default=sa.text("now()"), nullable=False),
        sa.Column("actor_clerk_id", sa.String(255)),
        sa.Column("actor_role", sa.String(50)),
        sa.Column("actor_name", sa.String(200)),
        sa.Column("action", sa.String(100), nullable=False),
        sa.Column("resource_type", sa.String(100), nullable=False),
        sa.Column("resource_id", sa.String(255)),
        sa.Column("old_values", postgresql.JSONB()),
        sa.Column("new_values", postgresql.JSONB()),
        sa.Column("ip_address", sa.String(50)),
        sa.Column("user_agent", sa.Text()),
        sa.Column("extra_data", postgresql.JSONB()),
        sa.PrimaryKeyConstraint("id"),
    )
    op.create_index("ix_audit_logs_actor_clerk_id", "audit_logs", ["actor_clerk_id"])
    op.create_index("ix_audit_logs_action", "audit_logs", ["action"])
    op.create_index("ix_audit_logs_resource_type", "audit_logs", ["resource_type"])
    op.create_index("ix_audit_logs_created_at", "audit_logs", ["created_at"])


def downgrade() -> None:
    op.drop_table("audit_logs")
    op.drop_table("csv_import_jobs")
    op.drop_table("notifications")
    op.drop_table("payments")
    op.drop_table("student_fees")
    op.drop_table("fee_structures")
    op.drop_table("exam_results")
    op.drop_table("exam_schedules")
    op.drop_table("exams")
    op.drop_table("attendance")
    op.drop_table("academic_calendar_events")
    op.drop_table("holidays")
    op.drop_table("timetable_slots")
    op.drop_table("class_teacher_assignments")
    op.drop_table("teacher_subject_assignments")
    op.drop_table("student_class_enrollments")
    op.drop_table("classes")
    op.drop_table("subjects")
    op.drop_table("parent_contacts")
    op.drop_table("students")
    op.drop_table("teachers")
    op.drop_table("academic_years")

    op.execute("DROP TYPE IF EXISTS whatsappresponsestatus")
    op.execute("DROP TYPE IF EXISTS paymentmethod")
    op.execute("DROP TYPE IF EXISTS examtype")
    op.execute("DROP TYPE IF EXISTS csvimporttype")
    op.execute("DROP TYPE IF EXISTS csvimportstatus")
    op.execute("DROP TYPE IF EXISTS holidaytype")
    op.execute("DROP TYPE IF EXISTS notificationchannel")
    op.execute("DROP TYPE IF EXISTS notificationstatus")
    op.execute("DROP TYPE IF EXISTS feestatus")
    op.execute("DROP TYPE IF EXISTS attendancestatus")
