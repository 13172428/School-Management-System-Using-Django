"""
API v1 router — registers all endpoint modules.
"""
from fastapi import APIRouter

from app.api.v1.endpoints import (
    academic_years,
    attendance,
    audit_logs,
    classes,
    csv_import,
    dashboard,
    exams,
    fees,
    holidays,
    notifications,
    students,
    subjects,
    teachers,
    timetable,
    webhooks,
)

api_router = APIRouter()

api_router.include_router(academic_years.router, prefix="/academic-years", tags=["Academic Years"])
api_router.include_router(students.router, prefix="/students", tags=["Students"])
api_router.include_router(teachers.router, prefix="/teachers", tags=["Teachers"])
api_router.include_router(classes.router, prefix="/classes", tags=["Classes"])
api_router.include_router(subjects.router, prefix="/subjects", tags=["Subjects"])
api_router.include_router(holidays.router, prefix="/holidays", tags=["Holidays"])
api_router.include_router(attendance.router, prefix="/attendance", tags=["Attendance"])
api_router.include_router(exams.router, prefix="/exams", tags=["Exams"])
api_router.include_router(fees.router, prefix="/fees", tags=["Fees"])
api_router.include_router(timetable.router, prefix="/timetable", tags=["Timetable"])
api_router.include_router(notifications.router, prefix="/notifications", tags=["Notifications"])
api_router.include_router(csv_import.router, prefix="/csv-import", tags=["CSV Import"])
api_router.include_router(audit_logs.router, prefix="/audit-logs", tags=["Audit Logs"])
api_router.include_router(dashboard.router, prefix="/dashboard", tags=["Dashboard"])
api_router.include_router(webhooks.router, prefix="/webhooks", tags=["Webhooks"])
