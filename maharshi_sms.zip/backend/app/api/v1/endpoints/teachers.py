"""
Teachers endpoints — CRUD + class/subject assignment management.
"""
from uuid import UUID

from fastapi import APIRouter, HTTPException, Query, status
from sqlalchemy import select

from app.core.security import RequireAdmin, RequireAnyRole
from app.db.session import DbSession
from app.models.models import ClassTeacherAssignment, Teacher, TeacherSubjectAssignment
from app.schemas.schemas import (
    MessageResponse,
    TeacherCreate,
    TeacherResponse,
    TeacherUpdate,
)
from app.services.audit_service import AuditLogService

router = APIRouter()


@router.get("", response_model=list[TeacherResponse])
async def list_teachers(
    db: DbSession,
    _: None = RequireAnyRole,
    search: str | None = Query(None),
    is_active: bool | None = Query(None),
    skip: int = Query(0, ge=0),
    limit: int = Query(50, ge=1, le=200),
) -> list[Teacher]:
    q = select(Teacher)
    if search:
        pattern = f"%{search}%"
        q = q.where(
            (Teacher.first_name.ilike(pattern))
            | (Teacher.last_name.ilike(pattern))
            | (Teacher.employee_id.ilike(pattern))
        )
    if is_active is not None:
        q = q.where(Teacher.is_active == is_active)
    q = q.order_by(Teacher.first_name, Teacher.last_name).offset(skip).limit(limit)
    result = await db.execute(q)
    return list(result.scalars().all())


@router.get("/{teacher_id}", response_model=TeacherResponse)
async def get_teacher(
    db: DbSession,
    teacher_id: UUID,
    _: None = RequireAnyRole,
) -> Teacher:
    teacher = await db.get(Teacher, teacher_id)
    if not teacher:
        raise HTTPException(status_code=404, detail="Teacher not found.")
    return teacher


@router.post("", response_model=TeacherResponse, status_code=status.HTTP_201_CREATED)
async def create_teacher(
    db: DbSession,
    payload: TeacherCreate,
    current_user=RequireAdmin,
) -> Teacher:
    # Check employee ID uniqueness
    existing = await db.scalar(
        select(Teacher).where(Teacher.employee_id == payload.employee_id)
    )
    if existing:
        raise HTTPException(
            status_code=400,
            detail=f"Employee ID '{payload.employee_id}' already exists.",
        )

    # Check email uniqueness
    if payload.email:
        existing_email = await db.scalar(
            select(Teacher).where(Teacher.email == payload.email)
        )
        if existing_email:
            raise HTTPException(status_code=400, detail="Email already in use.")

    teacher = Teacher(**payload.model_dump())
    db.add(teacher)
    await db.flush()
    await db.refresh(teacher)

    await AuditLogService.log(
        db,
        actor_id=current_user.clerk_user_id,
        actor_role=current_user.role,
        action="CREATE_TEACHER",
        resource_type="teacher",
        resource_id=str(teacher.id),
        details={"name": teacher.full_name, "employee_id": teacher.employee_id},
    )
    return teacher


@router.patch("/{teacher_id}", response_model=TeacherResponse)
async def update_teacher(
    db: DbSession,
    teacher_id: UUID,
    payload: TeacherUpdate,
    current_user=RequireAdmin,
) -> Teacher:
    teacher = await db.get(Teacher, teacher_id)
    if not teacher:
        raise HTTPException(status_code=404, detail="Teacher not found.")

    update_data = payload.model_dump(exclude_unset=True)

    if "employee_id" in update_data:
        dup = await db.scalar(
            select(Teacher).where(
                Teacher.employee_id == update_data["employee_id"],
                Teacher.id != teacher_id,
            )
        )
        if dup:
            raise HTTPException(status_code=400, detail="Employee ID already in use.")

    for field, value in update_data.items():
        setattr(teacher, field, value)

    await db.flush()
    await db.refresh(teacher)
    await AuditLogService.log(
        db,
        actor_id=current_user.clerk_user_id,
        actor_role=current_user.role,
        action="UPDATE_TEACHER",
        resource_type="teacher",
        resource_id=str(teacher.id),
        details=update_data,
    )
    return teacher


@router.delete("/{teacher_id}", response_model=MessageResponse)
async def deactivate_teacher(
    db: DbSession,
    teacher_id: UUID,
    current_user=RequireAdmin,
) -> MessageResponse:
    teacher = await db.get(Teacher, teacher_id)
    if not teacher:
        raise HTTPException(status_code=404, detail="Teacher not found.")
    teacher.is_active = False
    await AuditLogService.log(
        db,
        actor_id=current_user.clerk_user_id,
        actor_role=current_user.role,
        action="DEACTIVATE_TEACHER",
        resource_type="teacher",
        resource_id=str(teacher_id),
    )
    return MessageResponse(message="Teacher deactivated successfully.")


@router.get("/{teacher_id}/assignments")
async def get_teacher_assignments(
    db: DbSession,
    teacher_id: UUID,
    _: None = RequireAnyRole,
) -> dict:
    """Return all subject and class assignments for a teacher."""
    subject_result = await db.execute(
        select(TeacherSubjectAssignment).where(
            TeacherSubjectAssignment.teacher_id == teacher_id
        )
    )
    class_result = await db.execute(
        select(ClassTeacherAssignment).where(
            ClassTeacherAssignment.teacher_id == teacher_id
        )
    )
    subjects = subject_result.scalars().all()
    classes = class_result.scalars().all()
    return {
        "subject_assignments": [
            {"subject_id": str(s.subject_id), "academic_year_id": str(s.academic_year_id)}
            for s in subjects
        ],
        "class_teacher_assignments": [
            {"class_id": str(c.class_id), "academic_year_id": str(c.academic_year_id)}
            for c in classes
        ],
    }
