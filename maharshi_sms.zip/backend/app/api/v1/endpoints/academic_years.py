"""
Academic Years endpoints — CRUD + activate/archive.
Only one academic year can be active at a time.
"""
from uuid import UUID

from fastapi import APIRouter, HTTPException, status
from sqlalchemy import select, update

from app.core.security import RequireAdmin, RequireAnyRole
from app.db.session import DbSession
from app.models.models import AcademicYear
from app.schemas.schemas import (
    AcademicYearCreate,
    AcademicYearResponse,
    AcademicYearUpdate,
    MessageResponse,
)
from app.services.audit_service import AuditLogService

router = APIRouter()


@router.get("", response_model=list[AcademicYearResponse])
async def list_academic_years(
    db: DbSession,
    _: None = RequireAnyRole,
) -> list[AcademicYear]:
    result = await db.execute(select(AcademicYear).order_by(AcademicYear.start_date.desc()))
    return list(result.scalars().all())


@router.get("/active", response_model=AcademicYearResponse)
async def get_active_academic_year(
    db: DbSession,
    _: None = RequireAnyRole,
) -> AcademicYear:
    result = await db.execute(
        select(AcademicYear).where(AcademicYear.is_active == True)  # noqa: E712
    )
    year = result.scalar_one_or_none()
    if not year:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail="No active academic year found.",
        )
    return year


@router.get("/{year_id}", response_model=AcademicYearResponse)
async def get_academic_year(
    db: DbSession,
    year_id: UUID,
    _: None = RequireAnyRole,
) -> AcademicYear:
    year = await db.get(AcademicYear, year_id)
    if not year:
        raise HTTPException(status_code=404, detail="Academic year not found.")
    return year


@router.post("", response_model=AcademicYearResponse, status_code=status.HTTP_201_CREATED)
async def create_academic_year(
    db: DbSession,
    payload: AcademicYearCreate,
    current_user=RequireAdmin,
) -> AcademicYear:
    # Validate dates
    if payload.end_date <= payload.start_date:
        raise HTTPException(status_code=400, detail="end_date must be after start_date.")

    # If this is to be active, deactivate all others
    if payload.is_active:
        await db.execute(update(AcademicYear).values(is_active=False))

    year = AcademicYear(**payload.model_dump())
    db.add(year)
    await db.flush()
    await db.refresh(year)

    await AuditLogService.log(
        db,
        actor_id=current_user.clerk_user_id,
        actor_role=current_user.role,
        action="CREATE_ACADEMIC_YEAR",
        resource_type="academic_year",
        resource_id=str(year.id),
        details={"name": year.name},
    )
    return year


@router.patch("/{year_id}", response_model=AcademicYearResponse)
async def update_academic_year(
    db: DbSession,
    year_id: UUID,
    payload: AcademicYearUpdate,
    current_user=RequireAdmin,
) -> AcademicYear:
    year = await db.get(AcademicYear, year_id)
    if not year:
        raise HTTPException(status_code=404, detail="Academic year not found.")
    if year.is_archived:
        raise HTTPException(status_code=400, detail="Cannot edit an archived academic year.")

    update_data = payload.model_dump(exclude_unset=True)

    if "is_active" in update_data and update_data["is_active"]:
        await db.execute(
            update(AcademicYear).where(AcademicYear.id != year_id).values(is_active=False)
        )

    for field, value in update_data.items():
        setattr(year, field, value)

    await db.flush()
    await db.refresh(year)
    await AuditLogService.log(
        db,
        actor_id=current_user.clerk_user_id,
        actor_role=current_user.role,
        action="UPDATE_ACADEMIC_YEAR",
        resource_type="academic_year",
        resource_id=str(year.id),
        details=update_data,
    )
    return year


@router.post("/{year_id}/activate", response_model=AcademicYearResponse)
async def activate_academic_year(
    db: DbSession,
    year_id: UUID,
    current_user=RequireAdmin,
) -> AcademicYear:
    year = await db.get(AcademicYear, year_id)
    if not year:
        raise HTTPException(status_code=404, detail="Academic year not found.")
    if year.is_archived:
        raise HTTPException(status_code=400, detail="Cannot activate an archived academic year.")

    # Deactivate all, then activate this one
    await db.execute(update(AcademicYear).values(is_active=False))
    year.is_active = True
    await db.flush()
    await db.refresh(year)
    await AuditLogService.log(
        db,
        actor_id=current_user.clerk_user_id,
        actor_role=current_user.role,
        action="ACTIVATE_ACADEMIC_YEAR",
        resource_type="academic_year",
        resource_id=str(year.id),
    )
    return year


@router.post("/{year_id}/archive", response_model=MessageResponse)
async def archive_academic_year(
    db: DbSession,
    year_id: UUID,
    current_user=RequireAdmin,
) -> MessageResponse:
    year = await db.get(AcademicYear, year_id)
    if not year:
        raise HTTPException(status_code=404, detail="Academic year not found.")
    if year.is_active:
        raise HTTPException(status_code=400, detail="Cannot archive the currently active year.")

    year.is_archived = True
    await db.flush()
    await AuditLogService.log(
        db,
        actor_id=current_user.clerk_user_id,
        actor_role=current_user.role,
        action="ARCHIVE_ACADEMIC_YEAR",
        resource_type="academic_year",
        resource_id=str(year.id),
    )
    return MessageResponse(message=f"Academic year '{year.name}' archived successfully.")


@router.delete("/{year_id}", response_model=MessageResponse)
async def delete_academic_year(
    db: DbSession,
    year_id: UUID,
    current_user=RequireAdmin,
) -> MessageResponse:
    year = await db.get(AcademicYear, year_id)
    if not year:
        raise HTTPException(status_code=404, detail="Academic year not found.")
    if year.is_active:
        raise HTTPException(status_code=400, detail="Cannot delete the active academic year.")

    await db.delete(year)
    await AuditLogService.log(
        db,
        actor_id=current_user.clerk_user_id,
        actor_role=current_user.role,
        action="DELETE_ACADEMIC_YEAR",
        resource_type="academic_year",
        resource_id=str(year_id),
    )
    return MessageResponse(message="Academic year deleted.")
