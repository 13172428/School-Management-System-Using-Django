"""
Subjects endpoints — CRUD + teacher assignment.
"""
from uuid import UUID

from fastapi import APIRouter, HTTPException, Query, status
from sqlalchemy import select

from app.core.security import RequireAdmin, RequireAnyRole
from app.db.session import DbSession
from app.models.models import Subject, Teacher, TeacherSubjectAssignment
from app.schemas.schemas import MessageResponse, SubjectCreate, SubjectResponse, SubjectUpdate
from app.services.audit_service import AuditLogService

router = APIRouter()


@router.get("", response_model=list[SubjectResponse])
async def list_subjects(
    db: DbSession,
    _: None = RequireAnyRole,
    academic_year_id: UUID | None = Query(None),
) -> list[Subject]:
    q = select(Subject)
    if academic_year_id:
        q = q.where(Subject.academic_year_id == academic_year_id)
    q = q.order_by(Subject.name)
    result = await db.execute(q)
    return list(result.scalars().all())


@router.get("/{subject_id}", response_model=SubjectResponse)
async def get_subject(
    db: DbSession,
    subject_id: UUID,
    _: None = RequireAnyRole,
) -> Subject:
    subject = await db.get(Subject, subject_id)
    if not subject:
        raise HTTPException(status_code=404, detail="Subject not found.")
    return subject


@router.post("", response_model=SubjectResponse, status_code=status.HTTP_201_CREATED)
async def create_subject(
    db: DbSession,
    payload: SubjectCreate,
    current_user=RequireAdmin,
) -> Subject:
    existing = await db.scalar(
        select(Subject).where(
            Subject.code == payload.code,
            Subject.academic_year_id == payload.academic_year_id,
        )
    )
    if existing:
        raise HTTPException(
            status_code=400,
            detail=f"Subject code '{payload.code}' already exists in this academic year.",
        )

    subject = Subject(**payload.model_dump())
    db.add(subject)
    await db.flush()
    await db.refresh(subject)

    await AuditLogService.log(
        db,
        actor_id=current_user.clerk_user_id,
        actor_role=current_user.role,
        action="CREATE_SUBJECT",
        resource_type="subject",
        resource_id=str(subject.id),
        details={"name": subject.name, "code": subject.code},
    )
    return subject


@router.patch("/{subject_id}", response_model=SubjectResponse)
async def update_subject(
    db: DbSession,
    subject_id: UUID,
    payload: SubjectUpdate,
    current_user=RequireAdmin,
) -> Subject:
    subject = await db.get(Subject, subject_id)
    if not subject:
        raise HTTPException(status_code=404, detail="Subject not found.")

    for field, value in payload.model_dump(exclude_unset=True).items():
        setattr(subject, field, value)

    await db.flush()
    await db.refresh(subject)
    return subject


@router.delete("/{subject_id}", response_model=MessageResponse)
async def delete_subject(
    db: DbSession,
    subject_id: UUID,
    current_user=RequireAdmin,
) -> MessageResponse:
    subject = await db.get(Subject, subject_id)
    if not subject:
        raise HTTPException(status_code=404, detail="Subject not found.")
    await db.delete(subject)
    return MessageResponse(message="Subject deleted.")


@router.post("/{subject_id}/assign-teacher/{teacher_id}", response_model=MessageResponse)
async def assign_teacher_to_subject(
    db: DbSession,
    subject_id: UUID,
    teacher_id: UUID,
    current_user=RequireAdmin,
) -> MessageResponse:
    subject = await db.get(Subject, subject_id)
    if not subject:
        raise HTTPException(status_code=404, detail="Subject not found.")
    teacher = await db.get(Teacher, teacher_id)
    if not teacher or not teacher.is_active:
        raise HTTPException(status_code=404, detail="Teacher not found or inactive.")

    existing = await db.scalar(
        select(TeacherSubjectAssignment).where(
            TeacherSubjectAssignment.subject_id == subject_id,
            TeacherSubjectAssignment.teacher_id == teacher_id,
            TeacherSubjectAssignment.academic_year_id == subject.academic_year_id,
        )
    )
    if existing:
        raise HTTPException(status_code=400, detail="Teacher already assigned to this subject.")

    assignment = TeacherSubjectAssignment(
        subject_id=subject_id,
        teacher_id=teacher_id,
        academic_year_id=subject.academic_year_id,
    )
    db.add(assignment)
    return MessageResponse(message="Teacher assigned to subject.")
