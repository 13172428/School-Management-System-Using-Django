"""
Notifications endpoints — list, analytics, retry.
"""
from uuid import UUID

from fastapi import APIRouter, Query
from sqlalchemy import func, select

from app.core.security import RequireAdmin, RequireAnyRole
from app.db.session import DbSession
from app.models.models import Notification, NotificationStatus
from app.schemas.schemas import MessageResponse, NotificationResponse

router = APIRouter()


@router.get("", response_model=list[NotificationResponse])
async def list_notifications(
    db: DbSession,
    _: None = RequireAnyRole,
    student_id: UUID | None = Query(None),
    status: NotificationStatus | None = Query(None),
    skip: int = Query(0, ge=0),
    limit: int = Query(50, ge=1, le=200),
) -> list[Notification]:
    q = select(Notification)
    if student_id:
        q = q.where(Notification.student_id == student_id)
    if status:
        q = q.where(Notification.status == status)
    q = q.order_by(Notification.created_at.desc()).offset(skip).limit(limit)
    result = await db.execute(q)
    return list(result.scalars().all())


@router.get("/analytics")
async def notification_analytics(
    db: DbSession,
    _: None = RequireAnyRole,
    academic_year_id: UUID | None = Query(None),
) -> dict:
    """Returns counts by status and channel."""
    q_status = select(
        Notification.status,
        func.count(Notification.id).label("count"),
    ).group_by(Notification.status)

    q_channel = select(
        Notification.channel,
        func.count(Notification.id).label("count"),
    ).group_by(Notification.channel)

    if academic_year_id:
        q_status = q_status.where(Notification.academic_year_id == academic_year_id)
        q_channel = q_channel.where(Notification.academic_year_id == academic_year_id)

    status_result = await db.execute(q_status)
    channel_result = await db.execute(q_channel)

    return {
        "by_status": [
            {"status": row.status, "count": row.count}
            for row in status_result.all()
        ],
        "by_channel": [
            {"channel": row.channel, "count": row.count}
            for row in channel_result.all()
        ],
    }


@router.get("/{notification_id}", response_model=NotificationResponse)
async def get_notification(
    db: DbSession,
    notification_id: UUID,
    _: None = RequireAnyRole,
) -> Notification:
    from fastapi import HTTPException
    n = await db.get(Notification, notification_id)
    if not n:
        raise HTTPException(status_code=404, detail="Notification not found.")
    return n


@router.post("/{notification_id}/retry", response_model=MessageResponse)
async def retry_notification(
    db: DbSession,
    notification_id: UUID,
    current_user=RequireAdmin,
) -> MessageResponse:
    """Queue a failed notification for retry."""
    from fastapi import HTTPException
    n = await db.get(Notification, notification_id)
    if not n:
        raise HTTPException(status_code=404, detail="Notification not found.")
    if n.status not in (NotificationStatus.FAILED, NotificationStatus.PENDING):
        raise HTTPException(
            status_code=400,
            detail=f"Cannot retry notification with status '{n.status}'.",
        )
    # Reset to pending for Celery to pick up
    n.status = NotificationStatus.PENDING
    n.error_message = None
    return MessageResponse(message="Notification queued for retry.")
