"""
Dashboard API endpoints.
"""
import uuid
from datetime import date

from fastapi import APIRouter, Depends, Query
from sqlalchemy import and_, func, select

from app.core.security import CurrentUser, UserRole, require_role
from app.db.session import DbSession
from app.models.models import (
    Attendance, AttendanceStatus, Class, Exam, FeeStatus,
    Notification, NotificationStatus, Student, StudentClassEnrollment,
    StudentFee, Teacher, TimetableSlot,
)
from app.schemas.schemas import AdminDashboardStats, HolidayResponse, TeacherDashboardStats
from app.services.holiday_service import HolidayService

router = APIRouter(prefix="/dashboard", tags=["Dashboard"])


@router.get("/admin", response_model=AdminDashboardStats)
async def get_admin_dashboard(
    db: DbSession,
    selected_date: date = Query(default=None),
    academic_year_id: uuid.UUID | None = Query(default=None),
    current_user: CurrentUser = Depends(require_role(UserRole.ADMIN)),
):
    from app.models.models import AcademicYear
    query_date = selected_date or date.today()

    if not academic_year_id:
        active_year = (await db.execute(select(AcademicYear).where(AcademicYear.is_active == True))).scalar_one_or_none()
        if active_year:
            academic_year_id = active_year.id

    holiday_svc = HolidayService(db)
    is_holiday = False
    holiday_obj = None
    upcoming_holidays = []
    if academic_year_id:
        is_holiday, holiday_obj = await holiday_svc.is_holiday(query_date, academic_year_id)
        upcoming_holidays = await holiday_svc.get_upcoming_holidays(academic_year_id, from_date=query_date)
    else:
        is_holiday = query_date.weekday() == 6

    total_students = (await db.execute(select(func.count(Student.id)))).scalar_one() or 0
    active_students = (await db.execute(select(func.count(Student.id)).where(Student.is_active == True))).scalar_one() or 0

    present_today = 0
    absent_today = 0
    attendance_pct = 0.0
    if not is_holiday:
        att_counts = (await db.execute(
            select(Attendance.status, func.count(Attendance.id))
            .where(Attendance.attendance_date == query_date)
            .group_by(Attendance.status)
        )).all()
        att_map = {row[0]: row[1] for row in att_counts}
        present_today = att_map.get(AttendanceStatus.PRESENT, 0)
        absent_today = att_map.get(AttendanceStatus.ABSENT, 0)
        total_marked = present_today + absent_today
        attendance_pct = round((present_today / total_marked * 100) if total_marked else 0, 2)

    fee_stats = (await db.execute(
        select(func.sum(StudentFee.amount_due), func.sum(StudentFee.amount_paid))
        .where(StudentFee.academic_year_id == academic_year_id)
    )).one()
    total_fees = float(fee_stats[0] or 0)
    collected_fees = float(fee_stats[1] or 0)
    pending_fees = total_fees - collected_fees
    overdue_fees = float((await db.execute(
        select(func.sum(StudentFee.amount_due - StudentFee.amount_paid))
        .where(and_(StudentFee.academic_year_id == academic_year_id, StudentFee.status == FeeStatus.OVERDUE))
    )).scalar_one() or 0)

    total_teachers = (await db.execute(select(func.count(Teacher.id)))).scalar_one() or 0
    active_teachers = (await db.execute(select(func.count(Teacher.id)).where(Teacher.is_active == True))).scalar_one() or 0

    notif_stats = (await db.execute(
        select(Notification.status, func.count(Notification.id))
        .where(func.date(Notification.sent_at) == query_date)
        .group_by(Notification.status)
    )).all()
    notif_map = {row[0]: row[1] for row in notif_stats}
    notifications_sent = (
        notif_map.get(NotificationStatus.SENT, 0) +
        notif_map.get(NotificationStatus.DELIVERED, 0) +
        notif_map.get(NotificationStatus.READ, 0)
    )
    notifications_failed = notif_map.get(NotificationStatus.FAILED, 0)

    return AdminDashboardStats(
        date=query_date,
        total_students=total_students,
        active_students=active_students,
        present_today=present_today,
        absent_today=absent_today,
        attendance_percentage=attendance_pct,
        total_fees=total_fees,
        collected_fees=collected_fees,
        pending_fees=pending_fees,
        overdue_fees=overdue_fees,
        total_teachers=total_teachers,
        active_teachers=active_teachers,
        notifications_sent=notifications_sent,
        notifications_failed=notifications_failed,
        upcoming_holidays=[HolidayResponse.model_validate(h) for h in upcoming_holidays],
        is_today_holiday=is_holiday,
        holiday_name=holiday_obj.name if holiday_obj else ("Sunday" if query_date.weekday() == 6 else None),
    )


@router.get("/teacher", response_model=TeacherDashboardStats)
async def get_teacher_dashboard(
    db: DbSession,
    selected_date: date = Query(default=None),
    academic_year_id: uuid.UUID | None = Query(default=None),
    current_user: CurrentUser = Depends(require_role(UserRole.TEACHER)),
):
    from sqlalchemy.orm import selectinload
    from app.models.models import Teacher as TeacherModel, AcademicYear

    query_date = selected_date or date.today()

    if not academic_year_id:
        active_year = (await db.execute(select(AcademicYear).where(AcademicYear.is_active == True))).scalar_one_or_none()
        if active_year:
            academic_year_id = active_year.id

    teacher = (await db.execute(select(TeacherModel).where(TeacherModel.clerk_user_id == current_user.clerk_user_id))).scalar_one_or_none()
    if not teacher:
        from fastapi import HTTPException
        raise HTTPException(status_code=404, detail="Teacher profile not found")

    day_of_week = query_date.weekday()
    timetable_slots = []
    if academic_year_id:
        timetable_slots = list((await db.execute(
            select(TimetableSlot)
            .options(selectinload(TimetableSlot.class_), selectinload(TimetableSlot.subject))
            .join(Class, TimetableSlot.class_id == Class.id)
            .where(and_(
                TimetableSlot.teacher_id == teacher.id,
                TimetableSlot.day_of_week == day_of_week,
                Class.academic_year_id == academic_year_id,
            ))
            .order_by(TimetableSlot.period_number)
        )).scalars().all())

    todays_classes = [
        {
            "class_id": str(slot.class_id),
            "class_name": slot.class_.display_name if slot.class_ else "",
            "subject": slot.subject.name if slot.subject else "",
            "start_time": slot.start_time,
            "end_time": slot.end_time,
            "is_attended_marked": False,
        }
        for slot in timetable_slots
    ]

    for cls_item in todays_classes:
        marked_count = (await db.execute(
            select(func.count(Attendance.id)).where(and_(
                Attendance.class_id == uuid.UUID(cls_item["class_id"]),
                Attendance.attendance_date == query_date,
            ))
        )).scalar_one() or 0
        cls_item["is_attended_marked"] = marked_count > 0

    attendance_summary = []
    for class_id_str in list({str(s.class_id) for s in timetable_slots}):
        class_id = uuid.UUID(class_id_str)
        att_map = {row[0]: row[1] for row in (await db.execute(
            select(Attendance.status, func.count(Attendance.id))
            .where(and_(Attendance.class_id == class_id, Attendance.attendance_date == query_date))
            .group_by(Attendance.status)
        )).all()}
        total = (await db.execute(
            select(func.count(StudentClassEnrollment.id))
            .where(and_(StudentClassEnrollment.class_id == class_id, StudentClassEnrollment.is_active == True))
        )).scalar_one() or 0
        present = att_map.get(AttendanceStatus.PRESENT, 0)
        absent = att_map.get(AttendanceStatus.ABSENT, 0)
        cls_slot = next((s for s in timetable_slots if str(s.class_id) == class_id_str), None)
        attendance_summary.append({
            "class_id": class_id_str,
            "class_name": cls_slot.class_.display_name if cls_slot and cls_slot.class_ else class_id_str,
            "present": present,
            "absent": absent,
            "total": total,
            "percentage": round((present / total * 100) if total else 0, 1),
        })

    upcoming_exams = []
    if academic_year_id:
        upcoming_exams = list((await db.execute(
            select(Exam)
            .where(and_(Exam.academic_year_id == academic_year_id, Exam.start_date >= query_date, Exam.is_published == True))
            .order_by(Exam.start_date).limit(5)
        )).scalars().all())

    from app.schemas.schemas import ExamResponse
    return TeacherDashboardStats(
        date=query_date,
        teacher_id=teacher.id,
        todays_classes=todays_classes,
        attendance_summary=attendance_summary,
        upcoming_exams=[ExamResponse.model_validate(e) for e in upcoming_exams],
        pending_attendance_classes=[
            {"class_id": s["class_id"], "class_name": s["class_name"]}
            for s in attendance_summary if s["total"] > (s["present"] + s["absent"])
        ],
    )
