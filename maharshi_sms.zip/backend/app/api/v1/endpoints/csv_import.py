"""
CSV Import endpoints — upload, status, template download, rollback.
"""
from uuid import UUID

from fastapi import APIRouter, HTTPException, Query, UploadFile, status
from fastapi.responses import StreamingResponse
import io

from app.core.security import RequireAdmin, RequireAnyRole
from app.db.session import DbSession
from app.models.models import CSVImportJob, CSVImportStatus, CSVImportType
from app.schemas.schemas import CSVImportJobResponse, MessageResponse
from app.services.audit_service import AuditLogService
from app.services.csv_service import CSVImportService

router = APIRouter()


@router.get("/templates/{import_type}")
async def download_template(
    db: DbSession,
    import_type: CSVImportType,
    _: None = RequireAnyRole,
) -> StreamingResponse:
    """Download a CSV template for the given import type."""
    csv_content = CSVImportService.get_template(import_type)
    filename = f"{import_type.value}_template.csv"
    return StreamingResponse(
        io.StringIO(csv_content),
        media_type="text/csv",
        headers={"Content-Disposition": f'attachment; filename="{filename}"'},
    )


@router.post("/upload", response_model=CSVImportJobResponse, status_code=status.HTTP_201_CREATED)
async def upload_csv(
    file: UploadFile,
    import_type: CSVImportType,
    academic_year_id: UUID,
    current_user=RequireAdmin,
) -> CSVImportJob:
    """Upload a CSV file; triggers background processing."""
    if not file.filename or not file.filename.endswith(".csv"):
        raise HTTPException(status_code=400, detail="Only .csv files are accepted.")

    content = await file.read()
    if len(content) > 5 * 1024 * 1024:  # 5 MB limit
        raise HTTPException(status_code=400, detail="File too large (max 5 MB).")

    csv_text = content.decode("utf-8-sig")  # handle BOM

    job = await CSVImportService.create_job(
        db,
        import_type=import_type,
        academic_year_id=academic_year_id,
        filename=file.filename,
        initiated_by=current_user.clerk_user_id,
    )

    # Process synchronously for now; Celery task can be swapped in
    await CSVImportService.process_import(db, job_id=job.id, csv_text=csv_text)

    await db.refresh(job)

    await AuditLogService.log(
        db,
        actor_id=current_user.clerk_user_id,
        actor_role=current_user.role,
        action="CSV_IMPORT",
        resource_type="csv_import_job",
        resource_id=str(job.id),
        details={
            "import_type": import_type.value,
            "filename": file.filename,
            "status": job.status,
        },
    )
    return job


@router.get("", response_model=list[CSVImportJobResponse])
async def list_import_jobs(
    db: DbSession,
    _: None = RequireAnyRole,
    import_type: CSVImportType | None = Query(None),
    skip: int = Query(0, ge=0),
    limit: int = Query(20, ge=1, le=100),
) -> list[CSVImportJob]:
    from sqlalchemy import select
    q = select(CSVImportJob)
    if import_type:
        q = q.where(CSVImportJob.import_type == import_type)
    q = q.order_by(CSVImportJob.created_at.desc()).offset(skip).limit(limit)
    result = await db.execute(q)
    return list(result.scalars().all())


@router.get("/{job_id}", response_model=CSVImportJobResponse)
async def get_import_job(
    db: DbSession,
    job_id: UUID,
    _: None = RequireAnyRole,
) -> CSVImportJob:
    job = await db.get(CSVImportJob, job_id)
    if not job:
        raise HTTPException(status_code=404, detail="Import job not found.")
    return job


@router.post("/{job_id}/rollback", response_model=MessageResponse)
async def rollback_import(
    db: DbSession,
    job_id: UUID,
    current_user=RequireAdmin,
) -> MessageResponse:
    """Roll back a completed import, deleting all imported records."""
    job = await db.get(CSVImportJob, job_id)
    if not job:
        raise HTTPException(status_code=404, detail="Import job not found.")
    if job.status != CSVImportStatus.COMPLETED:
        raise HTTPException(
            status_code=400,
            detail=f"Can only rollback completed imports. Current status: {job.status}.",
        )

    deleted_count = await CSVImportService.rollback_import(db, job)

    await AuditLogService.log(
        db,
        actor_id=current_user.clerk_user_id,
        actor_role=current_user.role,
        action="CSV_ROLLBACK",
        resource_type="csv_import_job",
        resource_id=str(job_id),
        details={"deleted_count": deleted_count},
    )
    return MessageResponse(
        message=f"Rollback complete. {deleted_count} records deleted."
    )
