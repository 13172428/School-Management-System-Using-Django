"""
Timetable endpoints — CRUD for weekly schedule slots.
"""
from uuid import UUID

from fastapi import APIRouter, HTTPException, Query, status
from sqlalchemy import select

from app.core.security import RequireAdmin, RequireAnyRole
from app.db.session import DbSession
from app.models.models import TimetableSlot
from app.schemas.schemas import (
    MessageResponse,
    TimetableSlotCreate,
    TimetableSlotResponse,
    TimetableSlotUpdate,
)

router = APIRouter()


@router.get("", response_model=list[TimetableSlotResponse])
async def list_timetable_slots(
    db: DbSession,
    _: None = RequireAnyRole,
    class_id: UUID | None = Query(None),
    teacher_id: UUID | None = Query(None),
    academic_year_id: UUID | None = Query(None),
    day_of_week: int | None = Query(None, ge=0, le=6, description="0=Mon, 6=Sun"),
) -> list[TimetableSlot]:
    q = select(TimetableSlot)
    if class_id:
        q = q.where(TimetableSlot.class_id == class_id)
    if teacher_id:
        q = q.where(TimetableSlot.teacher_id == teacher_id)
    if academic_year_id:
        q = q.where(TimetableSlot.academic_year_id == academic_year_id)
    if day_of_week is not None:
        q = q.where(TimetableSlot.day_of_week == day_of_week)
    q = q.order_by(TimetableSlot.day_of_week, TimetableSlot.start_time)
    result = await db.execute(q)
    return list(result.scalars().all())


@router.get("/{slot_id}", response_model=TimetableSlotResponse)
async def get_slot(
    db: DbSession,
    slot_id: UUID,
    _: None = RequireAnyRole,
) -> TimetableSlot:
    slot = await db.get(TimetableSlot, slot_id)
    if not slot:
        raise HTTPException(status_code=404, detail="Timetable slot not found.")
    return slot


@router.post("", response_model=TimetableSlotResponse, status_code=status.HTTP_201_CREATED)
async def create_slot(
    db: DbSession,
    payload: TimetableSlotCreate,
    current_user=RequireAdmin,
) -> TimetableSlot:
    # Check for conflicts: same class, same day, overlapping time
    existing = await db.scalar(
        select(TimetableSlot).where(
            TimetableSlot.class_id == payload.class_id,
            TimetableSlot.day_of_week == payload.day_of_week,
            TimetableSlot.academic_year_id == payload.academic_year_id,
            TimetableSlot.start_time < payload.end_time,
            TimetableSlot.end_time > payload.start_time,
        )
    )
    if existing:
        raise HTTPException(
            status_code=400,
            detail="Timetable conflict: another slot overlaps this time for the same class.",
        )

    # Check teacher not double-booked
    if payload.teacher_id:
        teacher_conflict = await db.scalar(
            select(TimetableSlot).where(
                TimetableSlot.teacher_id == payload.teacher_id,
                TimetableSlot.day_of_week == payload.day_of_week,
                TimetableSlot.academic_year_id == payload.academic_year_id,
                TimetableSlot.start_time < payload.end_time,
                TimetableSlot.end_time > payload.start_time,
            )
        )
        if teacher_conflict:
            raise HTTPException(
                status_code=400,
                detail="Teacher already has a class during this time slot.",
            )

    slot = TimetableSlot(**payload.model_dump())
    db.add(slot)
    await db.flush()
    await db.refresh(slot)
    return slot


@router.patch("/{slot_id}", response_model=TimetableSlotResponse)
async def update_slot(
    db: DbSession,
    slot_id: UUID,
    payload: TimetableSlotUpdate,
    current_user=RequireAdmin,
) -> TimetableSlot:
    slot = await db.get(TimetableSlot, slot_id)
    if not slot:
        raise HTTPException(status_code=404, detail="Timetable slot not found.")
    for field, value in payload.model_dump(exclude_unset=True).items():
        setattr(slot, field, value)
    await db.flush()
    await db.refresh(slot)
    return slot


@router.delete("/{slot_id}", response_model=MessageResponse)
async def delete_slot(
    db: DbSession,
    slot_id: UUID,
    current_user=RequireAdmin,
) -> MessageResponse:
    slot = await db.get(TimetableSlot, slot_id)
    if not slot:
        raise HTTPException(status_code=404, detail="Timetable slot not found.")
    await db.delete(slot)
    return MessageResponse(message="Timetable slot deleted.")


@router.get("/class/{class_id}/week")
async def get_class_weekly_timetable(
    db: DbSession,
    class_id: UUID,
    _: None = RequireAnyRole,
    academic_year_id: UUID | None = Query(None),
) -> dict:
    """Return the full weekly timetable for a class, grouped by day."""
    q = select(TimetableSlot).where(TimetableSlot.class_id == class_id)
    if academic_year_id:
        q = q.where(TimetableSlot.academic_year_id == academic_year_id)
    q = q.order_by(TimetableSlot.day_of_week, TimetableSlot.start_time)
    result = await db.execute(q)
    slots = result.scalars().all()

    days = {i: [] for i in range(7)}
    day_names = ["Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday", "Sunday"]
    for slot in slots:
        days[slot.day_of_week].append(
            {
                "id": str(slot.id),
                "subject_id": str(slot.subject_id) if slot.subject_id else None,
                "teacher_id": str(slot.teacher_id) if slot.teacher_id else None,
                "start_time": str(slot.start_time),
                "end_time": str(slot.end_time),
                "room": slot.room,
            }
        )

    return {day_names[i]: days[i] for i in range(7)}
