"""
Fees endpoints — FeeStructure, StudentFee, Payment recording.
"""
from uuid import UUID

from fastapi import APIRouter, HTTPException, Query, status
from sqlalchemy import select

from app.core.security import RequireAdmin, RequireAnyRole
from app.db.session import DbSession
from app.models.models import FeeStatus, FeeStructure, Payment, Student, StudentFee
from app.schemas.schemas import (
    FeeStructureCreate,
    FeeStructureResponse,
    FeeStructureUpdate,
    MessageResponse,
    PaymentCreate,
    PaymentResponse,
    StudentFeeCreate,
    StudentFeeResponse,
    StudentFeeUpdate,
)
from app.services.audit_service import AuditLogService

router = APIRouter()


# ─── Fee Structures ───────────────────────────────────────────────────────────

@router.get("/structures", response_model=list[FeeStructureResponse])
async def list_fee_structures(
    db: DbSession,
    _: None = RequireAnyRole,
    academic_year_id: UUID | None = Query(None),
) -> list[FeeStructure]:
    q = select(FeeStructure)
    if academic_year_id:
        q = q.where(FeeStructure.academic_year_id == academic_year_id)
    q = q.order_by(FeeStructure.name)
    result = await db.execute(q)
    return list(result.scalars().all())


@router.post(
    "/structures", response_model=FeeStructureResponse, status_code=status.HTTP_201_CREATED
)
async def create_fee_structure(
    db: DbSession,
    payload: FeeStructureCreate,
    current_user=RequireAdmin,
) -> FeeStructure:
    structure = FeeStructure(**payload.model_dump())
    db.add(structure)
    await db.flush()
    await db.refresh(structure)
    await AuditLogService.log(
        db,
        actor_id=current_user.clerk_user_id,
        actor_role=current_user.role,
        action="CREATE_FEE_STRUCTURE",
        resource_type="fee_structure",
        resource_id=str(structure.id),
        details={"name": structure.name, "amount": str(structure.amount)},
    )
    return structure


@router.patch("/structures/{structure_id}", response_model=FeeStructureResponse)
async def update_fee_structure(
    db: DbSession,
    structure_id: UUID,
    payload: FeeStructureUpdate,
    current_user=RequireAdmin,
) -> FeeStructure:
    structure = await db.get(FeeStructure, structure_id)
    if not structure:
        raise HTTPException(status_code=404, detail="Fee structure not found.")
    for field, value in payload.model_dump(exclude_unset=True).items():
        setattr(structure, field, value)
    await db.flush()
    await db.refresh(structure)
    return structure


@router.delete("/structures/{structure_id}", response_model=MessageResponse)
async def delete_fee_structure(
    db: DbSession,
    structure_id: UUID,
    current_user=RequireAdmin,
) -> MessageResponse:
    structure = await db.get(FeeStructure, structure_id)
    if not structure:
        raise HTTPException(status_code=404, detail="Fee structure not found.")

    # Check no fees assigned
    count = await db.scalar(
        select(StudentFee).where(StudentFee.fee_structure_id == structure_id)
    )
    if count:
        raise HTTPException(
            status_code=400,
            detail="Cannot delete a fee structure that has student fees assigned.",
        )
    await db.delete(structure)
    return MessageResponse(message="Fee structure deleted.")


# ─── Student Fees ─────────────────────────────────────────────────────────────

@router.get("", response_model=list[StudentFeeResponse])
async def list_student_fees(
    db: DbSession,
    _: None = RequireAnyRole,
    student_id: UUID | None = Query(None),
    academic_year_id: UUID | None = Query(None),
    status_filter: FeeStatus | None = Query(None, alias="status"),
) -> list[StudentFee]:
    q = select(StudentFee)
    if student_id:
        q = q.where(StudentFee.student_id == student_id)
    if academic_year_id:
        q = q.where(StudentFee.academic_year_id == academic_year_id)
    if status_filter:
        q = q.where(StudentFee.status == status_filter)
    result = await db.execute(q)
    return list(result.scalars().all())


@router.get("/summary")
async def fee_collection_summary(
    db: DbSession,
    _: None = RequireAnyRole,
    academic_year_id: UUID | None = Query(None),
) -> dict:
    """Returns aggregate fee stats."""
    from sqlalchemy import func

    q = select(
        StudentFee.status,
        func.count(StudentFee.id).label("count"),
        func.coalesce(func.sum(StudentFee.amount_due), 0).label("total"),
        func.coalesce(func.sum(StudentFee.amount_paid), 0).label("paid"),
    ).group_by(StudentFee.status)

    if academic_year_id:
        q = q.where(StudentFee.academic_year_id == academic_year_id)

    result = await db.execute(q)
    rows = result.all()
    return {
        "by_status": [
            {
                "status": row.status,
                "count": row.count,
                "total": float(row.total),
                "paid": float(row.paid),
            }
            for row in rows
        ]
    }


@router.post("", response_model=StudentFeeResponse, status_code=status.HTTP_201_CREATED)
async def create_student_fee(
    db: DbSession,
    payload: StudentFeeCreate,
    current_user=RequireAdmin,
) -> StudentFee:
    student = await db.get(Student, payload.student_id)
    if not student:
        raise HTTPException(status_code=400, detail="Student not found.")

    fee = StudentFee(**payload.model_dump())
    db.add(fee)
    await db.flush()
    await db.refresh(fee)
    await AuditLogService.log(
        db,
        actor_id=current_user.clerk_user_id,
        actor_role=current_user.role,
        action="CREATE_STUDENT_FEE",
        resource_type="student_fee",
        resource_id=str(fee.id),
        details={"student_id": str(payload.student_id), "amount_due": str(payload.amount_due)},
    )
    return fee


@router.patch("/{fee_id}", response_model=StudentFeeResponse)
async def update_student_fee(
    db: DbSession,
    fee_id: UUID,
    payload: StudentFeeUpdate,
    current_user=RequireAdmin,
) -> StudentFee:
    fee = await db.get(StudentFee, fee_id)
    if not fee:
        raise HTTPException(status_code=404, detail="Student fee not found.")
    for field, value in payload.model_dump(exclude_unset=True).items():
        setattr(fee, field, value)
    await db.flush()
    await db.refresh(fee)
    return fee


# ─── Payments ─────────────────────────────────────────────────────────────────

@router.post("/{fee_id}/payments", response_model=PaymentResponse, status_code=201)
async def record_payment(
    db: DbSession,
    fee_id: UUID,
    payload: PaymentCreate,
    current_user=RequireAdmin,
) -> Payment:
    fee = await db.get(StudentFee, fee_id)
    if not fee:
        raise HTTPException(status_code=404, detail="Student fee not found.")

    payment = Payment(student_fee_id=fee_id, **payload.model_dump())
    db.add(payment)

    # Update amount_paid and status on StudentFee
    new_paid = (fee.amount_paid or 0) + payload.amount
    fee.amount_paid = new_paid

    if new_paid >= fee.amount_due:
        fee.status = FeeStatus.PAID
    elif new_paid > 0:
        fee.status = FeeStatus.PARTIAL

    await db.flush()
    await db.refresh(payment)

    await AuditLogService.log(
        db,
        actor_id=current_user.clerk_user_id,
        actor_role=current_user.role,
        action="RECORD_PAYMENT",
        resource_type="payment",
        resource_id=str(payment.id),
        details={
            "fee_id": str(fee_id),
            "amount": str(payload.amount),
            "new_fee_status": fee.status,
        },
    )
    return payment


@router.get("/{fee_id}/payments", response_model=list[PaymentResponse])
async def list_payments(
    db: DbSession,
    fee_id: UUID,
    _: None = RequireAnyRole,
) -> list[Payment]:
    result = await db.execute(
        select(Payment)
        .where(Payment.student_fee_id == fee_id)
        .order_by(Payment.payment_date.desc())
    )
    return list(result.scalars().all())
