"""
Students endpoints — CRUD with parent contact management.
Students are not directly linked to academic years; that link is via class enrollment.
"""
from uuid import UUID

from fastapi import APIRouter, HTTPException, Query, status
from sqlalchemy import func, select

from app.core.security import RequireAdmin, RequireAnyRole
from app.db.session import DbSession
from app.models.models import (
    AcademicYear,
    ParentContact,
    Student,
    StudentClassEnrollment,
)
from app.schemas.schemas import (
    MessageResponse,
    StudentCreate,
    StudentResponse,
    StudentUpdate,
)
from app.services.audit_service import AuditLogService

router = APIRouter()


@router.get("", response_model=list[StudentResponse])
async def list_students(
    db: DbSession,
    _: None = RequireAnyRole,
    academic_year_id: UUID | None = Query(None),
    search: str | None = Query(None, min_length=1),
    is_active: bool | None = Query(None),
    skip: int = Query(0, ge=0),
    limit: int = Query(50, ge=1, le=200),
) -> list[Student]:
    q = select(Student)

    # Filter by academic year via enrollment join
    if academic_year_id:
        q = q.join(
            StudentClassEnrollment,
            StudentClassEnrollment.student_id == Student.id,
        ).where(StudentClassEnrollment.academic_year_id == academic_year_id)

    if search:
        pattern = f"%{search}%"
        q = q.where(
            (Student.first_name.ilike(pattern))
            | (Student.last_name.ilike(pattern))
            | (Student.admission_number.ilike(pattern))
        )

    if is_active is not None:
        q = q.where(Student.is_active == is_active)

    q = q.distinct().order_by(Student.first_name, Student.last_name).offset(skip).limit(limit)
    result = await db.execute(q)
    return list(result.scalars().all())


@router.get("/count")
async def count_students(
    db: DbSession,
    _: None = RequireAnyRole,
    academic_year_id: UUID | None = Query(None),
    is_active: bool | None = Query(None),
) -> dict:
    q = select(func.count(Student.id.distinct()))
    if academic_year_id:
        q = (
            select(func.count(Student.id.distinct()))
            .join(StudentClassEnrollment, StudentClassEnrollment.student_id == Student.id)
            .where(StudentClassEnrollment.academic_year_id == academic_year_id)
        )
    if is_active is not None:
        q = q.where(Student.is_active == is_active)
    count = await db.scalar(q)
    return {"count": count or 0}


@router.get("/{student_id}", response_model=StudentResponse)
async def get_student(
    db: DbSession,
    student_id: UUID,
    _: None = RequireAnyRole,
) -> Student:
    student = await db.get(Student, student_id)
    if not student:
        raise HTTPException(status_code=404, detail="Student not found.")
    return student


@router.post("", response_model=StudentResponse, status_code=status.HTTP_201_CREATED)
async def create_student(
    db: DbSession,
    payload: StudentCreate,
    current_user=RequireAdmin,
) -> Student:
    # Check admission number uniqueness (global — admission numbers are unique school-wide)
    existing = await db.scalar(
        select(Student).where(Student.admission_number == payload.admission_number)
    )
    if existing:
        raise HTTPException(
            status_code=400,
            detail=f"Admission number '{payload.admission_number}' already exists.",
        )

    student_data = payload.model_dump(exclude={"parent_contacts"})
    student = Student(**student_data)
    db.add(student)
    await db.flush()

    # Add parent contacts
    if payload.parent_contacts:
        for contact_data in payload.parent_contacts:
            contact = ParentContact(student_id=student.id, **contact_data.model_dump())
            db.add(contact)

    await db.flush()
    await db.refresh(student)

    await AuditLogService.log(
        db,
        actor_id=current_user.clerk_user_id,
        actor_role=current_user.role,
        action="CREATE_STUDENT",
        resource_type="student",
        resource_id=str(student.id),
        details={"name": student.full_name, "admission_number": student.admission_number},
    )
    return student


@router.patch("/{student_id}", response_model=StudentResponse)
async def update_student(
    db: DbSession,
    student_id: UUID,
    payload: StudentUpdate,
    current_user=RequireAdmin,
) -> Student:
    student = await db.get(Student, student_id)
    if not student:
        raise HTTPException(status_code=404, detail="Student not found.")

    update_data = payload.model_dump(exclude_unset=True)
    for field, value in update_data.items():
        setattr(student, field, value)

    await db.flush()
    await db.refresh(student)
    await AuditLogService.log(
        db,
        actor_id=current_user.clerk_user_id,
        actor_role=current_user.role,
        action="UPDATE_STUDENT",
        resource_type="student",
        resource_id=str(student.id),
        details=update_data,
    )
    return student


@router.delete("/{student_id}", response_model=MessageResponse)
async def delete_student(
    db: DbSession,
    student_id: UUID,
    current_user=RequireAdmin,
) -> MessageResponse:
    student = await db.get(Student, student_id)
    if not student:
        raise HTTPException(status_code=404, detail="Student not found.")

    # Soft delete: mark inactive
    student.is_active = False
    await AuditLogService.log(
        db,
        actor_id=current_user.clerk_user_id,
        actor_role=current_user.role,
        action="DEACTIVATE_STUDENT",
        resource_type="student",
        resource_id=str(student_id),
    )
    return MessageResponse(message="Student deactivated successfully.")


@router.get("/{student_id}/classes")
async def get_student_enrollments(
    db: DbSession,
    student_id: UUID,
    _: None = RequireAnyRole,
) -> list[dict]:
    """Return class enrollment history for a student."""
    result = await db.execute(
        select(StudentClassEnrollment).where(StudentClassEnrollment.student_id == student_id)
    )
    enrollments = result.scalars().all()
    return [
        {
            "class_id": str(e.class_id),
            "academic_year_id": str(e.academic_year_id),
            "roll_number": e.roll_number,
            "enrollment_date": e.enrollment_date.isoformat() if e.enrollment_date else None,
            "is_active": e.is_active,
        }
        for e in enrollments
    ]


@router.post("/{student_id}/parent-contacts", response_model=MessageResponse)
async def add_parent_contact(
    db: DbSession,
    student_id: UUID,
    payload: dict,
    current_user=RequireAdmin,
) -> MessageResponse:
    student = await db.get(Student, student_id)
    if not student:
        raise HTTPException(status_code=404, detail="Student not found.")
    contact = ParentContact(student_id=student_id, **payload)
    db.add(contact)
    return MessageResponse(message="Parent contact added.")
