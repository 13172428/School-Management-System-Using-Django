"""
Classes endpoints — CRUD + student enrollment.
"""
from uuid import UUID

from fastapi import APIRouter, HTTPException, Query, status
from sqlalchemy import select

from app.core.security import RequireAdmin, RequireAnyRole
from app.db.session import DbSession
from app.models.models import (
    AcademicYear,
    Class,
    Student,
    StudentClassEnrollment,
    Teacher,
    ClassTeacherAssignment,
)
from app.schemas.schemas import (
    ClassCreate,
    ClassResponse,
    ClassUpdate,
    MessageResponse,
)
from app.services.audit_service import AuditLogService

router = APIRouter()


@router.get("", response_model=list[ClassResponse])
async def list_classes(
    db: DbSession,
    _: None = RequireAnyRole,
    academic_year_id: UUID | None = Query(None),
) -> list[Class]:
    q = select(Class)
    if academic_year_id:
        q = q.where(Class.academic_year_id == academic_year_id)
    q = q.order_by(Class.name, Class.section)
    result = await db.execute(q)
    return list(result.scalars().all())


@router.get("/{class_id}", response_model=ClassResponse)
async def get_class(
    db: DbSession,
    class_id: UUID,
    _: None = RequireAnyRole,
) -> Class:
    cls = await db.get(Class, class_id)
    if not cls:
        raise HTTPException(status_code=404, detail="Class not found.")
    return cls


@router.post("", response_model=ClassResponse, status_code=status.HTTP_201_CREATED)
async def create_class(
    db: DbSession,
    payload: ClassCreate,
    current_user=RequireAdmin,
) -> Class:
    year = await db.get(AcademicYear, payload.academic_year_id)
    if not year:
        raise HTTPException(status_code=400, detail="Academic year not found.")
    if year.is_archived:
        raise HTTPException(status_code=400, detail="Cannot create class in archived year.")

    # Check uniqueness: name+section within academic year
    existing = await db.scalar(
        select(Class).where(
            Class.name == payload.name,
            Class.section == payload.section,
            Class.academic_year_id == payload.academic_year_id,
        )
    )
    if existing:
        raise HTTPException(
            status_code=400,
            detail=f"Class {payload.name}-{payload.section} already exists for this academic year.",
        )

    cls = Class(**payload.model_dump())
    db.add(cls)
    await db.flush()
    await db.refresh(cls)

    await AuditLogService.log(
        db,
        actor_id=current_user.clerk_user_id,
        actor_role=current_user.role,
        action="CREATE_CLASS",
        resource_type="class",
        resource_id=str(cls.id),
        details={"name": cls.name, "section": cls.section},
    )
    return cls


@router.patch("/{class_id}", response_model=ClassResponse)
async def update_class(
    db: DbSession,
    class_id: UUID,
    payload: ClassUpdate,
    current_user=RequireAdmin,
) -> Class:
    cls = await db.get(Class, class_id)
    if not cls:
        raise HTTPException(status_code=404, detail="Class not found.")

    for field, value in payload.model_dump(exclude_unset=True).items():
        setattr(cls, field, value)

    await db.flush()
    await db.refresh(cls)
    return cls


@router.delete("/{class_id}", response_model=MessageResponse)
async def delete_class(
    db: DbSession,
    class_id: UUID,
    current_user=RequireAdmin,
) -> MessageResponse:
    cls = await db.get(Class, class_id)
    if not cls:
        raise HTTPException(status_code=404, detail="Class not found.")

    # Check no students enrolled
    count = await db.scalar(
        select(StudentClassEnrollment).where(StudentClassEnrollment.class_id == class_id)
    )
    if count:
        raise HTTPException(
            status_code=400,
            detail="Cannot delete a class with enrolled students. Remove enrollments first.",
        )

    await db.delete(cls)
    return MessageResponse(message="Class deleted.")


@router.get("/{class_id}/students")
async def get_class_students(
    db: DbSession,
    class_id: UUID,
    _: None = RequireAnyRole,
) -> list[dict]:
    result = await db.execute(
        select(Student, StudentClassEnrollment)
        .join(StudentClassEnrollment, StudentClassEnrollment.student_id == Student.id)
        .where(StudentClassEnrollment.class_id == class_id)
        .order_by(StudentClassEnrollment.roll_number)
    )
    rows = result.all()
    return [
        {
            "id": str(s.id),
            "roll_number": enrollment.roll_number,
            "full_name": s.full_name,
            "is_active": s.is_active,
        }
        for s, enrollment in rows
    ]


@router.post("/{class_id}/enroll/{student_id}", response_model=MessageResponse)
async def enroll_student(
    db: DbSession,
    class_id: UUID,
    student_id: UUID,
    current_user=RequireAdmin,
) -> MessageResponse:
    cls = await db.get(Class, class_id)
    if not cls:
        raise HTTPException(status_code=404, detail="Class not found.")
    student = await db.get(Student, student_id)
    if not student:
        raise HTTPException(status_code=404, detail="Student not found.")

    # Check not already enrolled
    existing = await db.scalar(
        select(StudentClassEnrollment).where(
            StudentClassEnrollment.class_id == class_id,
            StudentClassEnrollment.student_id == student_id,
        )
    )
    if existing:
        raise HTTPException(status_code=400, detail="Student already enrolled in this class.")

    enrollment = StudentClassEnrollment(
        class_id=class_id,
        student_id=student_id,
        academic_year_id=cls.academic_year_id,
    )
    db.add(enrollment)
    await AuditLogService.log(
        db,
        actor_id=current_user.clerk_user_id,
        actor_role=current_user.role,
        action="ENROLL_STUDENT",
        resource_type="enrollment",
        resource_id=str(student_id),
        details={"class_id": str(class_id)},
    )
    return MessageResponse(message="Student enrolled successfully.")


@router.delete("/{class_id}/enroll/{student_id}", response_model=MessageResponse)
async def unenroll_student(
    db: DbSession,
    class_id: UUID,
    student_id: UUID,
    current_user=RequireAdmin,
) -> MessageResponse:
    enrollment = await db.scalar(
        select(StudentClassEnrollment).where(
            StudentClassEnrollment.class_id == class_id,
            StudentClassEnrollment.student_id == student_id,
        )
    )
    if not enrollment:
        raise HTTPException(status_code=404, detail="Enrollment not found.")
    await db.delete(enrollment)
    return MessageResponse(message="Student unenrolled.")


@router.post("/{class_id}/assign-teacher/{teacher_id}", response_model=MessageResponse)
async def assign_class_teacher(
    db: DbSession,
    class_id: UUID,
    teacher_id: UUID,
    current_user=RequireAdmin,
) -> MessageResponse:
    cls = await db.get(Class, class_id)
    if not cls:
        raise HTTPException(status_code=404, detail="Class not found.")
    teacher = await db.get(Teacher, teacher_id)
    if not teacher:
        raise HTTPException(status_code=404, detail="Teacher not found.")

    existing = await db.scalar(
        select(ClassTeacherAssignment).where(
            ClassTeacherAssignment.class_id == class_id,
            ClassTeacherAssignment.academic_year_id == cls.academic_year_id,
        )
    )
    if existing:
        existing.teacher_id = teacher_id
    else:
        assignment = ClassTeacherAssignment(
            class_id=class_id,
            teacher_id=teacher_id,
            academic_year_id=cls.academic_year_id,
        )
        db.add(assignment)

    return MessageResponse(message="Class teacher assigned.")
