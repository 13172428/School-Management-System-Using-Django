"""
WhatsApp Cloud API webhook endpoints.
"""
from fastapi import APIRouter, HTTPException, Query, Request
from fastapi.responses import PlainTextResponse

from app.core.logging import get_logger
from app.db.session import DbSession
from app.services.attendance_service import AttendanceService
from app.services.holiday_service import HolidayService
from app.services.whatsapp_service import WhatsAppService

logger = get_logger(__name__)
router = APIRouter(prefix="/webhooks/whatsapp", tags=["WhatsApp Webhook"])


def get_wa_service(db: DbSession) -> WhatsAppService:
    holiday_svc = HolidayService(db)
    attendance_svc = AttendanceService(db, holiday_svc)
    return WhatsAppService(db, attendance_svc)


@router.get("")
async def verify_webhook(
    hub_mode: str = Query(alias="hub.mode", default=""),
    hub_verify_token: str = Query(alias="hub.verify_token", default=""),
    hub_challenge: str = Query(alias="hub.challenge", default=""),
):
    wa_svc_temp = WhatsAppService.__new__(WhatsAppService)
    challenge = wa_svc_temp.verify_webhook(hub_mode, hub_verify_token, hub_challenge)
    if challenge is None:
        raise HTTPException(status_code=403, detail="Invalid verification token")
    return PlainTextResponse(challenge)


@router.post("")
async def receive_webhook(
    db: DbSession,
    request: Request,
):
    try:
        payload = await request.json()
    except Exception:
        raise HTTPException(status_code=400, detail="Invalid JSON payload")

    logger.debug("whatsapp_webhook_received", payload=str(payload)[:500])
    wa_svc = get_wa_service(db)

    for entry in payload.get("entry", []):
        for change in entry.get("changes", []):
            value = change.get("value", {})
            for status_update in value.get("statuses", []):
                await wa_svc.handle_status_update(status_update)

    result = await wa_svc.handle_webhook(payload)
    await db.commit()
    return {"status": "ok", **result}
