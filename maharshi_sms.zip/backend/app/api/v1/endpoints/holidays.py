"""
Holidays endpoints — CRUD using HolidayService.
"""
from datetime import date
from uuid import UUID

from fastapi import APIRouter, HTTPException, Query, status

from app.core.security import RequireAdmin, RequireAnyRole
from app.db.session import DbSession
from app.schemas.schemas import (
    HolidayCreate,
    HolidayResponse,
    HolidayUpdate,
    MessageResponse,
)
from app.services.audit_service import AuditLogService
from app.services.holiday_service import HolidayService

router = APIRouter()


@router.get("", response_model=list[HolidayResponse])
async def list_holidays(
    db: DbSession,
    _: None = RequireAnyRole,
    academic_year_id: UUID | None = Query(None),
    from_date: date | None = Query(None),
    to_date: date | None = Query(None),
) -> list:
    from sqlalchemy import and_, select
    from app.models.models import Holiday
    stmt = select(Holiday).where(Holiday.is_active == True)
    if academic_year_id:
        stmt = stmt.where(Holiday.academic_year_id == academic_year_id)
    if from_date:
        stmt = stmt.where(Holiday.end_date >= from_date)
    if to_date:
        stmt = stmt.where(Holiday.start_date <= to_date)
    stmt = stmt.order_by(Holiday.start_date)
    result = await db.execute(stmt)
    return list(result.scalars().all())


@router.get("/upcoming", response_model=list[HolidayResponse])
async def get_upcoming_holidays(
    db: DbSession,
    _: None = RequireAnyRole,
    days: int = Query(30, ge=1, le=365),
    academic_year_id: UUID | None = Query(None),
) -> list:
    svc = HolidayService(db)
    return await svc.get_upcoming_holidays(
        academic_year_id=academic_year_id, limit=days
    )


@router.get("/check")
async def check_is_holiday(
    db: DbSession,
    date: date,
    _: None = RequireAnyRole,
    academic_year_id: UUID | None = Query(None),
) -> dict:
    """Check if a specific date is a holiday/Sunday."""
    svc = HolidayService(db)
    if academic_year_id:
        is_hol, _ = await svc.is_holiday(date, academic_year_id)
    else:
        # No academic year: only check Sunday
        is_hol = date.weekday() == 6
    return {
        "date": date.isoformat(),
        "is_holiday": is_hol,
        "is_sunday": date.weekday() == 6,
    }


@router.get("/{holiday_id}", response_model=HolidayResponse)
async def get_holiday(
    db: DbSession,
    holiday_id: UUID,
    _: None = RequireAnyRole,
) -> object:
    from sqlalchemy import select
    from app.models.models import Holiday
    holiday = await db.get(Holiday, holiday_id)
    if not holiday:
        raise HTTPException(status_code=404, detail="Holiday not found.")
    return holiday


@router.post("", response_model=HolidayResponse, status_code=status.HTTP_201_CREATED)
async def create_holiday(
    db: DbSession,
    payload: HolidayCreate,
    current_user=RequireAdmin,
) -> object:
    from app.models.models import Holiday
    holiday = Holiday(**payload.model_dump())
    db.add(holiday)
    await db.flush()
    await db.refresh(holiday)
    await AuditLogService.log(
        db,
        actor_id=current_user.clerk_user_id,
        actor_role=current_user.role,
        action="CREATE_HOLIDAY",
        resource_type="holiday",
        resource_id=str(holiday.id),
        details={"name": holiday.name},
    )
    return holiday


@router.patch("/{holiday_id}", response_model=HolidayResponse)
async def update_holiday(
    db: DbSession,
    holiday_id: UUID,
    payload: HolidayUpdate,
    current_user=RequireAdmin,
) -> object:
    from app.models.models import Holiday
    holiday = await db.get(Holiday, holiday_id)
    if not holiday:
        raise HTTPException(status_code=404, detail="Holiday not found.")
    for field, value in payload.model_dump(exclude_unset=True).items():
        setattr(holiday, field, value)
    await db.flush()
    await db.refresh(holiday)
    await AuditLogService.log(
        db,
        actor_id=current_user.clerk_user_id,
        actor_role=current_user.role,
        action="UPDATE_HOLIDAY",
        resource_type="holiday",
        resource_id=str(holiday_id),
        details=payload.model_dump(exclude_unset=True),
    )
    return holiday


@router.delete("/{holiday_id}", response_model=MessageResponse)
async def delete_holiday(
    db: DbSession,
    holiday_id: UUID,
    current_user=RequireAdmin,
) -> MessageResponse:
    from app.models.models import Holiday
    holiday = await db.get(Holiday, holiday_id)
    if not holiday:
        raise HTTPException(status_code=404, detail="Holiday not found.")
    await db.delete(holiday)
    await AuditLogService.log(
        db,
        actor_id=current_user.clerk_user_id,
        actor_role=current_user.role,
        action="DELETE_HOLIDAY",
        resource_type="holiday",
        resource_id=str(holiday_id),
    )
    return MessageResponse(message="Holiday deleted.")
