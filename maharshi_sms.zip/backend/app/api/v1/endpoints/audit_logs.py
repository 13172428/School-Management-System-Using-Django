"""
Audit logs endpoints — read-only, admin only.
"""
from datetime import datetime
from uuid import UUID

from fastapi import APIRouter, Query

from app.core.security import RequireAdmin
from app.db.session import DbSession
from app.schemas.schemas import AuditLogResponse
from app.services.audit_service import AuditLogService

router = APIRouter()


@router.get("", response_model=list[AuditLogResponse])
async def list_audit_logs(
    db: DbSession,
    _: None = RequireAdmin,
    actor_id: str | None = Query(None),
    resource_type: str | None = Query(None),
    resource_id: str | None = Query(None),
    action: str | None = Query(None),
    from_dt: datetime | None = Query(None),
    to_dt: datetime | None = Query(None),
    skip: int = Query(0, ge=0),
    limit: int = Query(50, ge=1, le=200),
) -> list:
    return await AuditLogService.get_logs(
        db,
        actor_id=actor_id,
        resource_type=resource_type,
        resource_id=resource_id,
        action=action,
        from_dt=from_dt,
        to_dt=to_dt,
        skip=skip,
        limit=limit,
    )
