"""
Exams endpoints — Exam CRUD, schedules, and results.
"""
from uuid import UUID

from fastapi import APIRouter, HTTPException, Query, status
from sqlalchemy import select

from app.core.security import RequireAdmin, RequireAnyRole, RequireTeacher
from app.db.session import DbSession
from app.models.models import Exam, ExamResult, ExamSchedule, Student
from app.schemas.schemas import (
    ExamCreate,
    ExamResponse,
    ExamResultCreate,
    ExamResultResponse,
    ExamResultUpdate,
    ExamScheduleCreate,
    ExamScheduleResponse,
    ExamUpdate,
    MessageResponse,
)
from app.services.audit_service import AuditLogService

router = APIRouter()


# ─── Exams ───────────────────────────────────────────────────────────────────

@router.get("", response_model=list[ExamResponse])
async def list_exams(
    db: DbSession,
    _: None = RequireAnyRole,
    academic_year_id: UUID | None = Query(None),
) -> list[Exam]:
    q = select(Exam)
    if academic_year_id:
        q = q.where(Exam.academic_year_id == academic_year_id)
    q = q.order_by(Exam.start_date.desc())
    result = await db.execute(q)
    return list(result.scalars().all())


@router.get("/{exam_id}", response_model=ExamResponse)
async def get_exam(
    db: DbSession,
    exam_id: UUID,
    _: None = RequireAnyRole,
) -> Exam:
    exam = await db.get(Exam, exam_id)
    if not exam:
        raise HTTPException(status_code=404, detail="Exam not found.")
    return exam


@router.post("", response_model=ExamResponse, status_code=status.HTTP_201_CREATED)
async def create_exam(
    db: DbSession,
    payload: ExamCreate,
    current_user=RequireAdmin,
) -> Exam:
    exam = Exam(**payload.model_dump())
    db.add(exam)
    await db.flush()
    await db.refresh(exam)
    await AuditLogService.log(
        db,
        actor_id=current_user.clerk_user_id,
        actor_role=current_user.role,
        action="CREATE_EXAM",
        resource_type="exam",
        resource_id=str(exam.id),
        details={"name": exam.name},
    )
    return exam


@router.patch("/{exam_id}", response_model=ExamResponse)
async def update_exam(
    db: DbSession,
    exam_id: UUID,
    payload: ExamUpdate,
    current_user=RequireAdmin,
) -> Exam:
    exam = await db.get(Exam, exam_id)
    if not exam:
        raise HTTPException(status_code=404, detail="Exam not found.")
    for field, value in payload.model_dump(exclude_unset=True).items():
        setattr(exam, field, value)
    await db.flush()
    await db.refresh(exam)
    return exam


@router.delete("/{exam_id}", response_model=MessageResponse)
async def delete_exam(
    db: DbSession,
    exam_id: UUID,
    current_user=RequireAdmin,
) -> MessageResponse:
    exam = await db.get(Exam, exam_id)
    if not exam:
        raise HTTPException(status_code=404, detail="Exam not found.")
    await db.delete(exam)
    return MessageResponse(message="Exam deleted.")


# ─── Exam Schedules ───────────────────────────────────────────────────────────

@router.get("/{exam_id}/schedules", response_model=list[ExamScheduleResponse])
async def list_exam_schedules(
    db: DbSession,
    exam_id: UUID,
    _: None = RequireAnyRole,
) -> list[ExamSchedule]:
    result = await db.execute(
        select(ExamSchedule)
        .where(ExamSchedule.exam_id == exam_id)
        .order_by(ExamSchedule.exam_date, ExamSchedule.start_time)
    )
    return list(result.scalars().all())


@router.post("/{exam_id}/schedules", response_model=ExamScheduleResponse, status_code=201)
async def create_exam_schedule(
    db: DbSession,
    exam_id: UUID,
    payload: ExamScheduleCreate,
    current_user=RequireAdmin,
) -> ExamSchedule:
    exam = await db.get(Exam, exam_id)
    if not exam:
        raise HTTPException(status_code=404, detail="Exam not found.")

    schedule = ExamSchedule(exam_id=exam_id, **payload.model_dump())
    db.add(schedule)
    await db.flush()
    await db.refresh(schedule)
    return schedule


@router.delete("/schedules/{schedule_id}", response_model=MessageResponse)
async def delete_exam_schedule(
    db: DbSession,
    schedule_id: UUID,
    current_user=RequireAdmin,
) -> MessageResponse:
    schedule = await db.get(ExamSchedule, schedule_id)
    if not schedule:
        raise HTTPException(status_code=404, detail="Schedule not found.")
    await db.delete(schedule)
    return MessageResponse(message="Schedule deleted.")


# ─── Exam Results ─────────────────────────────────────────────────────────────

@router.get("/{exam_id}/results", response_model=list[ExamResultResponse])
async def list_exam_results(
    db: DbSession,
    exam_id: UUID,
    _: None = RequireAnyRole,
    class_id: UUID | None = Query(None),
    subject_id: UUID | None = Query(None),
) -> list[ExamResult]:
    q = select(ExamResult).where(ExamResult.exam_id == exam_id)
    if class_id:
        q = q.where(ExamResult.class_id == class_id)
    if subject_id:
        q = q.where(ExamResult.subject_id == subject_id)
    result = await db.execute(q)
    return list(result.scalars().all())


@router.post("/{exam_id}/results", response_model=list[ExamResultResponse], status_code=201)
async def bulk_create_results(
    db: DbSession,
    exam_id: UUID,
    payload: list[ExamResultCreate],
    current_user=RequireTeacher,
) -> list[ExamResult]:
    """Bulk upsert exam results (insert or update per student+subject)."""
    exam = await db.get(Exam, exam_id)
    if not exam:
        raise HTTPException(status_code=404, detail="Exam not found.")

    results = []
    for item in payload:
        # Check if result already exists
        existing = await db.scalar(
            select(ExamResult).where(
                ExamResult.exam_id == exam_id,
                ExamResult.student_id == item.student_id,
                ExamResult.subject_id == item.subject_id,
            )
        )
        if existing:
            for field, value in item.model_dump(exclude_unset=True).items():
                setattr(existing, field, value)
            results.append(existing)
        else:
            result = ExamResult(exam_id=exam_id, **item.model_dump())
            db.add(result)
            results.append(result)

    await db.flush()
    for r in results:
        await db.refresh(r)

    await AuditLogService.log(
        db,
        actor_id=current_user.clerk_user_id,
        actor_role=current_user.role,
        action="BULK_ENTER_RESULTS",
        resource_type="exam_result",
        resource_id=str(exam_id),
        details={"count": len(results)},
    )
    return results


@router.patch("/results/{result_id}", response_model=ExamResultResponse)
async def update_exam_result(
    db: DbSession,
    result_id: UUID,
    payload: ExamResultUpdate,
    current_user=RequireTeacher,
) -> ExamResult:
    result = await db.get(ExamResult, result_id)
    if not result:
        raise HTTPException(status_code=404, detail="Result not found.")
    for field, value in payload.model_dump(exclude_unset=True).items():
        setattr(result, field, value)
    await db.flush()
    await db.refresh(result)
    return result


@router.get("/results/student/{student_id}", response_model=list[ExamResultResponse])
async def get_student_results(
    db: DbSession,
    student_id: UUID,
    _: None = RequireAnyRole,
    academic_year_id: UUID | None = Query(None),
) -> list[ExamResult]:
    q = (
        select(ExamResult)
        .join(Exam, Exam.id == ExamResult.exam_id)
        .where(ExamResult.student_id == student_id)
    )
    if academic_year_id:
        q = q.where(Exam.academic_year_id == academic_year_id)
    result = await db.execute(q)
    return list(result.scalars().all())
