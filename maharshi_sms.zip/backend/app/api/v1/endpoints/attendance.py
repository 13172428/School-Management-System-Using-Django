"""
Attendance API endpoints.
"""
import uuid
from datetime import date
from typing import Optional

from fastapi import APIRouter, BackgroundTasks, Depends, HTTPException, Query, status
from fastapi.responses import StreamingResponse

from app.core.security import CurrentUser, UserRole, require_role
from app.db.session import DbSession
from app.models.models import AttendanceStatus, Student, StudentClassEnrollment
from app.schemas.schemas import (
    AttendanceBulkCreate,
    AttendanceResponse,
    AttendanceSummary,
    MessageResponse,
)
from app.services.attendance_service import AttendanceService
from app.services.audit_service import AuditLogService
from app.services.holiday_service import HolidayService
from app.services.report_service import ReportService
from app.services.whatsapp_service import WhatsAppService

router = APIRouter(prefix="/attendance", tags=["Attendance"])


def get_services(db: DbSession):
    holiday_svc = HolidayService(db)
    attendance_svc = AttendanceService(db, holiday_svc)
    wa_svc = WhatsAppService(db, attendance_svc)
    report_svc = ReportService(db)
    return attendance_svc, wa_svc, report_svc


@router.get("/class/{class_id}", response_model=list[AttendanceResponse])
async def get_class_attendance(
    db: DbSession,
    class_id: uuid.UUID,
    attendance_date: date = Query(...),
    current_user: CurrentUser = Depends(require_role(UserRole.ADMIN, UserRole.TEACHER)),
):
    attendance_svc, _, _ = get_services(db)
    records = await attendance_svc.get_class_attendance(class_id, attendance_date)

    from sqlalchemy import and_, select
    from sqlalchemy.orm import selectinload

    enroll_stmt = (
        select(StudentClassEnrollment)
        .options(selectinload(StudentClassEnrollment.student))
        .where(and_(
            StudentClassEnrollment.class_id == class_id,
            StudentClassEnrollment.is_active == True,
        ))
    )
    result = await db.execute(enroll_stmt)
    enrollments = result.scalars().all()
    enrollment_by_student = {e.student_id: e for e in enrollments}

    response = []
    for rec in records:
        enr = enrollment_by_student.get(rec.student_id)
        response.append(AttendanceResponse(
            id=rec.id,
            student_id=rec.student_id,
            class_id=rec.class_id,
            attendance_date=rec.attendance_date,
            status=rec.status,
            remarks=rec.remarks,
            parent_reason=rec.parent_reason,
            parent_reason_locked=rec.parent_reason_locked,
            whatsapp_response_status=rec.whatsapp_response_status,
            student_name=enr.student.full_name if enr and enr.student else None,
            roll_number=enr.roll_number if enr else None,
        ))
    return response


@router.get("/class/{class_id}/summary", response_model=AttendanceSummary)
async def get_attendance_summary(
    db: DbSession,
    class_id: uuid.UUID,
    attendance_date: date = Query(...),
    current_user: CurrentUser = Depends(require_role(UserRole.ADMIN, UserRole.TEACHER)),
):
    attendance_svc, _, _ = get_services(db)
    summary = await attendance_svc.get_attendance_summary(class_id, attendance_date)
    return AttendanceSummary(**summary)


@router.get("/class/{class_id}/enrolled", response_model=list[dict])
async def get_enrolled_students(
    db: DbSession,
    class_id: uuid.UUID,
    current_user: CurrentUser = Depends(require_role(UserRole.ADMIN, UserRole.TEACHER)),
):
    attendance_svc, _, _ = get_services(db)
    enrollments = await attendance_svc.get_enrolled_students(class_id)
    return [
        {
            "student_id": str(e.student_id),
            "roll_number": e.roll_number,
            "student_name": e.student.full_name if e.student else "",
            "admission_number": e.student.admission_number if e.student else "",
        }
        for e in enrollments
    ]


@router.post("/bulk", response_model=dict)
async def bulk_mark_attendance(
    db: DbSession,
    data: AttendanceBulkCreate,
    background_tasks: BackgroundTasks,
    current_user: CurrentUser = Depends(require_role(UserRole.ADMIN, UserRole.TEACHER)),
):
    from app.core.config import settings
    from sqlalchemy import select as sa_select

    attendance_svc, wa_svc, _ = get_services(db)

    teacher_id: Optional[uuid.UUID] = None
    if current_user.role == UserRole.TEACHER:
        from app.models.models import Teacher
        stmt = sa_select(Teacher).where(Teacher.clerk_user_id == current_user.clerk_user_id)
        teacher = (await db.execute(stmt)).scalar_one_or_none()
        if teacher:
            teacher_id = teacher.id

    from app.models.models import Class
    cls = (await db.execute(sa_select(Class).where(Class.id == data.class_id))).scalar_one_or_none()
    if not cls:
        raise HTTPException(status_code=404, detail="Class not found")

    try:
        attendance_records, absent_ids = await attendance_svc.bulk_mark_attendance(
            class_id=data.class_id,
            academic_year_id=cls.academic_year_id,
            attendance_date=data.attendance_date,
            records=data.records,
            teacher_id=teacher_id or uuid.UUID("00000000-0000-0000-0000-000000000000"),
        )
    except ValueError as e:
        raise HTTPException(status_code=400, detail=str(e))

    await AuditLogService.log(
        db,
        action="bulk_attendance_marked",
        resource_type="attendance",
        resource_id=str(data.class_id),
        actor_id=current_user.clerk_user_id,
        actor_role=current_user.role,
        actor_name=current_user.full_name,
        details={"date": str(data.attendance_date), "total": len(data.records), "absent": len(absent_ids)},
    )

    if data.send_whatsapp_notifications and absent_ids:
        async def send_notifications():
            from sqlalchemy import and_
            from sqlalchemy.orm import selectinload as sil
            from app.models.models import Attendance

            for student_id in absent_ids:
                try:
                    student_stmt = sa_select(Student).options(sil(Student.parent_contacts)).where(Student.id == student_id)
                    student = (await db.execute(student_stmt)).scalar_one_or_none()
                    if not student:
                        continue
                    att = (await db.execute(sa_select(Attendance).where(and_(
                        Attendance.student_id == student_id,
                        Attendance.attendance_date == data.attendance_date,
                        Attendance.class_id == data.class_id,
                    )))).scalar_one_or_none()
                    if not att:
                        continue
                    parent = next(
                        (p for p in student.parent_contacts if p.is_primary and p.whatsapp_number),
                        next((p for p in student.parent_contacts if p.whatsapp_number), None),
                    )
                    if parent:
                        await wa_svc.send_absence_notification(
                            student=student, attendance=att, parent_contact=parent, school_name=settings.SCHOOL_NAME,
                        )
                        await db.commit()
                except Exception as e:
                    from app.core.logging import get_logger
                    get_logger().error("notification_error", student_id=str(student_id), error=str(e))

        background_tasks.add_task(send_notifications)

    return {
        "message": "Attendance marked successfully",
        "total": len(attendance_records),
        "absent": len(absent_ids),
        "notifications_queued": len(absent_ids) if data.send_whatsapp_notifications else 0,
    }


@router.get("/student/{student_id}/stats", response_model=dict)
async def get_student_attendance_stats(
    db: DbSession,
    student_id: uuid.UUID,
    academic_year_id: uuid.UUID = Query(...),
    from_date: Optional[date] = Query(None),
    to_date: Optional[date] = Query(None),
    current_user: CurrentUser = Depends(require_role(UserRole.ADMIN, UserRole.TEACHER)),
):
    attendance_svc, _, _ = get_services(db)
    return await attendance_svc.get_student_attendance_stats(student_id, academic_year_id, from_date, to_date)


@router.get("/class/{class_id}/report/daily")
async def download_daily_attendance_report(
    db: DbSession,
    class_id: uuid.UUID,
    attendance_date: date = Query(...),
    current_user: CurrentUser = Depends(require_role(UserRole.ADMIN, UserRole.TEACHER)),
):
    _, _, report_svc = get_services(db)
    try:
        pdf_bytes = await report_svc.generate_daily_attendance_pdf(class_id, attendance_date)
    except ValueError as e:
        raise HTTPException(status_code=404, detail=str(e))
    import io
    return StreamingResponse(io.BytesIO(pdf_bytes), media_type="application/pdf",
        headers={"Content-Disposition": f"attachment; filename=attendance_{attendance_date}.pdf"})


@router.get("/class/{class_id}/report/monthly")
async def download_monthly_attendance_report(
    db: DbSession,
    class_id: uuid.UUID,
    year: int = Query(...),
    month: int = Query(..., ge=1, le=12),
    academic_year_id: uuid.UUID = Query(...),
    current_user: CurrentUser = Depends(require_role(UserRole.ADMIN, UserRole.TEACHER)),
):
    _, _, report_svc = get_services(db)
    try:
        pdf_bytes = await report_svc.generate_monthly_attendance_pdf(class_id, year, month, academic_year_id)
    except ValueError as e:
        raise HTTPException(status_code=404, detail=str(e))
    import io
    return StreamingResponse(io.BytesIO(pdf_bytes), media_type="application/pdf",
        headers={"Content-Disposition": f"attachment; filename=attendance_{year}_{month:02d}.pdf"})
