"""
WhatsApp Cloud API Service.
Sends interactive absence notifications with 3-button reason selection.
Implements lock-on-first-reply to prevent overwriting confirmed reasons.

Flow:
1. Teacher marks student absent
2. System sends interactive WhatsApp message to parent with 3 quick-reply buttons
3. Parent taps a reason button
4. System records reason, locks the attendance record, sends confirmation
5. If parent attempts to reply again: system sends "already locked" message
"""
import uuid
from datetime import date, datetime, timezone
from typing import Any, Optional

import httpx
from sqlalchemy import and_, select
from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy.orm import selectinload

from app.core.config import settings
from app.core.logging import get_logger
from app.models.models import (
    Attendance,
    AttendanceStatus,
    Notification,
    NotificationChannel,
    NotificationStatus,
    ParentContact,
    Student,
    WhatsAppResponseStatus,
)
from app.services.attendance_service import AttendanceService

logger = get_logger(__name__)

# Absence reason options — matches the WhatsApp interactive buttons
ABSENCE_REASONS = {
    "reason_1": "Suffering from Fever or Other Illness",
    "reason_2": "Going to Function or Out of Town",
    "reason_3": "Emergency Work",
}


class WhatsAppService:
    def __init__(self, db: AsyncSession, attendance_service: AttendanceService):
        self.db = db
        self.attendance_svc = attendance_service
        self._client: Optional[httpx.AsyncClient] = None

    @property
    def _http(self) -> httpx.AsyncClient:
        if self._client is None:
            self._client = httpx.AsyncClient(
                base_url=settings.whatsapp_api_url,
                headers={
                    "Authorization": f"Bearer {settings.WHATSAPP_ACCESS_TOKEN}",
                    "Content-Type": "application/json",
                },
                timeout=30.0,
            )
        return self._client

    async def close(self) -> None:
        if self._client:
            await self._client.aclose()
            self._client = None

    # ─── Send Absence Notification ─────────────────────────────────────────────

    async def send_absence_notification(
        self,
        student: Student,
        attendance: Attendance,
        parent_contact: ParentContact,
        school_name: str,
    ) -> Optional[str]:
        """
        Send interactive absence notification to parent.
        Returns WhatsApp message ID or None on failure.
        """
        if not parent_contact.whatsapp_number:
            logger.warning(
                "no_whatsapp_number",
                student_id=str(student.id),
                parent_id=str(parent_contact.id),
            )
            return None

        formatted_date = attendance.attendance_date.strftime("%d %b %Y")
        phone = self._normalize_phone(parent_contact.whatsapp_number)

        payload = {
            "messaging_product": "whatsapp",
            "recipient_type": "individual",
            "to": phone,
            "type": "interactive",
            "interactive": {
                "type": "button",
                "body": {
                    "text": (
                        f"Dear Parent of {student.full_name},\n\n"
                        f"Your child was marked ABSENT today ({formatted_date}) "
                        f"at {school_name}.\n\n"
                        f"Please select a reason for absence by tapping one of the buttons below:\n"
                        f"1️⃣ Reason 1: {ABSENCE_REASONS['reason_1']}\n"
                        f"2️⃣ Reason 2: {ABSENCE_REASONS['reason_2']}\n"
                        f"3️⃣ Reason 3: {ABSENCE_REASONS['reason_3']}"
                    )
                },
                "footer": {"text": f"— {school_name}"},
                "action": {
                    "buttons": [
                        {
                            "type": "reply",
                            "reply": {
                                "id": f"reason_1_{attendance.id}",
                                "title": "Reason 1",
                            },
                        },
                        {
                            "type": "reply",
                            "reply": {
                                "id": f"reason_2_{attendance.id}",
                                "title": "Reason 2",
                            },
                        },
                        {
                            "type": "reply",
                            "reply": {
                                "id": f"reason_3_{attendance.id}",
                                "title": "Reason 3",
                            },
                        },
                    ]
                },
            },
        }

        try:
            response = await self._http.post("/messages", json=payload)
            response.raise_for_status()
            data = response.json()
            message_id = data.get("messages", [{}])[0].get("id")

            # Record notification
            notification = Notification(
                student_id=student.id,
                parent_contact_id=parent_contact.id,
                channel=NotificationChannel.WHATSAPP,
                recipient_number=phone,
                message_body=payload["interactive"]["body"]["text"],
                status=NotificationStatus.SENT,
                whatsapp_message_id=message_id,
                sent_at=datetime.now(timezone.utc),
                notification_type="attendance",
                extra_data={
                    "attendance_id": str(attendance.id),
                    "attendance_date": str(attendance.attendance_date),
                },
            )
            self.db.add(notification)

            # Update attendance with sent timestamp
            attendance.whatsapp_notification_sent_at = datetime.now(timezone.utc)
            await self.db.flush()

            logger.info(
                "whatsapp_absence_sent",
                student_id=str(student.id),
                phone=phone,
                message_id=message_id,
            )
            return message_id

        except httpx.HTTPStatusError as e:
            logger.error(
                "whatsapp_send_failed",
                student_id=str(student.id),
                phone=phone,
                status_code=e.response.status_code,
                response=e.response.text,
            )
            # Record failed notification
            notification = Notification(
                student_id=student.id,
                parent_contact_id=parent_contact.id,
                channel=NotificationChannel.WHATSAPP,
                recipient_number=phone,
                status=NotificationStatus.FAILED,
                error_message=str(e),
                notification_type="attendance",
            )
            self.db.add(notification)
            await self.db.flush()
            return None

    # ─── Webhook Handler ───────────────────────────────────────────────────────

    async def handle_webhook(self, payload: dict) -> dict:
        """
        Process incoming WhatsApp webhook.
        Handles interactive button replies from parents.
        """
        results = []
        try:
            entry = payload.get("entry", [])
            for entry_item in entry:
                changes = entry_item.get("changes", [])
                for change in changes:
                    value = change.get("value", {})
                    messages = value.get("messages", [])
                    for message in messages:
                        result = await self._process_message(message, value)
                        if result:
                            results.append(result)
        except Exception as e:
            logger.error("webhook_processing_error", error=str(e))

        return {"processed": len(results), "results": results}

    async def _process_message(self, message: dict, value: dict) -> Optional[dict]:
        """Process a single incoming WhatsApp message."""
        msg_type = message.get("type")
        from_number = message.get("from")

        if msg_type != "interactive":
            logger.debug("non_interactive_message_ignored", type=msg_type)
            return None

        interactive = message.get("interactive", {})
        if interactive.get("type") != "button_reply":
            return None

        button_reply = interactive.get("button_reply", {})
        button_id = button_reply.get("id", "")

        # Parse button_id: format is "reason_X_<attendance_uuid>"
        parts = button_id.split("_", 2)
        if len(parts) < 3 or parts[0] != "reason":
            logger.warning("unrecognized_button_id", button_id=button_id)
            return None

        reason_key = f"reason_{parts[1]}"
        attendance_id_str = parts[2]

        try:
            attendance_id = uuid.UUID(attendance_id_str)
        except ValueError:
            logger.error("invalid_attendance_id_in_button", raw=attendance_id_str)
            return None

        reason_text = ABSENCE_REASONS.get(reason_key)
        if not reason_text:
            return None

        # Get attendance record
        stmt = (
            select(Attendance)
            .options(
                selectinload(Attendance.student).selectinload(Student.parent_contacts)
            )
            .where(Attendance.id == attendance_id)
        )
        attendance = (await self.db.execute(stmt)).scalar_one_or_none()
        if not attendance:
            logger.error("attendance_not_found_in_webhook", id=attendance_id_str)
            return None

        # Check if already locked
        if attendance.parent_reason_locked:
            await self._send_already_locked_message(from_number, attendance, reason_text)
            return {"status": "already_locked", "attendance_id": attendance_id_str}

        # Lock the reason
        attendance.parent_reason = reason_text
        attendance.parent_reason_locked = True
        attendance.whatsapp_response_status = WhatsAppResponseStatus.LOCKED
        await self.db.flush()

        # Send confirmation
        student_name = attendance.student.full_name if attendance.student else "your child"
        await self._send_reason_confirmation(from_number, student_name, reason_text)

        logger.info(
            "parent_reason_recorded",
            attendance_id=attendance_id_str,
            reason=reason_text,
            from_number=from_number,
        )
        return {"status": "recorded", "reason": reason_text, "attendance_id": attendance_id_str}

    async def _send_already_locked_message(
        self, to: str, attendance: Attendance, attempted_reason: str
    ) -> None:
        """Inform parent their reason is already locked and cannot be changed."""
        existing_reason = attendance.parent_reason or "Unknown"
        payload = {
            "messaging_product": "whatsapp",
            "recipient_type": "individual",
            "to": to,
            "type": "text",
            "text": {
                "body": (
                    f"⚠️ This leave request has already been locked.\n\n"
                    f"Your recorded reason is:\n{existing_reason}\n\n"
                    f"If you need to change this, please contact the school administration directly."
                )
            },
        }
        try:
            await self._http.post("/messages", json=payload)
        except Exception as e:
            logger.error("failed_to_send_locked_message", error=str(e))

    async def _send_reason_confirmation(
        self, to: str, student_name: str, reason: str
    ) -> None:
        """Send confirmation after reason is recorded."""
        payload = {
            "messaging_product": "whatsapp",
            "recipient_type": "individual",
            "to": to,
            "type": "text",
            "text": {
                "body": (
                    f"✅ Thank you.\n\n"
                    f"Your leave reason has been recorded successfully.\n\n"
                    f"Selected Reason:\n{reason}\n\n"
                    f"— {settings.SCHOOL_NAME}"
                )
            },
        }
        try:
            await self._http.post("/messages", json=payload)
        except Exception as e:
            logger.error("failed_to_send_confirmation", error=str(e))

    # ─── Webhook Verification ──────────────────────────────────────────────────

    def verify_webhook(self, mode: str, token: str, challenge: str) -> Optional[str]:
        """Verify WhatsApp webhook subscription."""
        if mode == "subscribe" and token == settings.WHATSAPP_WEBHOOK_VERIFY_TOKEN:
            return challenge
        return None

    # ─── Delivery Status Update ────────────────────────────────────────────────

    async def handle_status_update(self, status_data: dict) -> None:
        """Update notification delivery status from webhook."""
        message_id = status_data.get("id")
        status = status_data.get("status")

        if not message_id or not status:
            return

        stmt = select(Notification).where(Notification.whatsapp_message_id == message_id)
        notification = (await self.db.execute(stmt)).scalar_one_or_none()
        if not notification:
            return

        status_map = {
            "sent": NotificationStatus.SENT,
            "delivered": NotificationStatus.DELIVERED,
            "read": NotificationStatus.READ,
            "failed": NotificationStatus.FAILED,
        }
        new_status = status_map.get(status)
        if new_status:
            notification.status = new_status
            if new_status == NotificationStatus.DELIVERED:
                notification.delivered_at = datetime.now(timezone.utc)
            await self.db.flush()

    async def _send_text_message(self, phone: str, text: str) -> Optional[str]:
        """Send a plain text WhatsApp message. Returns message_id or None."""
        normalized = self._normalize_phone(phone)
        payload = {
            "messaging_product": "whatsapp",
            "recipient_type": "individual",
            "to": normalized,
            "type": "text",
            "text": {"body": text},
        }
        try:
            response = await self._http.post("/messages", json=payload)
            response.raise_for_status()
            data = response.json()
            return data.get("messages", [{}])[0].get("id")
        except Exception as e:
            logger.error("text_message_failed", phone=normalized, error=str(e))
            return None

    # ─── Helpers ───────────────────────────────────────────────────────────────

    @staticmethod
    def _normalize_phone(phone: str) -> str:
        """Normalize phone number to E.164 format without + prefix."""
        normalized = phone.strip().replace(" ", "").replace("-", "").replace("(", "").replace(")", "")
        if normalized.startswith("+"):
            normalized = normalized[1:]
        # Default to India (+91) if no country code (10 digit number)
        if len(normalized) == 10 and normalized.isdigit():
            normalized = f"91{normalized}"
        return normalized
