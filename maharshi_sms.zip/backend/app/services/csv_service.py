"""
CSV Import Service.
Handles import of Students, Teachers, Fees, and Marks.
Supports validation, duplicate detection, error reporting, and rollback.
"""
import io
import uuid
from datetime import date, datetime, timezone
from typing import Any, Optional

import pandas as pd
from sqlalchemy import select
from sqlalchemy.exc import IntegrityError
from sqlalchemy.ext.asyncio import AsyncSession

from app.core.logging import get_logger
from app.models.models import (
    CSVImportJob,
    CSVImportStatus,
    CSVImportType,
    ExamResult,
    FeeStructure,
    ParentContact,
    Student,
    StudentFee,
    Teacher,
)

logger = get_logger(__name__)


# ─── Column Definitions ────────────────────────────────────────────────────────

STUDENT_COLUMNS = {
    "required": ["admission_number", "first_name", "last_name"],
    "optional": [
        "date_of_birth", "gender", "blood_group", "address",
        "admission_date", "parent_name", "parent_phone", "parent_whatsapp",
        "parent_email", "parent_relationship",
    ],
}

TEACHER_COLUMNS = {
    "required": ["employee_id", "first_name", "last_name", "email"],
    "optional": [
        "phone", "whatsapp_number", "qualification",
        "joining_date", "address",
    ],
}

FEE_COLUMNS = {
    "required": ["admission_number", "fee_structure_name", "amount_due"],
    "optional": ["due_date", "concession_amount", "concession_reason"],
}

MARKS_COLUMNS = {
    "required": ["admission_number", "exam_name", "subject_code", "marks_obtained"],
    "optional": ["max_marks", "is_absent", "remarks"],
}


class CSVImportService:
    def __init__(self, db: AsyncSession):
        self.db = db

    # ─── Templates ────────────────────────────────────────────────────────────

    def get_template(self, import_type: CSVImportType) -> bytes:
        """Generate a downloadable CSV template."""
        templates = {
            CSVImportType.STUDENTS: pd.DataFrame(columns=[
                "admission_number", "first_name", "last_name",
                "date_of_birth", "gender", "blood_group",
                "address", "admission_date",
                "parent_name", "parent_phone", "parent_whatsapp",
                "parent_email", "parent_relationship",
            ]),
            CSVImportType.TEACHERS: pd.DataFrame(columns=[
                "employee_id", "first_name", "last_name", "email",
                "phone", "whatsapp_number", "qualification",
                "joining_date", "address",
            ]),
            CSVImportType.FEES: pd.DataFrame(columns=[
                "admission_number", "fee_structure_name", "amount_due",
                "due_date", "concession_amount", "concession_reason",
            ]),
            CSVImportType.MARKS: pd.DataFrame(columns=[
                "admission_number", "exam_name", "subject_code",
                "marks_obtained", "max_marks", "is_absent", "remarks",
            ]),
        }
        df = templates[import_type]
        buffer = io.BytesIO()
        df.to_csv(buffer, index=False)
        return buffer.getvalue()

    # ─── Main Import ──────────────────────────────────────────────────────────

    async def process_import(
        self,
        job_id: uuid.UUID,
        file_content: bytes,
        import_type: CSVImportType,
        academic_year_id: Optional[uuid.UUID],
        initiated_by: str,
    ) -> CSVImportJob:
        """Process a CSV import job."""
        # Get job record
        stmt = select(CSVImportJob).where(CSVImportJob.id == job_id)
        job = (await self.db.execute(stmt)).scalar_one()

        job.status = CSVImportStatus.PROCESSING
        job.started_at = datetime.now(timezone.utc)
        await self.db.flush()

        errors: list[dict] = []
        imported_ids: list[str] = []

        try:
            df = pd.read_csv(io.BytesIO(file_content))
            df.columns = df.columns.str.strip().str.lower().str.replace(" ", "_")
            total_rows = len(df)
            job.total_rows = total_rows

            if import_type == CSVImportType.STUDENTS:
                result = await self._import_students(df, errors)
            elif import_type == CSVImportType.TEACHERS:
                result = await self._import_teachers(df, errors)
            elif import_type == CSVImportType.FEES:
                result = await self._import_fees(df, academic_year_id, errors)
            elif import_type == CSVImportType.MARKS:
                result = await self._import_marks(df, errors)
            else:
                raise ValueError(f"Unsupported import type: {import_type}")

            imported_ids = result["ids"]
            job.success_rows = result["success"]
            job.duplicate_rows = result["duplicates"]
            job.error_rows = len(errors)
            job.processed_rows = total_rows
            job.errors = errors
            job.imported_ids = imported_ids
            job.status = CSVImportStatus.COMPLETED
            job.completed_at = datetime.now(timezone.utc)

            logger.info(
                "csv_import_completed",
                job_id=str(job_id),
                type=import_type,
                total=total_rows,
                success=result["success"],
                errors=len(errors),
            )

        except Exception as e:
            job.status = CSVImportStatus.FAILED
            job.errors = [{"row": 0, "error": str(e)}]
            job.completed_at = datetime.now(timezone.utc)
            logger.error("csv_import_failed", job_id=str(job_id), error=str(e))

        await self.db.flush()
        return job

    # ─── Student Import ───────────────────────────────────────────────────────

    async def _import_students(
        self, df: pd.DataFrame, errors: list[dict]
    ) -> dict:
        required = STUDENT_COLUMNS["required"]
        missing = [c for c in required if c not in df.columns]
        if missing:
            raise ValueError(f"Missing required columns: {missing}")

        success = 0
        duplicates = 0
        ids: list[str] = []

        for idx, row in df.iterrows():
            row_num = idx + 2  # 1-indexed + header
            try:
                admission_number = str(row["admission_number"]).strip()
                if not admission_number or admission_number == "nan":
                    errors.append({"row": row_num, "error": "admission_number is required"})
                    continue

                # Check duplicate
                stmt = select(Student).where(Student.admission_number == admission_number)
                existing = (await self.db.execute(stmt)).scalar_one_or_none()
                if existing:
                    duplicates += 1
                    continue

                student = Student(
                    admission_number=admission_number,
                    first_name=str(row["first_name"]).strip(),
                    last_name=str(row["last_name"]).strip(),
                    date_of_birth=self._parse_date(row.get("date_of_birth")),
                    gender=self._safe_str(row.get("gender")),
                    blood_group=self._safe_str(row.get("blood_group")),
                    address=self._safe_str(row.get("address")),
                    admission_date=self._parse_date(row.get("admission_date")),
                )
                self.db.add(student)
                await self.db.flush()

                # Add parent contact if provided
                parent_name = self._safe_str(row.get("parent_name"))
                if parent_name:
                    parent = ParentContact(
                        student_id=student.id,
                        name=parent_name,
                        relationship_type=self._safe_str(row.get("parent_relationship")) or "guardian",
                        phone=self._safe_str(row.get("parent_phone")),
                        whatsapp_number=self._safe_str(row.get("parent_whatsapp")),
                        email=self._safe_str(row.get("parent_email")),
                        is_primary=True,
                    )
                    self.db.add(parent)
                    await self.db.flush()

                ids.append(str(student.id))
                success += 1

            except Exception as e:
                errors.append({"row": row_num, "error": str(e)})

        return {"success": success, "duplicates": duplicates, "ids": ids}

    # ─── Teacher Import ───────────────────────────────────────────────────────

    async def _import_teachers(
        self, df: pd.DataFrame, errors: list[dict]
    ) -> dict:
        required = TEACHER_COLUMNS["required"]
        missing = [c for c in required if c not in df.columns]
        if missing:
            raise ValueError(f"Missing required columns: {missing}")

        success = 0
        duplicates = 0
        ids: list[str] = []

        for idx, row in df.iterrows():
            row_num = idx + 2
            try:
                employee_id = str(row["employee_id"]).strip()
                email = str(row["email"]).strip().lower()

                # Check duplicates
                stmt = select(Teacher).where(
                    (Teacher.employee_id == employee_id) | (Teacher.email == email)
                )
                existing = (await self.db.execute(stmt)).scalar_one_or_none()
                if existing:
                    duplicates += 1
                    continue

                teacher = Teacher(
                    employee_id=employee_id,
                    first_name=str(row["first_name"]).strip(),
                    last_name=str(row["last_name"]).strip(),
                    email=email,
                    phone=self._safe_str(row.get("phone")),
                    whatsapp_number=self._safe_str(row.get("whatsapp_number")),
                    qualification=self._safe_str(row.get("qualification")),
                    joining_date=self._parse_date(row.get("joining_date")),
                    address=self._safe_str(row.get("address")),
                )
                self.db.add(teacher)
                await self.db.flush()
                ids.append(str(teacher.id))
                success += 1

            except Exception as e:
                errors.append({"row": row_num, "error": str(e)})

        return {"success": success, "duplicates": duplicates, "ids": ids}

    # ─── Fee Import ───────────────────────────────────────────────────────────

    async def _import_fees(
        self,
        df: pd.DataFrame,
        academic_year_id: Optional[uuid.UUID],
        errors: list[dict],
    ) -> dict:
        if not academic_year_id:
            raise ValueError("academic_year_id is required for fee import")

        success = 0
        duplicates = 0
        ids: list[str] = []

        for idx, row in df.iterrows():
            row_num = idx + 2
            try:
                admission_number = str(row["admission_number"]).strip()
                fee_structure_name = str(row["fee_structure_name"]).strip()

                # Find student
                stmt = select(Student).where(Student.admission_number == admission_number)
                student = (await self.db.execute(stmt)).scalar_one_or_none()
                if not student:
                    errors.append({"row": row_num, "error": f"Student not found: {admission_number}"})
                    continue

                # Find fee structure
                stmt = select(FeeStructure).where(
                    FeeStructure.name == fee_structure_name,
                    FeeStructure.academic_year_id == academic_year_id,
                )
                fee_structure = (await self.db.execute(stmt)).scalar_one_or_none()
                if not fee_structure:
                    errors.append({"row": row_num, "error": f"Fee structure not found: {fee_structure_name}"})
                    continue

                # Check duplicate
                stmt = select(StudentFee).where(
                    StudentFee.student_id == student.id,
                    StudentFee.fee_structure_id == fee_structure.id,
                )
                existing = (await self.db.execute(stmt)).scalar_one_or_none()
                if existing:
                    duplicates += 1
                    continue

                student_fee = StudentFee(
                    student_id=student.id,
                    fee_structure_id=fee_structure.id,
                    academic_year_id=academic_year_id,
                    amount_due=float(row["amount_due"]),
                    due_date=self._parse_date(row.get("due_date")),
                    concession_amount=float(row.get("concession_amount", 0) or 0),
                    concession_reason=self._safe_str(row.get("concession_reason")),
                )
                self.db.add(student_fee)
                await self.db.flush()
                ids.append(str(student_fee.id))
                success += 1

            except Exception as e:
                errors.append({"row": row_num, "error": str(e)})

        return {"success": success, "duplicates": duplicates, "ids": ids}

    # ─── Marks Import ─────────────────────────────────────────────────────────

    async def _import_marks(
        self, df: pd.DataFrame, errors: list[dict]
    ) -> dict:
        from app.models.models import Exam, ExamResult, Subject

        success = 0
        duplicates = 0
        ids: list[str] = []

        for idx, row in df.iterrows():
            row_num = idx + 2
            try:
                admission_number = str(row["admission_number"]).strip()
                exam_name = str(row["exam_name"]).strip()
                subject_code = str(row["subject_code"]).strip()

                # Find entities
                student = (await self.db.execute(
                    select(Student).where(Student.admission_number == admission_number)
                )).scalar_one_or_none()
                if not student:
                    errors.append({"row": row_num, "error": f"Student not found: {admission_number}"})
                    continue

                exam = (await self.db.execute(
                    select(Exam).where(Exam.name == exam_name)
                )).scalar_one_or_none()
                if not exam:
                    errors.append({"row": row_num, "error": f"Exam not found: {exam_name}"})
                    continue

                subject = (await self.db.execute(
                    select(Subject).where(Subject.code == subject_code)
                )).scalar_one_or_none()
                if not subject:
                    errors.append({"row": row_num, "error": f"Subject not found: {subject_code}"})
                    continue

                # Check duplicate
                existing = (await self.db.execute(
                    select(ExamResult).where(
                        ExamResult.exam_id == exam.id,
                        ExamResult.student_id == student.id,
                        ExamResult.subject_id == subject.id,
                    )
                )).scalar_one_or_none()
                if existing:
                    duplicates += 1
                    continue

                is_absent_raw = str(row.get("is_absent", "false")).lower()
                is_absent = is_absent_raw in ("true", "1", "yes")
                marks_raw = row.get("marks_obtained")
                marks = None if is_absent or pd.isna(marks_raw) else float(marks_raw)

                result = ExamResult(
                    exam_id=exam.id,
                    student_id=student.id,
                    subject_id=subject.id,
                    marks_obtained=marks,
                    max_marks=int(row.get("max_marks", 100) or 100),
                    is_absent=is_absent,
                    remarks=self._safe_str(row.get("remarks")),
                )
                self.db.add(result)
                await self.db.flush()
                ids.append(str(result.id))
                success += 1

            except Exception as e:
                errors.append({"row": row_num, "error": str(e)})

        return {"success": success, "duplicates": duplicates, "ids": ids}

    # ─── Rollback ─────────────────────────────────────────────────────────────

    async def rollback_import(self, job_id: uuid.UUID) -> CSVImportJob:
        """Rollback a completed import by deleting all imported records."""
        stmt = select(CSVImportJob).where(CSVImportJob.id == job_id)
        job = (await self.db.execute(stmt)).scalar_one_or_none()
        if not job:
            raise ValueError(f"Import job {job_id} not found")

        if job.status not in (CSVImportStatus.COMPLETED,):
            raise ValueError(f"Cannot rollback job with status: {job.status}")

        if job.imported_ids:
            # Delete based on import type
            from sqlalchemy import delete

            if job.import_type == CSVImportType.STUDENTS:
                ids = [uuid.UUID(i) for i in job.imported_ids]
                await self.db.execute(
                    delete(Student).where(Student.id.in_(ids))
                )
            elif job.import_type == CSVImportType.TEACHERS:
                ids = [uuid.UUID(i) for i in job.imported_ids]
                await self.db.execute(
                    delete(Teacher).where(Teacher.id.in_(ids))
                )
            elif job.import_type == CSVImportType.FEES:
                ids = [uuid.UUID(i) for i in job.imported_ids]
                await self.db.execute(
                    delete(StudentFee).where(StudentFee.id.in_(ids))
                )
            elif job.import_type == CSVImportType.MARKS:
                ids = [uuid.UUID(i) for i in job.imported_ids]
                await self.db.execute(
                    delete(ExamResult).where(ExamResult.id.in_(ids))
                )

        job.status = CSVImportStatus.ROLLED_BACK
        await self.db.flush()
        logger.info("csv_import_rolled_back", job_id=str(job_id))
        return job

    # ─── Helpers ──────────────────────────────────────────────────────────────

    @staticmethod
    def _safe_str(value: Any) -> Optional[str]:
        if value is None or (isinstance(value, float) and pd.isna(value)):
            return None
        s = str(value).strip()
        return s if s and s.lower() != "nan" else None

    @staticmethod
    def _parse_date(value: Any) -> Optional[date]:
        if value is None or (isinstance(value, float) and pd.isna(value)):
            return None
        try:
            if isinstance(value, date):
                return value
            from dateutil import parser
            return parser.parse(str(value)).date()
        except Exception:
            return None
