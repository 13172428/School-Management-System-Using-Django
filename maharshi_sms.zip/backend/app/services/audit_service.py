"""
Audit Log Service.
Records all important system actions with actor context.

Usage in endpoints (class method, db passed as first arg):
    await AuditLogService.log(
        db,
        actor_id=current_user.clerk_user_id,
        actor_role=current_user.role,
        action="ACTION",
        resource_type="resource",
        resource_id=str(obj.id),
        details={"key": "value"},
    )

Usage in services (instance method):
    svc = AuditLogService(db)
    await svc.log(action=..., resource_type=..., ...)
"""
from typing import Any, Optional

from sqlalchemy import select
from sqlalchemy.ext.asyncio import AsyncSession

from app.core.logging import get_logger
from app.models.models import AuditLog

logger = get_logger(__name__)


class AuditLogService:
    def __init__(self, db: AsyncSession):
        self.db = db

    # ── Endpoint-facing class method (db is explicit first arg) ───────────────

    @classmethod
    async def log(
        cls,
        db: AsyncSession,
        *,
        action: str,
        resource_type: str,
        resource_id: Optional[str] = None,
        actor_id: Optional[str] = None,
        actor_role: Optional[Any] = None,
        actor_name: Optional[str] = None,
        details: Optional[dict] = None,
        ip_address: Optional[str] = None,
    ) -> AuditLog:
        """
        Class-level helper: create an audit log entry.
        Called as: await AuditLogService.log(db, actor_id=..., action=..., ...)
        """
        role_str = (
            actor_role.value if hasattr(actor_role, "value")
            else str(actor_role) if actor_role else None
        )
        audit = AuditLog(
            actor_clerk_id=actor_id,
            actor_role=role_str,
            actor_name=actor_name,
            action=action,
            resource_type=resource_type,
            resource_id=str(resource_id) if resource_id else None,
            new_values=details,
            ip_address=ip_address,
        )
        db.add(audit)
        await db.flush()
        logger.info(
            "audit_log_created",
            action=action,
            resource_type=resource_type,
            resource_id=str(resource_id) if resource_id else None,
            actor=actor_id,
        )
        return audit

    # ── Instance method used by attendance/dashboard services ─────────────────

    async def log_event(
        self,
        *,
        action: str,
        resource_type: str,
        resource_id: Optional[str] = None,
        actor_clerk_id: Optional[str] = None,
        actor_role: Optional[Any] = None,
        actor_name: Optional[str] = None,
        new_values: Optional[dict] = None,
        ip_address: Optional[str] = None,
    ) -> AuditLog:
        return await AuditLogService.log(
            self.db,
            action=action,
            resource_type=resource_type,
            resource_id=resource_id,
            actor_id=actor_clerk_id,
            actor_role=actor_role,
            actor_name=actor_name,
            details=new_values,
            ip_address=ip_address,
        )

    async def get_logs(
        self,
        resource_type: Optional[str] = None,
        resource_id: Optional[str] = None,
        actor_clerk_id: Optional[str] = None,
        limit: int = 100,
        offset: int = 0,
    ) -> list[AuditLog]:
        """Query audit logs with optional filters."""
        stmt = select(AuditLog).order_by(AuditLog.created_at.desc())

        if resource_type:
            stmt = stmt.where(AuditLog.resource_type == resource_type)
        if resource_id:
            stmt = stmt.where(AuditLog.resource_id == resource_id)
        if actor_clerk_id:
            stmt = stmt.where(AuditLog.actor_clerk_id == actor_clerk_id)

        stmt = stmt.limit(limit).offset(offset)
        result = await self.db.execute(stmt)
        return list(result.scalars().all())
