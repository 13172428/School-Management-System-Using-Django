"""
Holiday Service.
Manages school holidays and provides date checking utilities.
Sundays are treated as holidays by default.
"""
import uuid
from datetime import date, timedelta
from typing import Optional

from sqlalchemy import and_, select
from sqlalchemy.ext.asyncio import AsyncSession

from app.core.logging import get_logger
from app.models.models import Holiday, HolidayType
from app.schemas.holiday import HolidayCreate, HolidayUpdate

logger = get_logger(__name__)


class HolidayService:
    def __init__(self, db: AsyncSession):
        self.db = db

    async def is_holiday(
        self, check_date: date, academic_year_id: uuid.UUID
    ) -> tuple[bool, Optional[Holiday]]:
        """
        Check if a given date is a holiday.
        Sundays are always considered holidays.
        Returns (is_holiday, holiday_record_or_None).
        """
        # Sunday check (weekday() == 6)
        if check_date.weekday() == 6:
            return True, None

        stmt = select(Holiday).where(
            and_(
                Holiday.academic_year_id == academic_year_id,
                Holiday.start_date <= check_date,
                Holiday.end_date >= check_date,
                Holiday.is_active == True,
            )
        )
        result = await self.db.execute(stmt)
        holiday = result.scalar_one_or_none()
        return holiday is not None, holiday

    async def get_holidays_in_range(
        self,
        start_date: date,
        end_date: date,
        academic_year_id: uuid.UUID,
    ) -> list[Holiday]:
        """Get all holidays within a date range."""
        stmt = select(Holiday).where(
            and_(
                Holiday.academic_year_id == academic_year_id,
                Holiday.start_date <= end_date,
                Holiday.end_date >= start_date,
                Holiday.is_active == True,
            )
        ).order_by(Holiday.start_date)
        result = await self.db.execute(stmt)
        return list(result.scalars().all())

    async def count_working_days(
        self,
        start_date: date,
        end_date: date,
        academic_year_id: uuid.UUID,
    ) -> int:
        """Count working days (excluding Sundays and holidays) in a range."""
        holidays = await self.get_holidays_in_range(start_date, end_date, academic_year_id)
        holiday_dates: set[date] = set()
        for h in holidays:
            current = h.start_date
            while current <= h.end_date:
                holiday_dates.add(current)
                current += timedelta(days=1)

        working_days = 0
        current = start_date
        while current <= end_date:
            if current.weekday() != 6 and current not in holiday_dates:
                working_days += 1
            current += timedelta(days=1)
        return working_days

    async def create_holiday(
        self,
        data: HolidayCreate,
        academic_year_id: uuid.UUID,
    ) -> Holiday:
        holiday = Holiday(
            academic_year_id=academic_year_id,
            name=data.name,
            description=data.description,
            start_date=data.start_date,
            end_date=data.end_date,
            holiday_type=data.holiday_type,
        )
        self.db.add(holiday)
        await self.db.flush()
        logger.info("holiday_created", holiday_id=str(holiday.id), name=data.name)
        return holiday

    async def update_holiday(
        self, holiday_id: uuid.UUID, data: HolidayUpdate
    ) -> Optional[Holiday]:
        stmt = select(Holiday).where(Holiday.id == holiday_id)
        result = await self.db.execute(stmt)
        holiday = result.scalar_one_or_none()
        if not holiday:
            return None

        for field, value in data.model_dump(exclude_unset=True).items():
            setattr(holiday, field, value)
        await self.db.flush()
        return holiday

    async def delete_holiday(self, holiday_id: uuid.UUID) -> bool:
        stmt = select(Holiday).where(Holiday.id == holiday_id)
        result = await self.db.execute(stmt)
        holiday = result.scalar_one_or_none()
        if not holiday:
            return False
        holiday.is_active = False
        await self.db.flush()
        return True

    async def list_holidays(
        self, academic_year_id: uuid.UUID, include_inactive: bool = False
    ) -> list[Holiday]:
        stmt = select(Holiday).where(Holiday.academic_year_id == academic_year_id)
        if not include_inactive:
            stmt = stmt.where(Holiday.is_active == True)
        stmt = stmt.order_by(Holiday.start_date)
        result = await self.db.execute(stmt)
        return list(result.scalars().all())

    async def get_upcoming_holidays(
        self,
        academic_year_id: Optional[uuid.UUID] = None,
        from_date: Optional[date] = None,
        limit: int = 5,
    ) -> list[Holiday]:
        from_date = from_date or date.today()
        stmt = (
            select(Holiday)
            .where(
                and_(
                    Holiday.end_date >= from_date,
                    Holiday.is_active == True,
                )
            )
        )
        if academic_year_id:
            stmt = stmt.where(Holiday.academic_year_id == academic_year_id)
        stmt = stmt.order_by(Holiday.start_date).limit(limit)
        result = await self.db.execute(stmt)
        return list(result.scalars().all())
