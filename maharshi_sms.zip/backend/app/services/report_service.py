"""
Report Generation Service.
Generates PDF attendance reports matching the school's format.
Daily and Monthly reports using ReportLab.
"""
import io
import uuid
from datetime import date
from typing import Optional

from reportlab.lib import colors
from reportlab.lib.enums import TA_CENTER, TA_LEFT, TA_RIGHT
from reportlab.lib.pagesizes import A4
from reportlab.lib.styles import ParagraphStyle, getSampleStyleSheet
from reportlab.lib.units import cm
from reportlab.platypus import (
    Paragraph,
    SimpleDocTemplate,
    Spacer,
    Table,
    TableStyle,
)
from sqlalchemy import and_, select
from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy.orm import selectinload

from app.core.config import settings
from app.core.logging import get_logger
from app.models.models import (
    Attendance,
    AttendanceStatus,
    Class,
    Student,
    StudentClassEnrollment,
)

logger = get_logger(__name__)


class ReportService:
    def __init__(self, db: AsyncSession):
        self.db = db

    async def generate_daily_attendance_pdf(
        self,
        class_id: uuid.UUID,
        attendance_date: date,
    ) -> bytes:
        """
        Generate a daily attendance PDF report.
        Format matches Maharshi High School daily report.
        """
        # Fetch class
        cls_stmt = select(Class).where(Class.id == class_id)
        cls = (await self.db.execute(cls_stmt)).scalar_one_or_none()
        if not cls:
            raise ValueError(f"Class {class_id} not found")

        # Fetch enrollments with students
        enroll_stmt = (
            select(StudentClassEnrollment)
            .options(selectinload(StudentClassEnrollment.student))
            .where(
                and_(
                    StudentClassEnrollment.class_id == class_id,
                    StudentClassEnrollment.is_active == True,
                )
            )
            .order_by(StudentClassEnrollment.roll_number)
        )
        enrollments = list((await self.db.execute(enroll_stmt)).scalars().all())

        # Fetch attendance records for the date
        att_stmt = select(Attendance).where(
            and_(
                Attendance.class_id == class_id,
                Attendance.attendance_date == attendance_date,
            )
        )
        attendance_records = list((await self.db.execute(att_stmt)).scalars().all())
        att_by_student = {rec.student_id: rec for rec in attendance_records}

        # Build stats
        total = len(enrollments)
        present_count = sum(
            1 for e in enrollments
            if att_by_student.get(e.student_id) and
            att_by_student[e.student_id].status == AttendanceStatus.PRESENT
        )
        absent_count = sum(
            1 for e in enrollments
            if att_by_student.get(e.student_id) and
            att_by_student[e.student_id].status == AttendanceStatus.ABSENT
        )
        not_marked = sum(1 for e in enrollments if e.student_id not in att_by_student)

        return self._build_daily_pdf(
            school_name=settings.SCHOOL_NAME,
            class_display=cls.display_name,
            report_date=attendance_date,
            enrollments=enrollments,
            att_by_student=att_by_student,
            stats={
                "total": total,
                "present": present_count,
                "absent": absent_count,
                "not_marked": not_marked,
            },
        )

    def _build_daily_pdf(
        self,
        school_name: str,
        class_display: str,
        report_date: date,
        enrollments: list,
        att_by_student: dict,
        stats: dict,
    ) -> bytes:
        buffer = io.BytesIO()
        doc = SimpleDocTemplate(
            buffer,
            pagesize=A4,
            rightMargin=1.5 * cm,
            leftMargin=1.5 * cm,
            topMargin=1.5 * cm,
            bottomMargin=1.5 * cm,
        )

        styles = getSampleStyleSheet()
        story = []

        # ── Header ──────────────────────────────────────────────────────────────
        title_style = ParagraphStyle(
            "Title",
            parent=styles["Normal"],
            fontSize=16,
            fontName="Helvetica-Bold",
            alignment=TA_CENTER,
            spaceAfter=4,
        )
        subtitle_style = ParagraphStyle(
            "Subtitle",
            parent=styles["Normal"],
            fontSize=12,
            fontName="Helvetica-Bold",
            alignment=TA_CENTER,
            spaceAfter=4,
        )
        info_style = ParagraphStyle(
            "Info",
            parent=styles["Normal"],
            fontSize=11,
            alignment=TA_CENTER,
            spaceAfter=4,
        )

        story.append(Paragraph(school_name, title_style))
        story.append(Paragraph("Daily Attendance Report", subtitle_style))
        story.append(Paragraph(class_display, info_style))
        story.append(Paragraph(report_date.strftime("%d %B %Y"), info_style))
        story.append(Spacer(1, 0.3 * cm))

        # ── Summary Row ──────────────────────────────────────────────────────────
        summary_data = [
            ["Total", "Present", "Absent", "Not Marked"],
            [
                str(stats["total"]),
                str(stats["present"]),
                str(stats["absent"]),
                str(stats["not_marked"]),
            ],
        ]
        summary_table = Table(summary_data, colWidths=[4 * cm] * 4)
        summary_table.setStyle(
            TableStyle(
                [
                    ("BACKGROUND", (0, 0), (-1, 0), colors.HexColor("#2C3E50")),
                    ("TEXTCOLOR", (0, 0), (-1, 0), colors.white),
                    ("FONTNAME", (0, 0), (-1, 0), "Helvetica-Bold"),
                    ("FONTSIZE", (0, 0), (-1, -1), 10),
                    ("ALIGN", (0, 0), (-1, -1), "CENTER"),
                    ("VALIGN", (0, 0), (-1, -1), "MIDDLE"),
                    ("ROWHEIGHT", (0, 0), (-1, -1), 18),
                    ("GRID", (0, 0), (-1, -1), 0.5, colors.grey),
                    ("BACKGROUND", (0, 1), (-1, 1), colors.HexColor("#ECF0F1")),
                ]
            )
        )
        story.append(summary_table)
        story.append(Spacer(1, 0.4 * cm))

        # ── Attendance Table ─────────────────────────────────────────────────────
        header = ["Roll", "Student Name", "Status", "Parent Reason"]
        table_data = [header]

        for enrollment in enrollments:
            student = enrollment.student
            roll = str(enrollment.roll_number) if enrollment.roll_number else "—"
            name = student.full_name if student else "Unknown"
            att = att_by_student.get(enrollment.student_id)

            if att:
                status_str = att.status.value.upper()
                if att.status == AttendanceStatus.ABSENT:
                    if att.parent_reason:
                        parent_reason = att.parent_reason
                    elif att.whatsapp_response_status.value == "pending":
                        parent_reason = "Awaiting Parent Reply"
                    else:
                        parent_reason = "—"
                else:
                    parent_reason = "—"
            else:
                status_str = "NOT MARKED"
                parent_reason = "—"

            table_data.append([roll, name, status_str, parent_reason])

        col_widths = [1.5 * cm, 7 * cm, 3 * cm, 7 * cm]
        att_table = Table(table_data, colWidths=col_widths, repeatRows=1)

        # Build row colors
        row_styles = [
            ("BACKGROUND", (0, 0), (-1, 0), colors.HexColor("#2C3E50")),
            ("TEXTCOLOR", (0, 0), (-1, 0), colors.white),
            ("FONTNAME", (0, 0), (-1, 0), "Helvetica-Bold"),
            ("FONTSIZE", (0, 0), (-1, -1), 9),
            ("ALIGN", (0, 0), (0, -1), "CENTER"),
            ("ALIGN", (2, 0), (2, -1), "CENTER"),
            ("VALIGN", (0, 0), (-1, -1), "MIDDLE"),
            ("GRID", (0, 0), (-1, -1), 0.25, colors.grey),
            ("ROWHEIGHT", (0, 0), (-1, -1), 16),
        ]

        # Highlight absent rows
        for i, enrollment in enumerate(enrollments, start=1):
            att = att_by_student.get(enrollment.student_id)
            if i % 2 == 0:
                row_styles.append(
                    ("BACKGROUND", (0, i), (-1, i), colors.HexColor("#F8F9FA"))
                )
            if att and att.status == AttendanceStatus.ABSENT:
                row_styles.append(
                    ("BACKGROUND", (2, i), (2, i), colors.HexColor("#FFEBEE"))
                )
                row_styles.append(
                    ("TEXTCOLOR", (2, i), (2, i), colors.HexColor("#C0392B"))
                )

        att_table.setStyle(TableStyle(row_styles))
        story.append(att_table)

        # ── Footer ───────────────────────────────────────────────────────────────
        story.append(Spacer(1, 0.5 * cm))
        footer_style = ParagraphStyle(
            "Footer",
            parent=styles["Normal"],
            fontSize=8,
            alignment=TA_CENTER,
            textColor=colors.grey,
        )
        story.append(
            Paragraph(
                f"Generated on {date.today().strftime('%d %B %Y')} | {school_name}",
                footer_style,
            )
        )

        doc.build(story)
        return buffer.getvalue()

    async def generate_monthly_attendance_pdf(
        self,
        class_id: uuid.UUID,
        year: int,
        month: int,
        academic_year_id: uuid.UUID,
    ) -> bytes:
        """Generate a monthly attendance summary PDF."""
        from calendar import monthrange, month_name

        cls_stmt = select(Class).where(Class.id == class_id)
        cls = (await self.db.execute(cls_stmt)).scalar_one_or_none()
        if not cls:
            raise ValueError(f"Class {class_id} not found")

        _, last_day = monthrange(year, month)
        start = date(year, month, 1)
        end = date(year, month, last_day)

        # Get enrollments
        enroll_stmt = (
            select(StudentClassEnrollment)
            .options(selectinload(StudentClassEnrollment.student))
            .where(
                and_(
                    StudentClassEnrollment.class_id == class_id,
                    StudentClassEnrollment.is_active == True,
                )
            )
            .order_by(StudentClassEnrollment.roll_number)
        )
        enrollments = list((await self.db.execute(enroll_stmt)).scalars().all())

        # Get all attendance for month
        att_stmt = select(Attendance).where(
            and_(
                Attendance.class_id == class_id,
                Attendance.attendance_date >= start,
                Attendance.attendance_date <= end,
            )
        )
        records = list((await self.db.execute(att_stmt)).scalars().all())

        # Organize by student
        student_stats: dict[uuid.UUID, dict] = {}
        for enr in enrollments:
            student_stats[enr.student_id] = {
                "roll": enr.roll_number,
                "name": enr.student.full_name if enr.student else "",
                "present": 0,
                "absent": 0,
                "late": 0,
            }

        for rec in records:
            if rec.student_id in student_stats:
                if rec.status == AttendanceStatus.PRESENT:
                    student_stats[rec.student_id]["present"] += 1
                elif rec.status == AttendanceStatus.ABSENT:
                    student_stats[rec.student_id]["absent"] += 1
                elif rec.status == AttendanceStatus.LATE:
                    student_stats[rec.student_id]["late"] += 1

        buffer = io.BytesIO()
        doc = SimpleDocTemplate(buffer, pagesize=A4, rightMargin=1.5*cm, leftMargin=1.5*cm,
                                topMargin=1.5*cm, bottomMargin=1.5*cm)
        styles = getSampleStyleSheet()
        story = []

        title_style = ParagraphStyle("T", parent=styles["Normal"], fontSize=16,
                                     fontName="Helvetica-Bold", alignment=TA_CENTER, spaceAfter=4)
        subtitle_style = ParagraphStyle("S", parent=styles["Normal"], fontSize=12,
                                        fontName="Helvetica-Bold", alignment=TA_CENTER, spaceAfter=4)
        info_style = ParagraphStyle("I", parent=styles["Normal"], fontSize=11,
                                    alignment=TA_CENTER, spaceAfter=4)

        story.append(Paragraph(settings.SCHOOL_NAME, title_style))
        story.append(Paragraph("Monthly Attendance Report", subtitle_style))
        story.append(Paragraph(cls.display_name, info_style))
        story.append(Paragraph(f"{month_name[month]} {year}", info_style))
        story.append(Spacer(1, 0.4 * cm))

        header = ["Roll", "Student Name", "Present", "Absent", "Late", "%"]
        table_data = [header]
        for sid, stats in student_stats.items():
            total = stats["present"] + stats["absent"] + stats["late"]
            pct = f"{round(stats['present'] / total * 100, 1)}%" if total else "—"
            table_data.append([
                str(stats["roll"]) if stats["roll"] else "—",
                stats["name"],
                str(stats["present"]),
                str(stats["absent"]),
                str(stats["late"]),
                pct,
            ])

        col_widths = [1.5*cm, 7.5*cm, 2.5*cm, 2.5*cm, 2.5*cm, 2.5*cm]
        tbl = Table(table_data, colWidths=col_widths, repeatRows=1)
        tbl.setStyle(TableStyle([
            ("BACKGROUND", (0, 0), (-1, 0), colors.HexColor("#2C3E50")),
            ("TEXTCOLOR", (0, 0), (-1, 0), colors.white),
            ("FONTNAME", (0, 0), (-1, 0), "Helvetica-Bold"),
            ("FONTSIZE", (0, 0), (-1, -1), 9),
            ("ALIGN", (0, 0), (0, -1), "CENTER"),
            ("ALIGN", (2, 0), (-1, -1), "CENTER"),
            ("VALIGN", (0, 0), (-1, -1), "MIDDLE"),
            ("GRID", (0, 0), (-1, -1), 0.25, colors.grey),
            ("ROWHEIGHT", (0, 0), (-1, -1), 16),
            ("ROWBACKGROUNDS", (0, 1), (-1, -1), [colors.white, colors.HexColor("#F8F9FA")]),
        ]))
        story.append(tbl)

        doc.build(story)
        return buffer.getvalue()
