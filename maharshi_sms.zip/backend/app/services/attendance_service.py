"""
Attendance Service.
Handles daily attendance with holiday validation, bulk marking,
and WhatsApp absence notification triggers.
"""
import uuid
from datetime import date
from typing import Optional

from sqlalchemy import and_, func, select, update
from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy.orm import selectinload

from app.core.logging import get_logger
from app.models.models import (
    Attendance,
    AttendanceStatus,
    Class,
    ParentContact,
    Student,
    StudentClassEnrollment,
    WhatsAppResponseStatus,
)
from app.schemas.attendance import (
    AttendanceBulkCreate,
    AttendanceRecord,
    AttendanceUpdate,
)
from app.services.holiday_service import HolidayService

logger = get_logger(__name__)


class AttendanceService:
    def __init__(self, db: AsyncSession, holiday_service: HolidayService):
        self.db = db
        self.holiday_svc = holiday_service

    async def validate_attendance_date(
        self,
        attendance_date: date,
        academic_year_id: uuid.UUID,
    ) -> None:
        """Raise ValueError if date is a holiday or Sunday."""
        is_hol, holiday = await self.holiday_svc.is_holiday(attendance_date, academic_year_id)
        if is_hol:
            reason = holiday.name if holiday else "Sunday"
            raise ValueError(f"Cannot mark attendance on holiday: {reason}")

    async def get_class_attendance(
        self,
        class_id: uuid.UUID,
        attendance_date: date,
    ) -> list[Attendance]:
        """Get attendance records for a class on a given date."""
        stmt = (
            select(Attendance)
            .options(
                selectinload(Attendance.student).selectinload(Student.parent_contacts)
            )
            .where(
                and_(
                    Attendance.class_id == class_id,
                    Attendance.attendance_date == attendance_date,
                )
            )
            .order_by(Attendance.created_at)
        )
        result = await self.db.execute(stmt)
        return list(result.scalars().all())

    async def get_enrolled_students(self, class_id: uuid.UUID) -> list[StudentClassEnrollment]:
        """Get all active enrolled students with their student data."""
        stmt = (
            select(StudentClassEnrollment)
            .options(
                selectinload(StudentClassEnrollment.student).selectinload(Student.parent_contacts)
            )
            .where(
                and_(
                    StudentClassEnrollment.class_id == class_id,
                    StudentClassEnrollment.is_active == True,
                )
            )
            .order_by(StudentClassEnrollment.roll_number)
        )
        result = await self.db.execute(stmt)
        return list(result.scalars().all())

    async def bulk_mark_attendance(
        self,
        class_id: uuid.UUID,
        academic_year_id: uuid.UUID,
        attendance_date: date,
        records: list[AttendanceRecord],
        teacher_id: uuid.UUID,
    ) -> tuple[list[Attendance], list[uuid.UUID]]:
        """
        Bulk mark attendance for a class.
        Returns (attendance_records, absent_student_ids_needing_notification).
        """
        await self.validate_attendance_date(attendance_date, academic_year_id)

        absent_student_ids: list[uuid.UUID] = []
        created_or_updated: list[Attendance] = []

        for record in records:
            # Check if attendance already exists
            stmt = select(Attendance).where(
                and_(
                    Attendance.student_id == record.student_id,
                    Attendance.class_id == class_id,
                    Attendance.attendance_date == attendance_date,
                )
            )
            existing = (await self.db.execute(stmt)).scalar_one_or_none()

            if existing:
                old_status = existing.status
                existing.status = record.status
                existing.marked_by_teacher_id = teacher_id
                existing.remarks = record.remarks
                # Reset WA status if re-marked from present to absent
                if old_status != AttendanceStatus.ABSENT and record.status == AttendanceStatus.ABSENT:
                    existing.whatsapp_response_status = WhatsAppResponseStatus.PENDING
                    existing.parent_reason = None
                    existing.parent_reason_locked = False
                    absent_student_ids.append(record.student_id)
                attendance = existing
            else:
                attendance = Attendance(
                    student_id=record.student_id,
                    class_id=class_id,
                    academic_year_id=academic_year_id,
                    attendance_date=attendance_date,
                    status=record.status,
                    marked_by_teacher_id=teacher_id,
                    remarks=record.remarks,
                )
                self.db.add(attendance)
                if record.status == AttendanceStatus.ABSENT:
                    absent_student_ids.append(record.student_id)

            created_or_updated.append(attendance)

        await self.db.flush()
        logger.info(
            "bulk_attendance_marked",
            class_id=str(class_id),
            date=str(attendance_date),
            total=len(records),
            absent=len(absent_student_ids),
        )
        return created_or_updated, absent_student_ids

    async def update_parent_reason(
        self,
        student_id: uuid.UUID,
        attendance_date: date,
        class_id: uuid.UUID,
        reason: str,
        whatsapp_number: str,
    ) -> Optional[Attendance]:
        """
        Record parent-provided absence reason via WhatsApp webhook.
        Once locked, subsequent responses are blocked.
        """
        stmt = select(Attendance).where(
            and_(
                Attendance.student_id == student_id,
                Attendance.attendance_date == attendance_date,
                Attendance.class_id == class_id,
                Attendance.status == AttendanceStatus.ABSENT,
            )
        )
        attendance = (await self.db.execute(stmt)).scalar_one_or_none()
        if not attendance:
            return None

        if attendance.parent_reason_locked:
            logger.info(
                "parent_reason_already_locked",
                student_id=str(student_id),
                date=str(attendance_date),
            )
            return attendance

        attendance.parent_reason = reason
        attendance.parent_reason_locked = True
        attendance.whatsapp_response_status = WhatsAppResponseStatus.LOCKED
        await self.db.flush()
        return attendance

    async def get_attendance_summary(
        self,
        class_id: uuid.UUID,
        attendance_date: date,
    ) -> dict:
        """Get summary stats for a class on a given date."""
        stmt = (
            select(Attendance.status, func.count(Attendance.id))
            .where(
                and_(
                    Attendance.class_id == class_id,
                    Attendance.attendance_date == attendance_date,
                )
            )
            .group_by(Attendance.status)
        )
        result = await self.db.execute(stmt)
        counts = {row[0]: row[1] for row in result.all()}

        # Get total enrolled
        enrolled_stmt = select(func.count(StudentClassEnrollment.id)).where(
            and_(
                StudentClassEnrollment.class_id == class_id,
                StudentClassEnrollment.is_active == True,
            )
        )
        total_enrolled = (await self.db.execute(enrolled_stmt)).scalar_one() or 0

        present = counts.get(AttendanceStatus.PRESENT, 0)
        absent = counts.get(AttendanceStatus.ABSENT, 0)
        late = counts.get(AttendanceStatus.LATE, 0)
        marked = present + absent + late
        not_marked = total_enrolled - marked

        return {
            "total_enrolled": total_enrolled,
            "present": present,
            "absent": absent,
            "late": late,
            "not_marked": not_marked,
            "attendance_percentage": round((present / total_enrolled * 100) if total_enrolled else 0, 2),
        }

    async def get_student_attendance_stats(
        self,
        student_id: uuid.UUID,
        academic_year_id: uuid.UUID,
        from_date: Optional[date] = None,
        to_date: Optional[date] = None,
    ) -> dict:
        """Calculate attendance percentage for a student."""
        conditions = [
            Attendance.student_id == student_id,
            Attendance.academic_year_id == academic_year_id,
        ]
        if from_date:
            conditions.append(Attendance.attendance_date >= from_date)
        if to_date:
            conditions.append(Attendance.attendance_date <= to_date)

        stmt = (
            select(Attendance.status, func.count(Attendance.id))
            .where(and_(*conditions))
            .group_by(Attendance.status)
        )
        result = await self.db.execute(stmt)
        counts = {row[0]: row[1] for row in result.all()}

        present = counts.get(AttendanceStatus.PRESENT, 0)
        absent = counts.get(AttendanceStatus.ABSENT, 0)
        late = counts.get(AttendanceStatus.LATE, 0)
        total = present + absent + late

        return {
            "total_days": total,
            "present": present,
            "absent": absent,
            "late": late,
            "percentage": round((present / total * 100) if total else 0, 2),
        }

    async def get_class_monthly_report(
        self,
        class_id: uuid.UUID,
        year: int,
        month: int,
        academic_year_id: uuid.UUID,
    ) -> dict:
        """Generate monthly attendance data for a class."""
        from calendar import monthrange
        from datetime import date as date_type

        _, last_day = monthrange(year, month)
        start = date_type(year, month, 1)
        end = date_type(year, month, last_day)

        # Get all attendance for the class in this month
        stmt = (
            select(Attendance)
            .options(selectinload(Attendance.student))
            .where(
                and_(
                    Attendance.class_id == class_id,
                    Attendance.attendance_date >= start,
                    Attendance.attendance_date <= end,
                )
            )
            .order_by(Attendance.attendance_date, Attendance.student_id)
        )
        records = list((await self.db.execute(stmt)).scalars().all())

        # Working days in the month
        working_days = await self.holiday_svc.count_working_days(start, end, academic_year_id)

        # Organize by student
        student_data: dict = {}
        for rec in records:
            sid = str(rec.student_id)
            if sid not in student_data:
                student_data[sid] = {
                    "student_name": rec.student.full_name if rec.student else "",
                    "present": 0,
                    "absent": 0,
                    "late": 0,
                }
            if rec.status == AttendanceStatus.PRESENT:
                student_data[sid]["present"] += 1
            elif rec.status == AttendanceStatus.ABSENT:
                student_data[sid]["absent"] += 1
            elif rec.status == AttendanceStatus.LATE:
                student_data[sid]["late"] += 1

        return {
            "class_id": str(class_id),
            "year": year,
            "month": month,
            "working_days": working_days,
            "students": list(student_data.values()),
        }
