"""
Celery worker setup and async task definitions.
Tasks:
  - send_absence_whatsapp_notifications: dispatch WhatsApp for absent students
  - mark_overdue_fees: cron job to mark unpaid fees as overdue
  - send_fee_reminders: WhatsApp reminders for pending fees
"""
import asyncio
from datetime import date, timedelta
from uuid import UUID

import structlog
from celery import Celery
from celery.schedules import crontab

from app.core.config import settings

logger = structlog.get_logger(__name__)

# ─── Celery app ───────────────────────────────────────────────────────────────

celery_app = Celery(
    "sms_worker",
    broker=settings.redis_url,
    backend=settings.redis_url,
    include=["app.tasks.celery_tasks"],
)

celery_app.conf.update(
    task_serializer="json",
    accept_content=["json"],
    result_serializer="json",
    timezone="Asia/Kolkata",
    enable_utc=True,
    task_track_started=True,
    task_acks_late=True,
    worker_prefetch_multiplier=1,
    result_expires=3600,  # 1 hour
    beat_schedule={
        # Run every day at 09:00 IST to mark overdue fees
        "mark-overdue-fees-daily": {
            "task": "app.tasks.celery_tasks.mark_overdue_fees",
            "schedule": crontab(hour=9, minute=0),
        },
        # Run every day at 10:00 IST to send fee reminders
        "send-fee-reminders-daily": {
            "task": "app.tasks.celery_tasks.send_fee_reminders",
            "schedule": crontab(hour=10, minute=0),
        },
    },
)


# ─── Helper: run async in sync context ────────────────────────────────────────

def run_async(coro):
    """Run an async coroutine from a sync Celery task."""
    loop = asyncio.new_event_loop()
    try:
        return loop.run_until_complete(coro)
    finally:
        loop.close()


# ─── Tasks ────────────────────────────────────────────────────────────────────

@celery_app.task(
    name="app.tasks.celery_tasks.send_absence_whatsapp_notifications",
    bind=True,
    max_retries=3,
    default_retry_delay=60,
)
def send_absence_whatsapp_notifications(self, attendance_ids: list[str]) -> dict:
    """
    Send WhatsApp absence notifications for a batch of attendance records.
    Called after bulk attendance marking.
    """
    async def _run():
        from sqlalchemy import select
        from app.db.session import AsyncSessionLocal
        from app.models.models import Attendance, Notification, NotificationChannel, NotificationStatus
        from app.services.whatsapp_service import WhatsAppService

        sent = 0
        failed = 0

        async with AsyncSessionLocal() as db:
            for att_id_str in attendance_ids:
                att_id = UUID(att_id_str)
                try:
                    from sqlalchemy import select as sa_select
                    from sqlalchemy.orm import selectinload
                    from app.models.models import Attendance, Student
                    from app.services.attendance_service import AttendanceService
                    from app.core.config import settings as app_settings

                    att_svc = AttendanceService(db)
                    whatsapp = WhatsAppService(db, att_svc)

                    attendance = await db.get(Attendance, att_id)
                    if not attendance:
                        continue

                    # Load student with parent contacts
                    student_result = await db.execute(
                        sa_select(Student)
                        .options(selectinload(Student.parent_contacts))
                        .where(Student.id == attendance.student_id)
                    )
                    student = student_result.scalar_one_or_none()
                    if not student:
                        continue

                    primary_parent = next(
                        (p for p in student.parent_contacts if p.is_primary and p.whatsapp_number),
                        next((p for p in student.parent_contacts if p.whatsapp_number), None),
                    )
                    if not primary_parent:
                        continue

                    msg_id = await whatsapp.send_absence_notification(
                        student=student,
                        attendance=attendance,
                        parent_contact=primary_parent,
                        school_name=app_settings.SCHOOL_NAME,
                    )
                    if msg_id:
                        sent += 1
                    else:
                        failed += 1

                    await db.commit()

                except Exception as e:
                    logger.error(
                        "Failed to send WhatsApp notification",
                        attendance_id=att_id_str,
                        error=str(e),
                    )
                    failed += 1

        return {"sent": sent, "failed": failed}

    try:
        return run_async(_run())
    except Exception as exc:
        logger.error("Task failed", task="send_absence_whatsapp_notifications", error=str(exc))
        raise self.retry(exc=exc)


@celery_app.task(
    name="app.tasks.celery_tasks.mark_overdue_fees",
    bind=True,
)
def mark_overdue_fees(self) -> dict:
    """
    Daily cron: mark PENDING and PARTIAL fees as OVERDUE when due_date has passed.
    """
    async def _run():
        from sqlalchemy import update, and_
        from app.db.session import AsyncSessionLocal
        from app.models.models import FeeStatus, StudentFee

        today = date.today()

        async with AsyncSessionLocal() as db:
            result = await db.execute(
                update(StudentFee)
                .where(
                    and_(
                        StudentFee.due_date < today,
                        StudentFee.status.in_([FeeStatus.PENDING, FeeStatus.PARTIAL]),
                    )
                )
                .values(status=FeeStatus.OVERDUE)
            )
            await db.commit()
            count = result.rowcount

        logger.info("Marked fees as overdue", count=count, date=str(today))
        return {"marked_overdue": count}

    return run_async(_run())


@celery_app.task(
    name="app.tasks.celery_tasks.send_fee_reminders",
    bind=True,
)
def send_fee_reminders(self) -> dict:
    """
    Daily cron: send WhatsApp fee reminders for PENDING fees due in the next 3 days
    and for OVERDUE fees.
    """
    async def _run():
        from sqlalchemy import select, and_, or_
        from app.db.session import AsyncSessionLocal
        from app.models.models import FeeStatus, StudentFee, Student, ParentContact
        from app.services.whatsapp_service import WhatsAppService

        whatsapp = WhatsAppService()
        today = date.today()
        reminder_threshold = today + timedelta(days=3)
        sent = 0

        async with AsyncSessionLocal() as db:
            result = await db.execute(
                select(StudentFee).where(
                    or_(
                        and_(
                            StudentFee.status == FeeStatus.PENDING,
                            StudentFee.due_date <= reminder_threshold,
                            StudentFee.due_date >= today,
                        ),
                        StudentFee.status == FeeStatus.OVERDUE,
                    )
                )
            )
            fees = result.scalars().all()

            from app.services.attendance_service import AttendanceService
            att_svc = AttendanceService(db)
            whatsapp = WhatsAppService(db, att_svc)

            for fee in fees:
                try:
                    # Get student + primary parent
                    student = await db.get(Student, fee.student_id)
                    if not student:
                        continue

                    parent_result = await db.execute(
                        select(ParentContact).where(
                            ParentContact.student_id == fee.student_id,
                            ParentContact.is_primary == True,  # noqa
                        )
                    )
                    parent = parent_result.scalar_one_or_none()
                    if not parent or not parent.whatsapp_number:
                        continue

                    balance = fee.amount_due - (fee.amount_paid or 0) - (fee.concession_amount or 0)
                    msg = (
                        f"Dear Parent, this is a reminder that school fee of ₹{balance:.0f} "
                        f"for {student.full_name} is "
                        f"{'overdue' if fee.status == FeeStatus.OVERDUE else f'due by {fee.due_date}'}. "
                        f"Please make the payment at the earliest. — Maharshi High School"
                    )
                    await whatsapp._send_text_message(parent.whatsapp_number, msg)
                    sent += 1

                except Exception as e:
                    logger.error("Fee reminder failed", fee_id=str(fee.id), error=str(e))

            await db.commit()

        logger.info("Fee reminders sent", count=sent)
        return {"reminders_sent": sent}

    return run_async(_run())
