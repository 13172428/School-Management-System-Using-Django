"""
Core configuration using pydantic-settings.
All settings loaded from environment variables.
"""
from functools import lru_cache
from typing import Literal

from pydantic import AnyHttpUrl, PostgresDsn, RedisDsn, field_validator
from pydantic_settings import BaseSettings, SettingsConfigDict


class Settings(BaseSettings):
    model_config = SettingsConfigDict(
        env_file=".env",
        env_file_encoding="utf-8",
        case_sensitive=False,
        extra="ignore",
    )

    # ─── App ───────────────────────────────────────────────────────────────────
    APP_NAME: str = "School Management System"
    APP_VERSION: str = "1.0.0"
    ENVIRONMENT: Literal["development", "staging", "production", "test"] = "development"
    DEBUG: bool = False
    SECRET_KEY: str
    API_V1_STR: str = "/api/v1"
    ALLOWED_ORIGINS: list[str] = ["http://localhost:5173", "http://localhost:3000"]

    # ─── Database ──────────────────────────────────────────────────────────────
    DATABASE_URL: PostgresDsn
    DATABASE_POOL_SIZE: int = 10
    DATABASE_MAX_OVERFLOW: int = 20
    DATABASE_POOL_TIMEOUT: int = 30

    # ─── Redis ─────────────────────────────────────────────────────────────────
    REDIS_URL: RedisDsn

    # ─── Clerk ─────────────────────────────────────────────────────────────────
    CLERK_SECRET_KEY: str
    CLERK_PUBLISHABLE_KEY: str
    CLERK_ISSUER: str = "https://clerk.your-domain.com"

    # ─── WhatsApp Cloud API ────────────────────────────────────────────────────
    WHATSAPP_ACCESS_TOKEN: str
    WHATSAPP_PHONE_NUMBER_ID: str
    WHATSAPP_API_VERSION: str = "v19.0"
    WHATSAPP_WEBHOOK_VERIFY_TOKEN: str
    WHATSAPP_BUSINESS_ACCOUNT_ID: str = ""

    # ─── Email (SMTP) ──────────────────────────────────────────────────────────
    SMTP_HOST: str = "smtp.gmail.com"
    SMTP_PORT: int = 587
    SMTP_USERNAME: str = ""
    SMTP_PASSWORD: str = ""
    SMTP_FROM_EMAIL: str = ""
    SMTP_FROM_NAME: str = "School Management System"

    # ─── Sentry ────────────────────────────────────────────────────────────────
    SENTRY_DSN: str = ""

    # ─── School ────────────────────────────────────────────────────────────────
    SCHOOL_NAME: str = "Maharshi High School"
    SCHOOL_TIMEZONE: str = "Asia/Kolkata"

    # ─── Rate Limiting ─────────────────────────────────────────────────────────
    RATE_LIMIT_PER_MINUTE: int = 100

    # ─── Celery ────────────────────────────────────────────────────────────────
    CELERY_BROKER_URL: str = ""
    CELERY_RESULT_BACKEND: str = ""

    @field_validator("CELERY_BROKER_URL", mode="before")
    @classmethod
    def set_celery_broker(cls, v: str, info) -> str:
        if not v:
            redis_url = info.data.get("REDIS_URL", "redis://localhost:6379/0")
            return str(redis_url)
        return v

    @field_validator("CELERY_RESULT_BACKEND", mode="before")
    @classmethod
    def set_celery_backend(cls, v: str, info) -> str:
        if not v:
            redis_url = info.data.get("REDIS_URL", "redis://localhost:6379/0")
            return str(redis_url)
        return v

    @property
    def is_production(self) -> bool:
        return self.ENVIRONMENT == "production"

    @property
    def redis_url(self) -> str:
        return str(self.REDIS_URL)

    @property
    def RATE_LIMIT_DEFAULT(self) -> str:
        return f"{self.RATE_LIMIT_PER_MINUTE}/minute"

    @property
    def database_url_str(self) -> str:
        return str(self.DATABASE_URL).replace("postgresql://", "postgresql+asyncpg://", 1)

    @property
    def database_url_sync(self) -> str:
        return str(self.DATABASE_URL).replace("postgresql+asyncpg://", "postgresql://", 1)

    @property
    def whatsapp_api_url(self) -> str:
        return f"https://graph.facebook.com/{self.WHATSAPP_API_VERSION}/{self.WHATSAPP_PHONE_NUMBER_ID}"


@lru_cache
def get_settings() -> Settings:
    return Settings()  # type: ignore[call-arg]


settings = get_settings()
