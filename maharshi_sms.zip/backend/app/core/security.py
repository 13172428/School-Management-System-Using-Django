"""
Security utilities.
Clerk JWT verification + Role-based access control.
"""
from enum import StrEnum
from typing import Annotated

import httpx
from fastapi import Depends, HTTPException, Security, status
from fastapi.security import HTTPAuthorizationCredentials, HTTPBearer
from jose import ExpiredSignatureError, JWTError, jwt
from pydantic import BaseModel

from app.core.config import settings
from app.core.logging import get_logger

logger = get_logger(__name__)
bearer_scheme = HTTPBearer(auto_error=True)

# Cached JWKS
_jwks_cache: dict | None = None


class UserRole(StrEnum):
    ADMIN = "admin"
    TEACHER = "teacher"


class CurrentUser(BaseModel):
    clerk_user_id: str
    email: str
    role: UserRole
    first_name: str = ""
    last_name: str = ""

    @property
    def full_name(self) -> str:
        return f"{self.first_name} {self.last_name}".strip()


async def _get_clerk_jwks() -> dict:
    """Fetch and cache Clerk JWKS for JWT verification."""
    global _jwks_cache
    if _jwks_cache is not None:
        return _jwks_cache

    clerk_domain = settings.CLERK_ISSUER
    jwks_url = f"{clerk_domain}/.well-known/jwks.json"

    async with httpx.AsyncClient(timeout=10.0) as client:
        response = await client.get(jwks_url)
        response.raise_for_status()
        _jwks_cache = response.json()
        return _jwks_cache


async def verify_clerk_token(token: str) -> dict:
    """Verify Clerk JWT and return claims."""
    try:
        # Decode header to get key id
        unverified_header = jwt.get_unverified_header(token)
        kid = unverified_header.get("kid")

        jwks = await _get_clerk_jwks()
        rsa_key = {}

        for key in jwks.get("keys", []):
            if key.get("kid") == kid:
                rsa_key = {
                    "kty": key["kty"],
                    "kid": key["kid"],
                    "use": key["use"],
                    "n": key["n"],
                    "e": key["e"],
                }
                break

        if not rsa_key:
            raise HTTPException(
                status_code=status.HTTP_401_UNAUTHORIZED,
                detail="Unable to find matching key",
            )

        payload = jwt.decode(
            token,
            rsa_key,
            algorithms=["RS256"],
            issuer=settings.CLERK_ISSUER,
            options={"verify_aud": False},
        )
        return payload

    except ExpiredSignatureError:
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail="Token has expired",
        )
    except JWTError as e:
        logger.warning("JWT verification failed", error=str(e))
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail="Invalid token",
        )


async def get_current_user(
    credentials: Annotated[HTTPAuthorizationCredentials, Security(bearer_scheme)],
) -> CurrentUser:
    """Extract and validate the current user from the Clerk JWT."""
    token = credentials.credentials
    payload = await verify_clerk_token(token)

    # Extract role from Clerk public metadata
    metadata = payload.get("public_metadata", {})
    role_str = metadata.get("role", "")

    try:
        role = UserRole(role_str)
    except ValueError:
        raise HTTPException(
            status_code=status.HTTP_403_FORBIDDEN,
            detail="User role not configured. Contact your administrator.",
        )

    email_addresses = payload.get("email_addresses", [])
    email = email_addresses[0].get("email_address", "") if email_addresses else payload.get("email", "")

    return CurrentUser(
        clerk_user_id=payload["sub"],
        email=email,
        role=role,
        first_name=payload.get("first_name", ""),
        last_name=payload.get("last_name", ""),
    )


def require_role(*roles: UserRole):
    """Factory: returns a dependency that enforces one of the given roles."""

    async def _checker(
        current_user: Annotated[CurrentUser, Depends(get_current_user)],
    ) -> CurrentUser:
        if current_user.role not in roles:
            raise HTTPException(
                status_code=status.HTTP_403_FORBIDDEN,
                detail=f"Access denied. Required role: {', '.join(roles)}",
            )
        return current_user

    return _checker


# Convenience dependencies
RequireAdmin = Depends(require_role(UserRole.ADMIN))
RequireTeacher = Depends(require_role(UserRole.TEACHER))
RequireAnyRole = Depends(require_role(UserRole.ADMIN, UserRole.TEACHER))
CurrentUserDep = Annotated[CurrentUser, Depends(get_current_user)]
