"""
Complete database models for School Management System.
All operational data linked to academic_year_id.
"""
import uuid
from datetime import date, datetime
from enum import StrEnum
from typing import Optional

from sqlalchemy import (
    BigInteger,
    Boolean,
    Date,
    DateTime,
    Enum,
    ForeignKey,
    Index,
    Integer,
    Numeric,
    String,
    Text,
    UniqueConstraint,
    func,
)
from sqlalchemy.dialects.postgresql import JSONB, UUID
from sqlalchemy.orm import Mapped, mapped_column, relationship

from app.db.session import Base


# ─── Enumerations ──────────────────────────────────────────────────────────────

class AttendanceStatus(StrEnum):
    PRESENT = "present"
    ABSENT = "absent"
    LATE = "late"
    EXCUSED = "excused"


class FeeStatus(StrEnum):
    PENDING = "pending"
    PAID = "paid"
    PARTIAL = "partial"
    OVERDUE = "overdue"
    WAIVED = "waived"


class NotificationStatus(StrEnum):
    PENDING = "pending"
    SENT = "sent"
    FAILED = "failed"
    DELIVERED = "delivered"
    READ = "read"


class NotificationChannel(StrEnum):
    WHATSAPP = "whatsapp"
    EMAIL = "email"
    SMS = "sms"


class HolidayType(StrEnum):
    NATIONAL = "national"
    RELIGIOUS = "religious"
    SCHOOL = "school"
    EXAM = "exam"
    OTHER = "other"


class CSVImportStatus(StrEnum):
    PENDING = "pending"
    PROCESSING = "processing"
    COMPLETED = "completed"
    FAILED = "failed"
    ROLLED_BACK = "rolled_back"


class CSVImportType(StrEnum):
    STUDENTS = "students"
    TEACHERS = "teachers"
    FEES = "fees"
    MARKS = "marks"


class ExamType(StrEnum):
    UNIT_TEST = "unit_test"
    MID_TERM = "mid_term"
    FINAL = "final"
    QUARTERLY = "quarterly"
    HALF_YEARLY = "half_yearly"


class PaymentMethod(StrEnum):
    CASH = "cash"
    ONLINE = "online"
    CHEQUE = "cheque"
    DD = "dd"
    UPI = "upi"


class WhatsAppResponseStatus(StrEnum):
    PENDING = "pending"
    RESPONDED = "responded"
    LOCKED = "locked"
    EXPIRED = "expired"


# ─── Mixin ─────────────────────────────────────────────────────────────────────

class TimestampMixin:
    created_at: Mapped[datetime] = mapped_column(
        DateTime(timezone=True), server_default=func.now(), nullable=False
    )
    updated_at: Mapped[datetime] = mapped_column(
        DateTime(timezone=True),
        server_default=func.now(),
        onupdate=func.now(),
        nullable=False,
    )


class UUIDMixin:
    id: Mapped[uuid.UUID] = mapped_column(
        UUID(as_uuid=True), primary_key=True, default=uuid.uuid4
    )


# ─── Core Tables ───────────────────────────────────────────────────────────────

class AcademicYear(UUIDMixin, TimestampMixin, Base):
    __tablename__ = "academic_years"

    name: Mapped[str] = mapped_column(String(50), nullable=False, unique=True)
    start_date: Mapped[date] = mapped_column(Date, nullable=False)
    end_date: Mapped[date] = mapped_column(Date, nullable=False)
    is_active: Mapped[bool] = mapped_column(Boolean, default=False, nullable=False)
    is_archived: Mapped[bool] = mapped_column(Boolean, default=False, nullable=False)
    description: Mapped[Optional[str]] = mapped_column(Text)

    # Relationships
    classes: Mapped[list["Class"]] = relationship("Class", back_populates="academic_year")
    holidays: Mapped[list["Holiday"]] = relationship("Holiday", back_populates="academic_year")
    exams: Mapped[list["Exam"]] = relationship("Exam", back_populates="academic_year")
    fees: Mapped[list["FeeStructure"]] = relationship("FeeStructure", back_populates="academic_year")
    calendar_events: Mapped[list["AcademicCalendarEvent"]] = relationship(
        "AcademicCalendarEvent", back_populates="academic_year"
    )


class Teacher(UUIDMixin, TimestampMixin, Base):
    __tablename__ = "teachers"

    employee_id: Mapped[str] = mapped_column(String(50), unique=True, nullable=False)
    clerk_user_id: Mapped[Optional[str]] = mapped_column(String(255), unique=True)
    first_name: Mapped[str] = mapped_column(String(100), nullable=False)
    last_name: Mapped[str] = mapped_column(String(100), nullable=False)
    email: Mapped[str] = mapped_column(String(255), unique=True, nullable=False)
    phone: Mapped[Optional[str]] = mapped_column(String(20))
    whatsapp_number: Mapped[Optional[str]] = mapped_column(String(20))
    qualification: Mapped[Optional[str]] = mapped_column(String(255))
    joining_date: Mapped[Optional[date]] = mapped_column(Date)
    is_active: Mapped[bool] = mapped_column(Boolean, default=True)
    profile_image_url: Mapped[Optional[str]] = mapped_column(String(500))
    address: Mapped[Optional[str]] = mapped_column(Text)
    extra_data: Mapped[Optional[dict]] = mapped_column(JSONB)

    # Relationships
    subject_assignments: Mapped[list["TeacherSubjectAssignment"]] = relationship(
        "TeacherSubjectAssignment", back_populates="teacher"
    )
    class_assignments: Mapped[list["ClassTeacherAssignment"]] = relationship(
        "ClassTeacherAssignment", back_populates="teacher"
    )
    timetable_slots: Mapped[list["TimetableSlot"]] = relationship(
        "TimetableSlot", back_populates="teacher"
    )

    __table_args__ = (
        Index("ix_teachers_email", "email"),
        Index("ix_teachers_employee_id", "employee_id"),
        Index("ix_teachers_clerk_user_id", "clerk_user_id"),
    )

    @property
    def full_name(self) -> str:
        return f"{self.first_name} {self.last_name}"


class Student(UUIDMixin, TimestampMixin, Base):
    __tablename__ = "students"

    admission_number: Mapped[str] = mapped_column(String(50), unique=True, nullable=False)
    first_name: Mapped[str] = mapped_column(String(100), nullable=False)
    last_name: Mapped[str] = mapped_column(String(100), nullable=False)
    date_of_birth: Mapped[Optional[date]] = mapped_column(Date)
    gender: Mapped[Optional[str]] = mapped_column(String(10))
    blood_group: Mapped[Optional[str]] = mapped_column(String(5))
    address: Mapped[Optional[str]] = mapped_column(Text)
    profile_image_url: Mapped[Optional[str]] = mapped_column(String(500))
    admission_date: Mapped[Optional[date]] = mapped_column(Date)
    is_active: Mapped[bool] = mapped_column(Boolean, default=True)
    extra_data: Mapped[Optional[dict]] = mapped_column(JSONB)

    # Relationships
    parent_contacts: Mapped[list["ParentContact"]] = relationship(
        "ParentContact", back_populates="student", cascade="all, delete-orphan"
    )
    class_enrollments: Mapped[list["StudentClassEnrollment"]] = relationship(
        "StudentClassEnrollment", back_populates="student"
    )
    attendance_records: Mapped[list["Attendance"]] = relationship(
        "Attendance", back_populates="student"
    )
    exam_results: Mapped[list["ExamResult"]] = relationship(
        "ExamResult", back_populates="student"
    )
    fee_records: Mapped[list["StudentFee"]] = relationship(
        "StudentFee", back_populates="student"
    )

    __table_args__ = (
        Index("ix_students_admission_number", "admission_number"),
        Index("ix_students_is_active", "is_active"),
    )

    @property
    def full_name(self) -> str:
        return f"{self.first_name} {self.last_name}"


class ParentContact(UUIDMixin, TimestampMixin, Base):
    __tablename__ = "parent_contacts"

    student_id: Mapped[uuid.UUID] = mapped_column(
        UUID(as_uuid=True), ForeignKey("students.id", ondelete="CASCADE"), nullable=False
    )
    relationship_type: Mapped[str] = mapped_column(
        String(20), nullable=False
    )  # father, mother, guardian
    name: Mapped[str] = mapped_column(String(200), nullable=False)
    phone: Mapped[Optional[str]] = mapped_column(String(20))
    whatsapp_number: Mapped[Optional[str]] = mapped_column(String(20))
    email: Mapped[Optional[str]] = mapped_column(String(255))
    occupation: Mapped[Optional[str]] = mapped_column(String(100))
    is_primary: Mapped[bool] = mapped_column(Boolean, default=False)

    # Relationships
    student: Mapped["Student"] = relationship("Student", back_populates="parent_contacts")

    __table_args__ = (
        Index("ix_parent_contacts_student_id", "student_id"),
        Index("ix_parent_contacts_whatsapp", "whatsapp_number"),
    )


class Subject(UUIDMixin, TimestampMixin, Base):
    __tablename__ = "subjects"

    code: Mapped[str] = mapped_column(String(20), unique=True, nullable=False)
    name: Mapped[str] = mapped_column(String(100), nullable=False)
    description: Mapped[Optional[str]] = mapped_column(Text)
    is_active: Mapped[bool] = mapped_column(Boolean, default=True)
    max_marks: Mapped[int] = mapped_column(Integer, default=100)
    passing_marks: Mapped[int] = mapped_column(Integer, default=35)


class Class(UUIDMixin, TimestampMixin, Base):
    __tablename__ = "classes"

    academic_year_id: Mapped[uuid.UUID] = mapped_column(
        UUID(as_uuid=True), ForeignKey("academic_years.id"), nullable=False
    )
    name: Mapped[str] = mapped_column(String(50), nullable=False)  # e.g., "Grade 6"
    section: Mapped[str] = mapped_column(String(10), nullable=False)  # e.g., "A", "General"
    room_number: Mapped[Optional[str]] = mapped_column(String(20))
    capacity: Mapped[int] = mapped_column(Integer, default=40)
    is_active: Mapped[bool] = mapped_column(Boolean, default=True)

    # Relationships
    academic_year: Mapped["AcademicYear"] = relationship("AcademicYear", back_populates="classes")
    enrollments: Mapped[list["StudentClassEnrollment"]] = relationship(
        "StudentClassEnrollment", back_populates="class_"
    )
    teacher_assignments: Mapped[list["ClassTeacherAssignment"]] = relationship(
        "ClassTeacherAssignment", back_populates="class_"
    )
    timetable_slots: Mapped[list["TimetableSlot"]] = relationship(
        "TimetableSlot", back_populates="class_"
    )
    attendance_records: Mapped[list["Attendance"]] = relationship(
        "Attendance", back_populates="class_"
    )

    __table_args__ = (
        UniqueConstraint("academic_year_id", "name", "section", name="uq_class_year_name_section"),
        Index("ix_classes_academic_year_id", "academic_year_id"),
    )

    @property
    def display_name(self) -> str:
        return f"{self.name} - {self.section}"


class StudentClassEnrollment(UUIDMixin, TimestampMixin, Base):
    __tablename__ = "student_class_enrollments"

    student_id: Mapped[uuid.UUID] = mapped_column(
        UUID(as_uuid=True), ForeignKey("students.id"), nullable=False
    )
    class_id: Mapped[uuid.UUID] = mapped_column(
        UUID(as_uuid=True), ForeignKey("classes.id"), nullable=False
    )
    roll_number: Mapped[Optional[int]] = mapped_column(Integer)
    enrollment_date: Mapped[date] = mapped_column(Date, nullable=False)
    is_active: Mapped[bool] = mapped_column(Boolean, default=True)

    # Relationships
    student: Mapped["Student"] = relationship("Student", back_populates="class_enrollments")
    class_: Mapped["Class"] = relationship("Class", back_populates="enrollments")

    __table_args__ = (
        UniqueConstraint("student_id", "class_id", name="uq_student_class_enrollment"),
        Index("ix_student_class_enrollments_class_id", "class_id"),
        Index("ix_student_class_enrollments_student_id", "student_id"),
    )


class TeacherSubjectAssignment(UUIDMixin, TimestampMixin, Base):
    __tablename__ = "teacher_subject_assignments"

    teacher_id: Mapped[uuid.UUID] = mapped_column(
        UUID(as_uuid=True), ForeignKey("teachers.id"), nullable=False
    )
    subject_id: Mapped[uuid.UUID] = mapped_column(
        UUID(as_uuid=True), ForeignKey("subjects.id"), nullable=False
    )
    class_id: Mapped[uuid.UUID] = mapped_column(
        UUID(as_uuid=True), ForeignKey("classes.id"), nullable=False
    )

    teacher: Mapped["Teacher"] = relationship("Teacher", back_populates="subject_assignments")
    subject: Mapped["Subject"] = relationship("Subject")
    class_: Mapped["Class"] = relationship("Class")

    __table_args__ = (
        UniqueConstraint("teacher_id", "subject_id", "class_id", name="uq_teacher_subject_class"),
    )


class ClassTeacherAssignment(UUIDMixin, TimestampMixin, Base):
    __tablename__ = "class_teacher_assignments"

    class_id: Mapped[uuid.UUID] = mapped_column(
        UUID(as_uuid=True), ForeignKey("classes.id"), nullable=False
    )
    teacher_id: Mapped[uuid.UUID] = mapped_column(
        UUID(as_uuid=True), ForeignKey("teachers.id"), nullable=False
    )
    is_class_teacher: Mapped[bool] = mapped_column(Boolean, default=False)

    teacher: Mapped["Teacher"] = relationship("Teacher", back_populates="class_assignments")
    class_: Mapped["Class"] = relationship("Class", back_populates="teacher_assignments")

    __table_args__ = (
        UniqueConstraint("class_id", "teacher_id", name="uq_class_teacher"),
    )


class TimetableSlot(UUIDMixin, TimestampMixin, Base):
    __tablename__ = "timetable_slots"

    class_id: Mapped[uuid.UUID] = mapped_column(
        UUID(as_uuid=True), ForeignKey("classes.id"), nullable=False
    )
    teacher_id: Mapped[uuid.UUID] = mapped_column(
        UUID(as_uuid=True), ForeignKey("teachers.id"), nullable=False
    )
    subject_id: Mapped[uuid.UUID] = mapped_column(
        UUID(as_uuid=True), ForeignKey("subjects.id"), nullable=False
    )
    day_of_week: Mapped[int] = mapped_column(Integer, nullable=False)  # 0=Monday, 6=Sunday
    period_number: Mapped[int] = mapped_column(Integer, nullable=False)
    start_time: Mapped[str] = mapped_column(String(5), nullable=False)  # "HH:MM"
    end_time: Mapped[str] = mapped_column(String(5), nullable=False)

    class_: Mapped["Class"] = relationship("Class", back_populates="timetable_slots")
    teacher: Mapped["Teacher"] = relationship("Teacher", back_populates="timetable_slots")
    subject: Mapped["Subject"] = relationship("Subject")

    __table_args__ = (
        UniqueConstraint(
            "class_id", "day_of_week", "period_number", name="uq_timetable_slot"
        ),
        Index("ix_timetable_slots_class_id", "class_id"),
        Index("ix_timetable_slots_teacher_id", "teacher_id"),
    )


class Holiday(UUIDMixin, TimestampMixin, Base):
    __tablename__ = "holidays"

    academic_year_id: Mapped[uuid.UUID] = mapped_column(
        UUID(as_uuid=True), ForeignKey("academic_years.id"), nullable=False
    )
    name: Mapped[str] = mapped_column(String(200), nullable=False)
    description: Mapped[Optional[str]] = mapped_column(Text)
    start_date: Mapped[date] = mapped_column(Date, nullable=False)
    end_date: Mapped[date] = mapped_column(Date, nullable=False)
    holiday_type: Mapped[HolidayType] = mapped_column(
        Enum(HolidayType, name="holidaytype"), nullable=False
    )
    is_active: Mapped[bool] = mapped_column(Boolean, default=True)

    academic_year: Mapped["AcademicYear"] = relationship(
        "AcademicYear", back_populates="holidays"
    )

    __table_args__ = (
        Index("ix_holidays_academic_year_id", "academic_year_id"),
        Index("ix_holidays_start_date", "start_date"),
        Index("ix_holidays_end_date", "end_date"),
    )


class AcademicCalendarEvent(UUIDMixin, TimestampMixin, Base):
    __tablename__ = "academic_calendar_events"

    academic_year_id: Mapped[uuid.UUID] = mapped_column(
        UUID(as_uuid=True), ForeignKey("academic_years.id"), nullable=False
    )
    title: Mapped[str] = mapped_column(String(200), nullable=False)
    description: Mapped[Optional[str]] = mapped_column(Text)
    event_date: Mapped[date] = mapped_column(Date, nullable=False)
    end_date: Mapped[Optional[date]] = mapped_column(Date)
    event_type: Mapped[str] = mapped_column(String(50), default="general")
    color: Mapped[Optional[str]] = mapped_column(String(7))

    academic_year: Mapped["AcademicYear"] = relationship(
        "AcademicYear", back_populates="calendar_events"
    )


class Attendance(UUIDMixin, TimestampMixin, Base):
    __tablename__ = "attendance"

    student_id: Mapped[uuid.UUID] = mapped_column(
        UUID(as_uuid=True), ForeignKey("students.id"), nullable=False
    )
    class_id: Mapped[uuid.UUID] = mapped_column(
        UUID(as_uuid=True), ForeignKey("classes.id"), nullable=False
    )
    academic_year_id: Mapped[uuid.UUID] = mapped_column(
        UUID(as_uuid=True), ForeignKey("academic_years.id"), nullable=False
    )
    attendance_date: Mapped[date] = mapped_column(Date, nullable=False)
    status: Mapped[AttendanceStatus] = mapped_column(
        Enum(AttendanceStatus, name="attendancestatus"), nullable=False
    )
    marked_by_teacher_id: Mapped[Optional[uuid.UUID]] = mapped_column(
        UUID(as_uuid=True), ForeignKey("teachers.id")
    )
    remarks: Mapped[Optional[str]] = mapped_column(Text)
    # Parent reason fields (set via WhatsApp)
    parent_reason: Mapped[Optional[str]] = mapped_column(Text)
    parent_reason_locked: Mapped[bool] = mapped_column(Boolean, default=False)
    whatsapp_response_status: Mapped[WhatsAppResponseStatus] = mapped_column(
        Enum(WhatsAppResponseStatus, name="whatsappresponsestatus"),
        default=WhatsAppResponseStatus.PENDING,
    )
    whatsapp_notification_sent_at: Mapped[Optional[datetime]] = mapped_column(
        DateTime(timezone=True)
    )

    student: Mapped["Student"] = relationship("Student", back_populates="attendance_records")
    class_: Mapped["Class"] = relationship("Class", back_populates="attendance_records")
    marked_by: Mapped[Optional["Teacher"]] = relationship("Teacher")

    __table_args__ = (
        UniqueConstraint("student_id", "attendance_date", "class_id", name="uq_attendance"),
        Index("ix_attendance_class_date", "class_id", "attendance_date"),
        Index("ix_attendance_student_date", "student_id", "attendance_date"),
        Index("ix_attendance_academic_year_id", "academic_year_id"),
        Index("ix_attendance_date", "attendance_date"),
    )


class Exam(UUIDMixin, TimestampMixin, Base):
    __tablename__ = "exams"

    academic_year_id: Mapped[uuid.UUID] = mapped_column(
        UUID(as_uuid=True), ForeignKey("academic_years.id"), nullable=False
    )
    name: Mapped[str] = mapped_column(String(200), nullable=False)
    exam_type: Mapped[ExamType] = mapped_column(
        Enum(ExamType, name="examtype"), nullable=False
    )
    start_date: Mapped[date] = mapped_column(Date, nullable=False)
    end_date: Mapped[date] = mapped_column(Date, nullable=False)
    is_published: Mapped[bool] = mapped_column(Boolean, default=False)
    description: Mapped[Optional[str]] = mapped_column(Text)

    academic_year: Mapped["AcademicYear"] = relationship("AcademicYear", back_populates="exams")
    schedules: Mapped[list["ExamSchedule"]] = relationship(
        "ExamSchedule", back_populates="exam", cascade="all, delete-orphan"
    )
    results: Mapped[list["ExamResult"]] = relationship(
        "ExamResult", back_populates="exam", cascade="all, delete-orphan"
    )

    __table_args__ = (
        Index("ix_exams_academic_year_id", "academic_year_id"),
    )


class ExamSchedule(UUIDMixin, TimestampMixin, Base):
    __tablename__ = "exam_schedules"

    exam_id: Mapped[uuid.UUID] = mapped_column(
        UUID(as_uuid=True), ForeignKey("exams.id", ondelete="CASCADE"), nullable=False
    )
    class_id: Mapped[uuid.UUID] = mapped_column(
        UUID(as_uuid=True), ForeignKey("classes.id"), nullable=False
    )
    subject_id: Mapped[uuid.UUID] = mapped_column(
        UUID(as_uuid=True), ForeignKey("subjects.id"), nullable=False
    )
    exam_date: Mapped[date] = mapped_column(Date, nullable=False)
    start_time: Mapped[Optional[str]] = mapped_column(String(5))
    end_time: Mapped[Optional[str]] = mapped_column(String(5))
    max_marks: Mapped[int] = mapped_column(Integer, default=100)
    passing_marks: Mapped[int] = mapped_column(Integer, default=35)

    exam: Mapped["Exam"] = relationship("Exam", back_populates="schedules")
    subject: Mapped["Subject"] = relationship("Subject")
    class_: Mapped["Class"] = relationship("Class")


class ExamResult(UUIDMixin, TimestampMixin, Base):
    __tablename__ = "exam_results"

    exam_id: Mapped[uuid.UUID] = mapped_column(
        UUID(as_uuid=True), ForeignKey("exams.id", ondelete="CASCADE"), nullable=False
    )
    student_id: Mapped[uuid.UUID] = mapped_column(
        UUID(as_uuid=True), ForeignKey("students.id"), nullable=False
    )
    subject_id: Mapped[uuid.UUID] = mapped_column(
        UUID(as_uuid=True), ForeignKey("subjects.id"), nullable=False
    )
    marks_obtained: Mapped[Optional[float]] = mapped_column(Numeric(6, 2))
    max_marks: Mapped[int] = mapped_column(Integer, default=100)
    is_absent: Mapped[bool] = mapped_column(Boolean, default=False)
    remarks: Mapped[Optional[str]] = mapped_column(Text)
    entered_by_teacher_id: Mapped[Optional[uuid.UUID]] = mapped_column(
        UUID(as_uuid=True), ForeignKey("teachers.id")
    )

    exam: Mapped["Exam"] = relationship("Exam", back_populates="results")
    student: Mapped["Student"] = relationship("Student", back_populates="exam_results")
    subject: Mapped["Subject"] = relationship("Subject")

    __table_args__ = (
        UniqueConstraint("exam_id", "student_id", "subject_id", name="uq_exam_result"),
        Index("ix_exam_results_exam_id", "exam_id"),
        Index("ix_exam_results_student_id", "student_id"),
    )


class FeeStructure(UUIDMixin, TimestampMixin, Base):
    __tablename__ = "fee_structures"

    academic_year_id: Mapped[uuid.UUID] = mapped_column(
        UUID(as_uuid=True), ForeignKey("academic_years.id"), nullable=False
    )
    name: Mapped[str] = mapped_column(String(200), nullable=False)
    description: Mapped[Optional[str]] = mapped_column(Text)
    amount: Mapped[float] = mapped_column(Numeric(12, 2), nullable=False)
    due_date: Mapped[Optional[date]] = mapped_column(Date)
    applicable_classes: Mapped[Optional[list]] = mapped_column(JSONB)  # list of class IDs
    is_mandatory: Mapped[bool] = mapped_column(Boolean, default=True)
    is_active: Mapped[bool] = mapped_column(Boolean, default=True)

    academic_year: Mapped["AcademicYear"] = relationship(
        "AcademicYear", back_populates="fees"
    )
    student_fees: Mapped[list["StudentFee"]] = relationship(
        "StudentFee", back_populates="fee_structure"
    )


class StudentFee(UUIDMixin, TimestampMixin, Base):
    __tablename__ = "student_fees"

    student_id: Mapped[uuid.UUID] = mapped_column(
        UUID(as_uuid=True), ForeignKey("students.id"), nullable=False
    )
    fee_structure_id: Mapped[uuid.UUID] = mapped_column(
        UUID(as_uuid=True), ForeignKey("fee_structures.id"), nullable=False
    )
    academic_year_id: Mapped[uuid.UUID] = mapped_column(
        UUID(as_uuid=True), ForeignKey("academic_years.id"), nullable=False
    )
    amount_due: Mapped[float] = mapped_column(Numeric(12, 2), nullable=False)
    amount_paid: Mapped[float] = mapped_column(Numeric(12, 2), default=0)
    due_date: Mapped[Optional[date]] = mapped_column(Date)
    status: Mapped[FeeStatus] = mapped_column(
        Enum(FeeStatus, name="feestatus"), default=FeeStatus.PENDING
    )
    concession_amount: Mapped[float] = mapped_column(Numeric(12, 2), default=0)
    concession_reason: Mapped[Optional[str]] = mapped_column(Text)
    remarks: Mapped[Optional[str]] = mapped_column(Text)

    student: Mapped["Student"] = relationship("Student", back_populates="fee_records")
    fee_structure: Mapped["FeeStructure"] = relationship("FeeStructure", back_populates="student_fees")
    payments: Mapped[list["Payment"]] = relationship(
        "Payment", back_populates="student_fee", cascade="all, delete-orphan"
    )

    __table_args__ = (
        UniqueConstraint("student_id", "fee_structure_id", name="uq_student_fee"),
        Index("ix_student_fees_student_id", "student_id"),
        Index("ix_student_fees_academic_year_id", "academic_year_id"),
        Index("ix_student_fees_status", "status"),
    )


class Payment(UUIDMixin, TimestampMixin, Base):
    __tablename__ = "payments"

    student_fee_id: Mapped[uuid.UUID] = mapped_column(
        UUID(as_uuid=True), ForeignKey("student_fees.id", ondelete="CASCADE"), nullable=False
    )
    amount: Mapped[float] = mapped_column(Numeric(12, 2), nullable=False)
    payment_date: Mapped[date] = mapped_column(Date, nullable=False)
    payment_method: Mapped[PaymentMethod] = mapped_column(
        Enum(PaymentMethod, name="paymentmethod"), nullable=False
    )
    receipt_number: Mapped[Optional[str]] = mapped_column(String(100), unique=True)
    transaction_id: Mapped[Optional[str]] = mapped_column(String(255))
    remarks: Mapped[Optional[str]] = mapped_column(Text)
    collected_by_clerk_id: Mapped[Optional[str]] = mapped_column(String(255))

    student_fee: Mapped["StudentFee"] = relationship("StudentFee", back_populates="payments")

    __table_args__ = (
        Index("ix_payments_student_fee_id", "student_fee_id"),
        Index("ix_payments_payment_date", "payment_date"),
    )


class Notification(UUIDMixin, TimestampMixin, Base):
    __tablename__ = "notifications"

    academic_year_id: Mapped[Optional[uuid.UUID]] = mapped_column(
        UUID(as_uuid=True), ForeignKey("academic_years.id")
    )
    student_id: Mapped[Optional[uuid.UUID]] = mapped_column(
        UUID(as_uuid=True), ForeignKey("students.id")
    )
    parent_contact_id: Mapped[Optional[uuid.UUID]] = mapped_column(
        UUID(as_uuid=True), ForeignKey("parent_contacts.id")
    )
    channel: Mapped[NotificationChannel] = mapped_column(
        Enum(NotificationChannel, name="notificationchannel"), nullable=False
    )
    recipient_number: Mapped[Optional[str]] = mapped_column(String(20))
    recipient_email: Mapped[Optional[str]] = mapped_column(String(255))
    template_name: Mapped[Optional[str]] = mapped_column(String(100))
    message_body: Mapped[Optional[str]] = mapped_column(Text)
    status: Mapped[NotificationStatus] = mapped_column(
        Enum(NotificationStatus, name="notificationstatus"), default=NotificationStatus.PENDING
    )
    whatsapp_message_id: Mapped[Optional[str]] = mapped_column(String(255))
    error_message: Mapped[Optional[str]] = mapped_column(Text)
    sent_at: Mapped[Optional[datetime]] = mapped_column(DateTime(timezone=True))
    delivered_at: Mapped[Optional[datetime]] = mapped_column(DateTime(timezone=True))
    notification_type: Mapped[str] = mapped_column(
        String(50), default="general"
    )  # attendance, fee, general, exam
    extra_data: Mapped[Optional[dict]] = mapped_column(JSONB)

    __table_args__ = (
        Index("ix_notifications_student_id", "student_id"),
        Index("ix_notifications_status", "status"),
        Index("ix_notifications_sent_at", "sent_at"),
        Index("ix_notifications_academic_year_id", "academic_year_id"),
    )


class CSVImportJob(UUIDMixin, TimestampMixin, Base):
    __tablename__ = "csv_import_jobs"

    import_type: Mapped[CSVImportType] = mapped_column(
        Enum(CSVImportType, name="csvimporttype"), nullable=False
    )
    academic_year_id: Mapped[Optional[uuid.UUID]] = mapped_column(
        UUID(as_uuid=True), ForeignKey("academic_years.id")
    )
    filename: Mapped[str] = mapped_column(String(255), nullable=False)
    total_rows: Mapped[int] = mapped_column(Integer, default=0)
    processed_rows: Mapped[int] = mapped_column(Integer, default=0)
    success_rows: Mapped[int] = mapped_column(Integer, default=0)
    error_rows: Mapped[int] = mapped_column(Integer, default=0)
    duplicate_rows: Mapped[int] = mapped_column(Integer, default=0)
    status: Mapped[CSVImportStatus] = mapped_column(
        Enum(CSVImportStatus, name="csvimportstatus"), default=CSVImportStatus.PENDING
    )
    errors: Mapped[Optional[list]] = mapped_column(JSONB)  # list of {row, error}
    imported_ids: Mapped[Optional[list]] = mapped_column(JSONB)  # for rollback
    started_at: Mapped[Optional[datetime]] = mapped_column(DateTime(timezone=True))
    completed_at: Mapped[Optional[datetime]] = mapped_column(DateTime(timezone=True))
    initiated_by_clerk_id: Mapped[Optional[str]] = mapped_column(String(255))

    __table_args__ = (
        Index("ix_csv_import_jobs_status", "status"),
        Index("ix_csv_import_jobs_import_type", "import_type"),
    )


class AuditLog(UUIDMixin, Base):
    __tablename__ = "audit_logs"

    created_at: Mapped[datetime] = mapped_column(
        DateTime(timezone=True), server_default=func.now(), nullable=False
    )
    actor_clerk_id: Mapped[Optional[str]] = mapped_column(String(255))
    actor_role: Mapped[Optional[str]] = mapped_column(String(50))
    actor_name: Mapped[Optional[str]] = mapped_column(String(200))
    action: Mapped[str] = mapped_column(String(100), nullable=False)
    resource_type: Mapped[str] = mapped_column(String(100), nullable=False)
    resource_id: Mapped[Optional[str]] = mapped_column(String(255))
    old_values: Mapped[Optional[dict]] = mapped_column(JSONB)
    new_values: Mapped[Optional[dict]] = mapped_column(JSONB)
    ip_address: Mapped[Optional[str]] = mapped_column(String(50))
    user_agent: Mapped[Optional[str]] = mapped_column(Text)
    extra_data: Mapped[Optional[dict]] = mapped_column(JSONB)

    __table_args__ = (
        Index("ix_audit_logs_actor_clerk_id", "actor_clerk_id"),
        Index("ix_audit_logs_action", "action"),
        Index("ix_audit_logs_resource_type", "resource_type"),
        Index("ix_audit_logs_created_at", "created_at"),
    )
