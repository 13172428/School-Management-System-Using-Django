"""
Pydantic v2 schemas for request/response validation.
All schemas are type-safe with proper validation.
"""
import uuid
from datetime import date, datetime
from decimal import Decimal
from typing import Any, Optional

from pydantic import BaseModel, EmailStr, Field, field_validator, model_validator

from app.models.models import (
    AttendanceStatus,
    CSVImportStatus,
    CSVImportType,
    ExamType,
    FeeStatus,
    HolidayType,
    NotificationChannel,
    NotificationStatus,
    PaymentMethod,
    WhatsAppResponseStatus,
)


# ─── Base ──────────────────────────────────────────────────────────────────────

class BaseResponse(BaseModel):
    model_config = {"from_attributes": True}


class PaginatedResponse(BaseModel):
    total: int
    page: int
    page_size: int
    items: list[Any]


# ─── Academic Year ─────────────────────────────────────────────────────────────

class AcademicYearCreate(BaseModel):
    name: str = Field(..., min_length=1, max_length=50)
    start_date: date
    end_date: date
    is_active: bool = False
    description: Optional[str] = None

    @model_validator(mode="after")
    def validate_dates(self) -> "AcademicYearCreate":
        if self.end_date <= self.start_date:
            raise ValueError("end_date must be after start_date")
        return self


class AcademicYearUpdate(BaseModel):
    name: Optional[str] = Field(None, min_length=1, max_length=50)
    start_date: Optional[date] = None
    end_date: Optional[date] = None
    is_active: Optional[bool] = None
    description: Optional[str] = None


class AcademicYearResponse(BaseResponse):
    id: uuid.UUID
    name: str
    start_date: date
    end_date: date
    is_active: bool
    is_archived: bool
    description: Optional[str]
    created_at: datetime
    updated_at: datetime


# ─── Teacher ───────────────────────────────────────────────────────────────────

class TeacherCreate(BaseModel):
    employee_id: str = Field(..., min_length=1, max_length=50)
    first_name: str = Field(..., min_length=1, max_length=100)
    last_name: str = Field(..., min_length=1, max_length=100)
    email: EmailStr
    phone: Optional[str] = Field(None, max_length=20)
    whatsapp_number: Optional[str] = Field(None, max_length=20)
    qualification: Optional[str] = None
    joining_date: Optional[date] = None
    address: Optional[str] = None
    clerk_user_id: Optional[str] = None


class TeacherUpdate(BaseModel):
    first_name: Optional[str] = Field(None, min_length=1, max_length=100)
    last_name: Optional[str] = Field(None, min_length=1, max_length=100)
    email: Optional[EmailStr] = None
    phone: Optional[str] = None
    whatsapp_number: Optional[str] = None
    qualification: Optional[str] = None
    joining_date: Optional[date] = None
    address: Optional[str] = None
    is_active: Optional[bool] = None
    clerk_user_id: Optional[str] = None


class TeacherResponse(BaseResponse):
    id: uuid.UUID
    employee_id: str
    first_name: str
    last_name: str
    full_name: str
    email: str
    phone: Optional[str]
    whatsapp_number: Optional[str]
    qualification: Optional[str]
    joining_date: Optional[date]
    is_active: bool
    clerk_user_id: Optional[str]
    created_at: datetime


# ─── Student ───────────────────────────────────────────────────────────────────

class ParentContactCreate(BaseModel):
    relationship_type: str = Field(..., pattern="^(father|mother|guardian)$")
    name: str = Field(..., min_length=1, max_length=200)
    phone: Optional[str] = Field(None, max_length=20)
    whatsapp_number: Optional[str] = Field(None, max_length=20)
    email: Optional[EmailStr] = None
    occupation: Optional[str] = None
    is_primary: bool = False


class ParentContactResponse(BaseResponse):
    id: uuid.UUID
    relationship_type: str
    name: str
    phone: Optional[str]
    whatsapp_number: Optional[str]
    email: Optional[str]
    occupation: Optional[str]
    is_primary: bool


class StudentCreate(BaseModel):
    admission_number: str = Field(..., min_length=1, max_length=50)
    first_name: str = Field(..., min_length=1, max_length=100)
    last_name: str = Field(..., min_length=1, max_length=100)
    date_of_birth: Optional[date] = None
    gender: Optional[str] = Field(None, pattern="^(male|female|other)$")
    blood_group: Optional[str] = None
    address: Optional[str] = None
    admission_date: Optional[date] = None
    parent_contacts: list[ParentContactCreate] = Field(default_factory=list)


class StudentUpdate(BaseModel):
    first_name: Optional[str] = Field(None, min_length=1, max_length=100)
    last_name: Optional[str] = Field(None, min_length=1, max_length=100)
    date_of_birth: Optional[date] = None
    gender: Optional[str] = None
    blood_group: Optional[str] = None
    address: Optional[str] = None
    is_active: Optional[bool] = None


class StudentResponse(BaseResponse):
    id: uuid.UUID
    admission_number: str
    first_name: str
    last_name: str
    full_name: str
    date_of_birth: Optional[date]
    gender: Optional[str]
    blood_group: Optional[str]
    admission_date: Optional[date]
    is_active: bool
    parent_contacts: list[ParentContactResponse] = []
    created_at: datetime


# ─── Class ─────────────────────────────────────────────────────────────────────

class ClassCreate(BaseModel):
    academic_year_id: uuid.UUID
    name: str = Field(..., min_length=1, max_length=50, description='e.g. "Grade 6"')
    section: str = Field(..., min_length=1, max_length=10, description='e.g. "A" or "General"')
    room_number: Optional[str] = None
    capacity: int = Field(default=40, ge=1, le=200)


class ClassUpdate(BaseModel):
    name: Optional[str] = None
    section: Optional[str] = None
    room_number: Optional[str] = None
    capacity: Optional[int] = Field(None, ge=1, le=200)
    is_active: Optional[bool] = None


class ClassResponse(BaseResponse):
    id: uuid.UUID
    academic_year_id: uuid.UUID
    name: str
    section: str
    display_name: str
    room_number: Optional[str]
    capacity: int
    is_active: bool
    student_count: int = 0


# ─── Subject ───────────────────────────────────────────────────────────────────

class SubjectCreate(BaseModel):
    academic_year_id: uuid.UUID
    code: str = Field(..., min_length=1, max_length=20)
    name: str = Field(..., min_length=1, max_length=100)
    description: Optional[str] = None
    max_marks: int = Field(default=100, ge=1)
    passing_marks: int = Field(default=35, ge=1)


class SubjectUpdate(BaseModel):
    name: Optional[str] = None
    description: Optional[str] = None
    max_marks: Optional[int] = Field(None, ge=1)
    passing_marks: Optional[int] = Field(None, ge=1)
    is_active: Optional[bool] = None


class SubjectResponse(BaseResponse):
    id: uuid.UUID
    code: str
    name: str
    description: Optional[str]
    is_active: bool
    max_marks: int
    passing_marks: int


# ─── Holiday ───────────────────────────────────────────────────────────────────

class HolidayCreate(BaseModel):
    academic_year_id: uuid.UUID
    name: str = Field(..., min_length=1, max_length=200)
    description: Optional[str] = None
    start_date: date
    end_date: date
    holiday_type: HolidayType

    @model_validator(mode="after")
    def validate_dates(self) -> "HolidayCreate":
        if self.end_date < self.start_date:
            raise ValueError("end_date cannot be before start_date")
        return self


class HolidayUpdate(BaseModel):
    name: Optional[str] = None
    description: Optional[str] = None
    start_date: Optional[date] = None
    end_date: Optional[date] = None
    holiday_type: Optional[HolidayType] = None
    is_active: Optional[bool] = None


class HolidayResponse(BaseResponse):
    id: uuid.UUID
    academic_year_id: uuid.UUID
    name: str
    description: Optional[str]
    start_date: date
    end_date: date
    holiday_type: HolidayType
    is_active: bool
    duration_days: int = 1

    @field_validator("duration_days", mode="before")
    @classmethod
    def compute_duration(cls, v: Any, info: Any) -> int:
        data = info.data if hasattr(info, "data") else {}
        start = data.get("start_date")
        end = data.get("end_date")
        if start and end:
            return (end - start).days + 1
        return v if v else 1


# ─── Attendance ────────────────────────────────────────────────────────────────

class AttendanceRecord(BaseModel):
    student_id: uuid.UUID
    status: AttendanceStatus
    remarks: Optional[str] = None


class AttendanceBulkCreate(BaseModel):
    class_id: uuid.UUID
    attendance_date: date
    records: list[AttendanceRecord] = Field(..., min_length=1)
    send_whatsapp_notifications: bool = True


class AttendanceUpdate(BaseModel):
    status: Optional[AttendanceStatus] = None
    remarks: Optional[str] = None


class AttendanceResponse(BaseResponse):
    id: uuid.UUID
    student_id: uuid.UUID
    class_id: uuid.UUID
    attendance_date: date
    status: AttendanceStatus
    remarks: Optional[str]
    parent_reason: Optional[str]
    parent_reason_locked: bool
    whatsapp_response_status: WhatsAppResponseStatus
    student_name: Optional[str] = None
    roll_number: Optional[int] = None


class AttendanceSummary(BaseModel):
    total_enrolled: int
    present: int
    absent: int
    late: int
    not_marked: int
    attendance_percentage: float


# ─── Exam ──────────────────────────────────────────────────────────────────────

class ExamCreate(BaseModel):
    name: str = Field(..., min_length=1, max_length=200)
    exam_type: ExamType
    start_date: date
    end_date: date
    description: Optional[str] = None


class ExamResponse(BaseResponse):
    id: uuid.UUID
    academic_year_id: uuid.UUID
    name: str
    exam_type: ExamType
    start_date: date
    end_date: date
    is_published: bool
    description: Optional[str]
    created_at: datetime


class ExamResultCreate(BaseModel):
    student_id: uuid.UUID
    subject_id: uuid.UUID
    marks_obtained: Optional[float] = Field(None, ge=0)
    max_marks: int = Field(default=100, ge=1)
    is_absent: bool = False
    remarks: Optional[str] = None


class ExamResultResponse(BaseResponse):
    id: uuid.UUID
    exam_id: uuid.UUID
    student_id: uuid.UUID
    subject_id: uuid.UUID
    marks_obtained: Optional[float]
    max_marks: int
    is_absent: bool
    remarks: Optional[str]
    percentage: Optional[float] = None


# ─── Fee ───────────────────────────────────────────────────────────────────────

class FeeStructureCreate(BaseModel):
    name: str = Field(..., min_length=1, max_length=200)
    description: Optional[str] = None
    amount: float = Field(..., gt=0)
    due_date: Optional[date] = None
    applicable_classes: Optional[list[str]] = None
    is_mandatory: bool = True


class FeeStructureResponse(BaseResponse):
    id: uuid.UUID
    academic_year_id: uuid.UUID
    name: str
    description: Optional[str]
    amount: float
    due_date: Optional[date]
    is_mandatory: bool
    is_active: bool


class PaymentCreate(BaseModel):
    amount: float = Field(..., gt=0)
    payment_date: date
    payment_method: PaymentMethod
    receipt_number: Optional[str] = None
    transaction_id: Optional[str] = None
    remarks: Optional[str] = None


class StudentFeeResponse(BaseResponse):
    id: uuid.UUID
    student_id: uuid.UUID
    fee_structure_id: uuid.UUID
    academic_year_id: uuid.UUID
    amount: float = Field(validation_alias="amount_due")
    paid_amount: float = Field(validation_alias="amount_paid")
    due_date: Optional[date]
    status: FeeStatus
    concession_amount: float
    concession_reason: Optional[str]
    balance: float = 0.0

    model_config = {"from_attributes": True, "populate_by_name": True}

    @model_validator(mode="after")
    def compute_balance(self) -> "StudentFeeResponse":
        self.balance = max(0.0, self.amount - self.paid_amount - (self.concession_amount or 0))
        return self


# ─── Notification ──────────────────────────────────────────────────────────────

class NotificationResponse(BaseResponse):
    id: uuid.UUID
    student_id: Optional[uuid.UUID]
    channel: NotificationChannel
    recipient_number: Optional[str]
    status: NotificationStatus
    sent_at: Optional[datetime]
    notification_type: str
    error_message: Optional[str]


# ─── CSV Import ────────────────────────────────────────────────────────────────

class CSVImportJobResponse(BaseResponse):
    id: uuid.UUID
    import_type: CSVImportType
    filename: str
    total_rows: int
    processed_rows: int
    success_rows: int
    error_rows: int
    duplicate_rows: int
    status: CSVImportStatus
    errors: Optional[list]
    started_at: Optional[datetime]
    completed_at: Optional[datetime]
    created_at: datetime


# ─── Dashboard ─────────────────────────────────────────────────────────────────

class AdminDashboardStats(BaseModel):
    date: date
    # Students
    total_students: int
    active_students: int
    # Attendance
    present_today: int
    absent_today: int
    attendance_percentage: float
    # Fees
    total_fees: float
    collected_fees: float
    pending_fees: float
    overdue_fees: float
    # Teachers
    total_teachers: int
    active_teachers: int
    # Notifications
    notifications_sent: int
    notifications_failed: int
    # Upcoming
    upcoming_holidays: list[HolidayResponse] = []
    is_today_holiday: bool = False
    holiday_name: Optional[str] = None


class TeacherDashboardStats(BaseModel):
    date: date
    teacher_id: uuid.UUID
    todays_classes: list[dict] = []
    attendance_summary: list[dict] = []
    upcoming_exams: list[ExamResponse] = []
    pending_attendance_classes: list[dict] = []


# ─── Audit Log ─────────────────────────────────────────────────────────────────

class AuditLogResponse(BaseModel):
    id: uuid.UUID
    created_at: datetime
    actor_clerk_id: Optional[str]
    actor_role: Optional[str]
    actor_name: Optional[str]
    action: str
    resource_type: str
    resource_id: Optional[str]
    ip_address: Optional[str]

    model_config = {"from_attributes": True}


# ─── Exam (additional) ────────────────────────────────────────────────────────

class ExamUpdate(BaseModel):
    name: Optional[str] = None
    exam_type: Optional[ExamType] = None
    start_date: Optional[date] = None
    end_date: Optional[date] = None
    is_published: Optional[bool] = None
    description: Optional[str] = None


class ExamScheduleCreate(BaseModel):
    class_id: uuid.UUID
    subject_id: uuid.UUID
    exam_date: date
    start_time: Optional[str] = None
    end_time: Optional[str] = None
    room: Optional[str] = None


class ExamScheduleResponse(BaseResponse):
    id: uuid.UUID
    exam_id: uuid.UUID
    class_id: uuid.UUID
    subject_id: uuid.UUID
    exam_date: date
    start_time: Optional[str]
    end_time: Optional[str]
    room: Optional[str]


class ExamResultUpdate(BaseModel):
    marks_obtained: Optional[float] = Field(None, ge=0)
    is_absent: Optional[bool] = None
    remarks: Optional[str] = None


# ─── Fee (additional) ─────────────────────────────────────────────────────────

class FeeStructureUpdate(BaseModel):
    name: Optional[str] = None
    description: Optional[str] = None
    amount: Optional[float] = Field(None, gt=0)
    due_date: Optional[date] = None
    is_mandatory: Optional[bool] = None
    is_active: Optional[bool] = None


class StudentFeeCreate(BaseModel):
    student_id: uuid.UUID
    fee_structure_id: uuid.UUID
    academic_year_id: uuid.UUID
    amount_due: float = Field(..., gt=0, alias="amount")
    due_date: Optional[date] = None
    concession_amount: float = 0.0
    concession_reason: Optional[str] = None

    model_config = {"populate_by_name": True}


class StudentFeeUpdate(BaseModel):
    due_date: Optional[date] = None
    status: Optional[FeeStatus] = None
    concession_amount: Optional[float] = Field(None, ge=0)
    concession_reason: Optional[str] = None


class PaymentResponse(BaseResponse):
    id: uuid.UUID
    student_fee_id: uuid.UUID
    amount: float
    payment_date: date
    payment_method: PaymentMethod
    receipt_number: Optional[str]
    transaction_id: Optional[str]
    remarks: Optional[str]
    created_at: datetime


# ─── Timetable ─────────────────────────────────────────────────────────────────

class TimetableSlotCreate(BaseModel):
    academic_year_id: uuid.UUID
    class_id: uuid.UUID
    subject_id: Optional[uuid.UUID] = None
    teacher_id: Optional[uuid.UUID] = None
    day_of_week: int = Field(..., ge=0, le=6, description="0=Monday, 6=Sunday")
    start_time: str = Field(..., description="HH:MM format")
    end_time: str = Field(..., description="HH:MM format")
    room: Optional[str] = None


class TimetableSlotUpdate(BaseModel):
    subject_id: Optional[uuid.UUID] = None
    teacher_id: Optional[uuid.UUID] = None
    day_of_week: Optional[int] = Field(None, ge=0, le=6)
    start_time: Optional[str] = None
    end_time: Optional[str] = None
    room: Optional[str] = None


class TimetableSlotResponse(BaseResponse):
    id: uuid.UUID
    academic_year_id: uuid.UUID
    class_id: uuid.UUID
    subject_id: Optional[uuid.UUID]
    teacher_id: Optional[uuid.UUID]
    day_of_week: int
    start_time: str
    end_time: str
    room: Optional[str]


# ─── Generic ───────────────────────────────────────────────────────────────────

class MessageResponse(BaseModel):
    message: str
    success: bool = True


class ErrorResponse(BaseModel):
    detail: str
    code: Optional[str] = None
