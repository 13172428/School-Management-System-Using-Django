"""
API tests for core endpoints.
Uses the async test client with mocked authentication.
"""
from unittest.mock import AsyncMock, patch
from datetime import date

import pytest
from httpx import AsyncClient

from app.core.security import CurrentUser, UserRole


# ─── Mock current user ────────────────────────────────────────────────────────

ADMIN_USER = CurrentUser(
    clerk_user_id="user_test_admin",
    email="admin@school.edu",
    role=UserRole.ADMIN,
    first_name="Test",
    last_name="Admin",
)

TEACHER_USER = CurrentUser(
    clerk_user_id="user_test_teacher",
    email="teacher@school.edu",
    role=UserRole.TEACHER,
    first_name="Test",
    last_name="Teacher",
)


def patch_auth(user: CurrentUser):
    """Patch Clerk auth to return a specific user."""
    from app.core.security import get_current_user

    async def _override():
        return user

    return patch("app.core.security.get_current_user", new=_override)


# ─── Health check ─────────────────────────────────────────────────────────────

@pytest.mark.asyncio
async def test_health_check(client: AsyncClient):
    response = await client.get("/health")
    assert response.status_code == 200
    data = response.json()
    assert data["status"] == "ok"


# ─── Academic Years ───────────────────────────────────────────────────────────

@pytest.mark.asyncio
async def test_list_academic_years_empty(client: AsyncClient, db_session):
    from app.main import app
    from app.core.security import get_current_user

    app.dependency_overrides[get_current_user] = lambda: ADMIN_USER

    response = await client.get("/api/v1/academic-years")
    assert response.status_code == 200
    assert isinstance(response.json(), list)

    app.dependency_overrides.pop(get_current_user, None)


@pytest.mark.asyncio
async def test_create_academic_year(client: AsyncClient, db_session):
    from app.main import app
    from app.core.security import get_current_user

    app.dependency_overrides[get_current_user] = lambda: ADMIN_USER

    payload = {
        "name": "2026-27",
        "start_date": "2026-06-01",
        "end_date": "2027-03-31",
        "is_active": True,
    }
    response = await client.post("/api/v1/academic-years", json=payload)
    assert response.status_code == 201
    data = response.json()
    assert data["name"] == "2026-27"
    assert data["is_active"] is True

    app.dependency_overrides.pop(get_current_user, None)


@pytest.mark.asyncio
async def test_create_academic_year_invalid_dates(client: AsyncClient, db_session):
    from app.main import app
    from app.core.security import get_current_user

    app.dependency_overrides[get_current_user] = lambda: ADMIN_USER

    payload = {
        "name": "Bad Year",
        "start_date": "2027-03-31",
        "end_date": "2026-06-01",  # end before start
    }
    response = await client.post("/api/v1/academic-years", json=payload)
    assert response.status_code == 422  # Pydantic validation error

    app.dependency_overrides.pop(get_current_user, None)


# ─── Holidays ─────────────────────────────────────────────────────────────────

@pytest.mark.asyncio
async def test_check_sunday_is_holiday(client: AsyncClient):
    from app.main import app
    from app.core.security import get_current_user

    app.dependency_overrides[get_current_user] = lambda: ADMIN_USER

    response = await client.get("/api/v1/holidays/check", params={"date": "2026-06-07"})
    assert response.status_code == 200
    data = response.json()
    assert data["is_holiday"] is True
    assert data["is_sunday"] is True

    app.dependency_overrides.pop(get_current_user, None)


@pytest.mark.asyncio
async def test_check_weekday_not_holiday(client: AsyncClient):
    from app.main import app
    from app.core.security import get_current_user

    app.dependency_overrides[get_current_user] = lambda: ADMIN_USER

    response = await client.get("/api/v1/holidays/check", params={"date": "2026-06-08"})
    assert response.status_code == 200
    data = response.json()
    assert data["is_sunday"] is False

    app.dependency_overrides.pop(get_current_user, None)


# ─── Students ─────────────────────────────────────────────────────────────────

@pytest.mark.asyncio
async def test_list_students(client: AsyncClient):
    from app.main import app
    from app.core.security import get_current_user

    app.dependency_overrides[get_current_user] = lambda: ADMIN_USER

    response = await client.get("/api/v1/students")
    assert response.status_code == 200
    assert isinstance(response.json(), list)

    app.dependency_overrides.pop(get_current_user, None)


@pytest.mark.asyncio
async def test_teacher_cannot_create_student(client: AsyncClient):
    from app.main import app
    from app.core.security import get_current_user

    app.dependency_overrides[get_current_user] = lambda: TEACHER_USER

    payload = {
        "admission_number": "ADM001",
        "first_name": "Test",
        "last_name": "Student",
        "academic_year_id": "00000000-0000-0000-0000-000000000000",
    }
    response = await client.post("/api/v1/students", json=payload)
    # Teacher should be forbidden
    assert response.status_code == 403

    app.dependency_overrides.pop(get_current_user, None)
