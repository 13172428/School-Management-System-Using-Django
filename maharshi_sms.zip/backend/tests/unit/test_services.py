"""
Unit tests for HolidayService and AttendanceService.
"""
from datetime import date
from unittest.mock import AsyncMock, MagicMock, patch

import pytest

from app.services.holiday_service import HolidayService


class TestHolidayServiceIsSunday:
    """Test is_holiday returns True for Sundays regardless of DB holidays."""

    @pytest.mark.asyncio
    async def test_sunday_is_always_holiday(self):
        db = AsyncMock()
        db.execute = AsyncMock(return_value=MagicMock(scalar_one_or_none=lambda: None))
        svc = HolidayService(db)
        # 2026-06-07 is a Sunday
        is_hol, holiday = await svc.is_holiday(date(2026, 6, 7), MagicMock())
        assert is_hol is True
        assert holiday is None  # Sunday returns no Holiday record

    @pytest.mark.asyncio
    async def test_monday_not_holiday_without_db_record(self):
        db = AsyncMock()
        mock_result = MagicMock()
        mock_result.scalar_one_or_none.return_value = None
        db.execute = AsyncMock(return_value=mock_result)
        svc = HolidayService(db)
        # 2026-06-08 is a Monday
        is_hol, holiday = await svc.is_holiday(date(2026, 6, 8), MagicMock())
        assert is_hol is False
        assert holiday is None

    @pytest.mark.asyncio
    async def test_db_holiday_detected(self):
        from app.models.models import Holiday
        fake_holiday = MagicMock(spec=Holiday)
        mock_result = MagicMock()
        mock_result.scalar_one_or_none.return_value = fake_holiday
        db = AsyncMock()
        db.execute = AsyncMock(return_value=mock_result)
        svc = HolidayService(db)
        # Tuesday — not a Sunday, but DB has a holiday
        is_hol, holiday = await svc.is_holiday(date(2026, 6, 9), MagicMock())
        assert is_hol is True
        assert holiday is fake_holiday


class TestHolidayServiceWorkingDays:
    @pytest.mark.asyncio
    async def test_count_working_days_excludes_sundays(self):
        # Mock get_holidays_in_range to return no DB holidays
        db = AsyncMock()
        svc = HolidayService(db)
        with patch.object(svc, "get_holidays_in_range", return_value=[]):
            # Mon 2026-06-01 to Sun 2026-06-07 (7 days, 1 Sunday → 6 working days)
            count = await svc.count_working_days(
                start_date=date(2026, 6, 1),
                end_date=date(2026, 6, 7),
                academic_year_id=MagicMock(),
            )
        assert count == 6  # 7 total - 1 Sunday

    @pytest.mark.asyncio
    async def test_count_working_days_excludes_db_holiday(self):
        from app.models.models import Holiday
        # Create a fake holiday on Monday 2026-06-08
        fake_holiday = MagicMock(spec=Holiday)
        fake_holiday.start_date = date(2026, 6, 8)
        fake_holiday.end_date = date(2026, 6, 8)

        db = AsyncMock()
        svc = HolidayService(db)
        with patch.object(svc, "get_holidays_in_range", return_value=[fake_holiday]):
            # Mon 2026-06-08 to Fri 2026-06-12 = 5 days, 1 holiday → 4 working days
            count = await svc.count_working_days(
                start_date=date(2026, 6, 8),
                end_date=date(2026, 6, 12),
                academic_year_id=MagicMock(),
            )
        assert count == 4


class TestAttendanceServiceValidation:
    @pytest.mark.asyncio
    async def test_rejects_sunday(self):
        from app.services.attendance_service import AttendanceService

        db = AsyncMock()
        mock_result = MagicMock()
        mock_result.scalar_one_or_none.return_value = None
        db.execute = AsyncMock(return_value=mock_result)

        holiday_svc = HolidayService(db)
        svc = AttendanceService(db, holiday_svc)

        with pytest.raises(ValueError) as exc:
            # 2026-06-07 is a Sunday — attendance blocked
            await svc.validate_attendance_date(date(2026, 6, 7), MagicMock())
        assert "holiday" in str(exc.value).lower() or "sunday" in str(exc.value).lower()

    @pytest.mark.asyncio
    async def test_allows_weekday(self):
        from app.services.attendance_service import AttendanceService

        db = AsyncMock()
        mock_result = MagicMock()
        mock_result.scalar_one_or_none.return_value = None
        db.execute = AsyncMock(return_value=mock_result)

        holiday_svc = HolidayService(db)
        svc = AttendanceService(db, holiday_svc)

        # Should not raise — 2026-06-08 is a Monday
        await svc.validate_attendance_date(date(2026, 6, 8), MagicMock())
